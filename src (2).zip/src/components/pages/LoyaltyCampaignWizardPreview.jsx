import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Header from '@/components/layout/Header'

const STATUS_META = {
  local: {
    label: 'Aninda calisir',
    detail: 'Mevcut POS/Kiosk siparis baglamiyla uygulanabilir.',
    color: '#166534',
    background: '#dcfce7',
    border: '#bbf7d0',
  },
  server: {
    label: 'Canli kontrol ister',
    detail: 'Musteri gecmisi, zaman, kupon veya satis gecmisi icin canli sorgu gerekir.',
    color: '#92400e',
    background: '#fef3c7',
    border: '#fde68a',
  },
  ledger: {
    label: 'Deger defteri yazar',
    detail: 'Puan, kupon, hak veya redemption kaydi olusturur.',
    color: '#6d28d9',
    background: '#f3e8ff',
    border: '#ddd6fe',
  },
  model: {
    label: 'Motor eksik',
    detail: 'Tanimlanabilir ama checkout/runtime davranisi henuz tamamlanmamis.',
    color: '#475569',
    background: '#f8fafc',
    border: '#cbd5e1',
  },
  presentation: {
    label: 'Gosterim',
    detail: 'Kullaniciya uyari veya oneriyi gosterir; ticari etki ayrica tanimlanir.',
    color: '#0369a1',
    background: '#e0f2fe',
    border: '#bae6fd',
  },
}

const STEPS = [
  { id: 'goal', title: 'Amac', prompt: 'Once kampanyanin neyi basarmasini istedigini sec.' },
  { id: 'audience', title: 'Hedef', prompt: 'Simdi bu kampanyanin kimlere gorunecegini belirle.' },
  { id: 'window', title: 'Zaman ve kanal', prompt: 'Nerede ve ne zaman calisacagini sade tut.' },
  { id: 'condition', title: 'Kosul', prompt: 'Kampanyayi tetikleyecek ana kosulu sec.' },
  { id: 'reward', title: 'Eylem', prompt: 'Kosul saglaninca musteriye ne olacagini tanimla.' },
  { id: 'checkout', title: 'Kasa davranisi', prompt: 'Kampanya kasada otomatik mi, oneri olarak mi, onayla mi ilerlesin?' },
  { id: 'review', title: 'Kontrol', prompt: 'Olusan tanimi oku; eksik kalan davranis varsa buradan geri don.' },
]

const GOAL_OPTIONS = [
  {
    value: 'discount',
    label: 'Sepet indirimini hizli kur',
    text: 'Tutar veya yuzde indirim kampanyalari icin sade akis.',
    recommendedConditions: ['order_total', 'always'],
    recommendedRewards: ['total_order_discount_percent', 'order_discount_amount'],
  },
  {
    value: 'frequency',
    label: 'Tekrar ziyareti artir',
    text: 'Ziyaret sayisi, donem harcamasi veya hediye odul kurgusu.',
    recommendedConditions: ['period_order_count', 'order_total'],
    recommendedRewards: ['free_products', 'bonus_points'],
  },
  {
    value: 'member_value',
    label: 'Uyeye deger kazandir',
    text: 'Puan, kupon veya hak tanimlayan kampanyalar.',
    recommendedConditions: ['birthday', 'coupon_present', 'always'],
    recommendedRewards: ['bonus_points', 'issue_coupon'],
  },
  {
    value: 'basket_growth',
    label: 'Sepeti buyut',
    text: 'Esik tutar, urun grubu veya ek urun onerisi.',
    recommendedConditions: ['order_total', 'order_item_quantity'],
    recommendedRewards: ['free_products', 'warning_message'],
  },
]

const AUDIENCE_OPTIONS = [
  { value: 'all', label: 'Tum musteriler', text: 'Musteri ayrimi yapmadan gecerli olur.' },
  { value: 'members', label: 'Sadakat uyeleri', text: 'Kayitli ve bagli musteriler icin calisir.' },
  { value: 'category', label: 'Secili kategori', text: 'VIP, yeni musteri veya ozel segment gibi kategori hedefi.' },
  { value: 'cashier_pick', label: 'Kasiyer secsin', text: 'Personel kampanyayi uygun musteride elle secer.' },
]

const CHANNEL_OPTIONS = [
  { value: 'all', label: 'Tum kanallar' },
  { value: 'pos', label: 'POS' },
  { value: 'garson', label: 'Garson' },
  { value: 'kiosk', label: 'Kiosk' },
  { value: 'online', label: 'Online' },
]

const WINDOW_OPTIONS = [
  { value: 'always', label: 'Surekli acik', text: 'Baslangic/bitis veya saat araligi olmadan calisir.' },
  { value: 'date_range', label: 'Tarih araligi', text: 'Belirli tarih araliginda yayinda kalir.' },
  { value: 'happy_hour', label: 'Saat araligi', text: 'Gun/saat penceresine gore calisir.', status: 'server' },
]

const CONDITION_OPTIONS = [
  { value: 'always', key: 'always', group: 'Basit', label: 'Ek kosul yok', text: 'Hedef ve kanal uygunsa kampanya calisir.', status: 'local', inputLabel: 'Not', placeholder: 'Orn. tum uygun siparisler' },
  { value: 'calendar_schedule', key: 'calendar_schedule', group: 'Zaman', label: 'Takvim plani', text: 'Gun/hafta/ay/yil takvimine gore kampanya zamanini kontrol eder.', status: 'server', inputLabel: 'Takvim tarifi', placeholder: 'Orn. her pazartesi' },
  { value: 'birthday', key: 'birthday', group: 'Musteri profili', label: 'Dogum gunu', text: 'Musterinin dogum gunu penceresine gore calisir.', status: 'server', inputLabel: 'Pencere', placeholder: 'Orn. once/sonra 7 gun' },
  { value: 'period_total_order_amount', key: 'period_total_order_amount', group: 'Musteri gecmisi', label: 'Donem harcamasi', text: 'Musterinin secili donemdeki toplam harcamasina bakar.', status: 'server', inputLabel: 'Donem ve tutar', placeholder: 'Orn. bu ay 3000 TL' },
  { value: 'period_order_count', key: 'period_order_count', group: 'Musteri gecmisi', label: 'Ziyaret sayisi', text: 'Musterinin donem icindeki siparis sayisina bakar.', status: 'server', inputLabel: 'Donem ve adet', placeholder: 'Orn. bu ay 3 ziyaret' },
  { value: 'period_product_quantity', key: 'period_product_quantity', group: 'Musteri gecmisi', label: 'Donem urun adedi', text: 'Musterinin donemde aldigi urun veya kategori miktarini kontrol eder.', status: 'server', inputLabel: 'Urun/donem/adet', placeholder: 'Orn. bu ay 5 kahve' },
  { value: 'period_sold_product_quantity', key: 'period_sold_product_quantity', group: 'Genel satis', label: 'Genel satis hacmi', text: 'Sube veya genel satis hacmi urun/kategori bazinda esige ulasinca calisir.', status: 'server', inputLabel: 'Hacim esigi', placeholder: 'Orn. bugun 100 burger' },
  { value: 'missing_products', key: 'missing_products', group: 'Sepet', label: 'Sepette eksik urun', text: 'Sepette secili urun veya grup yoksa calisir.', status: 'model', inputLabel: 'Eksik urun', placeholder: 'Orn. icecek yoksa' },
  { value: 'happy_hour', key: 'happy_hour', group: 'Zaman', label: 'Happy hour', text: 'Belirli gun ve saat araliginda calisir.', status: 'server', inputLabel: 'Saat araligi', placeholder: 'Orn. 18:00-20:00' },
  { value: 'gift_card_series', key: 'gift_card_series', group: 'Kupon', label: 'Hediye kart serisi', text: 'Musteri veya kart belirli seriyle eslesirse calisir.', status: 'server', inputLabel: 'Seri', placeholder: 'Orn. GIFT2026' },
  { value: 'campaign_triggered', key: 'campaign_triggered', group: 'Kampanya', label: 'Baska kampanya tetiklendi', text: 'Baska bir kampanya calistiktan sonra zincir kural olarak calisir.', status: 'server', inputLabel: 'Kampanya', placeholder: 'Orn. once VIP indirimi' },
  { value: 'coupon_present', key: 'coupon_present', group: 'Kupon', label: 'Kupon varligi', text: 'Musteride veya sepette belirli kupon varsa calisir.', status: 'server', inputLabel: 'Kupon/seri', placeholder: 'Orn. MAYIS10' },
  { value: 'manual_approval', key: 'manual_approval', group: 'Kasa', label: 'Manuel onay', text: 'Personel kampanyayi elle secip onaylarsa calisir.', status: 'local', inputLabel: 'Onay notu', placeholder: 'Orn. mudur onayi' },
  { value: 'days_since_first_activity', key: 'days_since_first_activity', group: 'Musteri gecmisi', label: 'Ilk aktiviteden beri gun', text: 'Musterinin ilk kayit veya ilk siparisinden beri gecen sureye bakar.', status: 'server', inputLabel: 'Gun esigi', placeholder: 'Orn. ilk 30 gun' },
  { value: 'customer_has_tag', key: 'customer_has_tag', group: 'Musteri profili', label: 'Musteride kategori var', text: 'Bagli musteri secili kategoriye uyuyorsa calisir.', status: 'local', inputLabel: 'Kategori', placeholder: 'Orn. VIP' },
  { value: 'customer_lacks_tag', key: 'customer_lacks_tag', group: 'Musteri profili', label: 'Musteride kategori yok', text: 'Bagli musteri secili kategoride degilse calisir.', status: 'local', inputLabel: 'Kategori', placeholder: 'Orn. ilk kez gelen degil' },
  { value: 'referral_source', key: 'referral_source', group: 'Musteri profili', label: 'Referans kaynagi', text: 'Musteri belirli referans veya davet kaynagindan geldiyse calisir.', status: 'server', inputLabel: 'Referans', placeholder: 'Orn. Instagram / davet kodu' },
  { value: 'sales_channel', key: 'sales_channel', group: 'Kanal', label: 'Satis kanali', text: 'POS, Garson, Kiosk, online veya mobil kanalina gore calisir.', status: 'local', inputLabel: 'Kanal', placeholder: 'Orn. Kiosk' },
  { value: 'order_item_quantity', key: 'order_item_quantity', group: 'Sepet', label: 'Sepette urun adedi', text: 'Secili urun veya kategori sepette yeterli adetteyse calisir.', status: 'model', inputLabel: 'Urun/adet tarifi', placeholder: 'Orn. burger >= 2' },
  { value: 'order_total', key: 'order_total', group: 'Sepet', label: 'Sepet tutari esigi', text: 'Siparis tutari belirlenen esigi gecince calisir.', status: 'local', inputLabel: 'Minimum tutar', placeholder: 'Orn. 500' },
  { value: 'last_visit_days', key: 'last_visit_days', group: 'Musteri gecmisi', label: 'Son ziyaretten beri gun', text: 'Musterinin son siparisinden beri gecen sureye bakar.', status: 'server', inputLabel: 'Gun esigi', placeholder: 'Orn. 45 gundur gelmedi' },
]

const REWARD_OPTIONS = [
  { value: 'free_products', key: 'free_products', group: 'Hediye', label: 'Hediye urun', text: 'Uygun sepete hediye urun teklifi verir.', status: 'local', inputLabel: 'Hediye', placeholder: 'Orn. 1 cay' },
  { value: 'product_pricing', key: 'product_pricing', group: 'Fiyat', label: 'Urun fiyatlandirma', text: 'Secili urune ozel fiyat veya satir indirimi uygular.', status: 'model', inputLabel: 'Fiyat tarifi', placeholder: 'Orn. burger 199 TL' },
  { value: 'combo_bundle', key: 'combo_bundle', group: 'Kombo', label: 'Kombo paket', text: 'Birden fazla urunu paket veya kombo olarak fiyatlar.', status: 'model', inputLabel: 'Kombo tarifi', placeholder: 'Orn. burger + icecek' },
  { value: 'write_customer_note', key: 'write_customer_note', group: 'Musteri', label: 'Musteri notu yaz', text: 'Musteri veya siparis uzerine not kaydi olusturur.', status: 'model', inputLabel: 'Not', placeholder: 'Orn. geri kazanma kampanyasi' },
  { value: 'send_sms', key: 'send_sms', group: 'Mesaj', label: 'SMS gonder', text: 'Musteriye kampanya mesaji yollar.', status: 'model', inputLabel: 'Mesaj', placeholder: 'Orn. kuponunuz hazir' },
  { value: 'send_webhook', key: 'send_webhook', group: 'Entegrasyon', label: 'Webhook gonder', text: 'Harici sistemlere kampanya olayi yollar.', status: 'model', inputLabel: 'Webhook', placeholder: 'Orn. CRM event' },
  { value: 'remove_customer_tag', key: 'remove_customer_tag', group: 'Musteri', label: 'Kategoriden cikar', text: 'Musteriyi secili kategoriden cikarir.', status: 'model', inputLabel: 'Kategori', placeholder: 'Orn. yeni musteri' },
  { value: 'add_customer_tag', key: 'add_customer_tag', group: 'Musteri', label: 'Kategoriye ekle', text: 'Musteriyi secili kategoriye ekler.', status: 'model', inputLabel: 'Kategori', placeholder: 'Orn. VIP aday' },
  { value: 'special_discount', key: 'special_discount', group: 'Indirim', label: 'Ozel indirim', text: 'Kampanyaya ozel tanimli indirim davranisi uygular.', status: 'model', inputLabel: 'Indirim tarifi', placeholder: 'Orn. personel secimli' },
  { value: 'order_extra_charge_amount', key: 'order_extra_charge_amount', group: 'Ek ucret', label: 'Sabit ek ucret', text: 'Siparise sabit ek ucret ekler.', status: 'model', inputLabel: 'Tutar', placeholder: 'Orn. 25' },
  { value: 'order_extra_charge_percent', key: 'order_extra_charge_percent', group: 'Ek ucret', label: 'Yuzdesel ek ucret', text: 'Siparise yuzdesel ek ucret ekler.', status: 'model', inputLabel: 'Yuzde', placeholder: 'Orn. 10' },
  { value: 'total_order_discount_percent', key: 'total_order_discount_percent', group: 'Indirim', label: 'Yuzde indirim', text: 'Sepet toplamindan yuzde indirim uygular.', status: 'local', inputLabel: 'Yuzde', placeholder: 'Orn. 15' },
  { value: 'order_discount_amount', key: 'order_discount_amount', group: 'Indirim', label: 'Tutar indirimi', text: 'Sepet toplamindan sabit tutar duser.', status: 'local', inputLabel: 'Tutar', placeholder: 'Orn. 75' },
  { value: 'suggest_products', key: 'suggest_products', group: 'Oneri', label: 'Urun oner', text: 'Sepete eklenebilecek urun onerisi gosterir.', status: 'model', inputLabel: 'Oneri', placeholder: 'Orn. patates oner' },
  { value: 'bonus_points', key: 'bonus_points', group: 'Puan', label: 'Bonus puan', text: 'Musterinin puan defterine deger yazar.', status: 'ledger', inputLabel: 'Puan', placeholder: 'Orn. 250' },
  { value: 'points_percent_of_order', key: 'points_percent_of_order', group: 'Puan', label: 'Siparisten puan kazandir', text: 'Siparis tutarina gore puan kazandirir.', status: 'ledger', inputLabel: 'Oran', placeholder: 'Orn. tutarin %5i' },
  { value: 'points_earn_multiplier', key: 'points_earn_multiplier', group: 'Puan', label: 'Puan kazanma katsayisi', text: 'Kazanilacak puani belirli katsayi ile carpar.', status: 'ledger', inputLabel: 'Katsayi', placeholder: 'Orn. 2x' },
  { value: 'points_redeem_multiplier', key: 'points_redeem_multiplier', group: 'Puan', label: 'Puan harcama katsayisi', text: 'Puan harcama degerini kampanya icin carpar.', status: 'ledger', inputLabel: 'Katsayi', placeholder: 'Orn. 1.5x' },
  { value: 'issue_coupon', key: 'issue_coupon', group: 'Kupon', label: 'Kupon ver', text: 'Musteriye kullanilabilir kupon olusturur.', status: 'ledger', inputLabel: 'Kupon serisi', placeholder: 'Orn. DOGUMGUNU' },
  { value: 'discount_percent', key: 'discount_percent', group: 'Indirim', label: 'Satir yuzde indirimi', text: 'Urun veya satir bazinda yuzdesel indirim uygular.', status: 'local', inputLabel: 'Yuzde', placeholder: 'Orn. 20' },
  { value: 'warning_message', key: 'warning_message', group: 'Oneri', label: 'Sadece uyari goster', text: 'Kasiyere veya musteriyi yonlendiren mesaj gosterir.', status: 'presentation', inputLabel: 'Mesaj', placeholder: 'Orn. ikinci urunu oner' },
]

const CHECKOUT_OPTIONS = [
  { value: 'ask_cashier', label: 'Kasiyere sor', text: 'Kasa personeli uygun kampanyayi onaylar.' },
  { value: 'auto_apply', label: 'Uygunsa otomatik uygula', text: 'Kosul saglaninca kampanya otomatik islenir.' },
  { value: 'show_suggestion', label: 'Oneri olarak goster', text: 'Kampanya gorunur, kullanici/personel secince uygulanir.' },
]

const INITIAL_DRAFT = {
  goal: 'discount',
  name: 'Aksam Sepeti',
  description: '',
  audience: 'all',
  channel: 'all',
  windowMode: 'always',
  startAt: '',
  endAt: '',
  condition: 'order_total',
  conditionValue: '500',
  reward: 'total_order_discount_percent',
  rewardValue: '15',
  checkoutMode: 'ask_cashier',
  stackRule: 'exclusive',
}

const INITIAL_BLOCKS = [
  {
    id: 'block-1',
    name: 'Ana kosul blogu',
    conditionMode: 'and',
    actionMode: 'sequence',
    conditions: [{ id: 'condition-1', type: 'order_total', value: '500' }],
    actions: [{ id: 'action-1', type: 'total_order_discount_percent', value: '15' }],
  },
]

function getOption(options, value) {
  return options.find(option => option.value === value) || options[0]
}

function getGuidedOptions(options, recommendedValues = [], selectedValue) {
  const recommended = options.filter(option => recommendedValues.includes(option.value))
  const selected = options.find(option => option.value === selectedValue)
  if (selected && !recommended.some(option => option.value === selected.value)) {
    return [selected, ...recommended]
  }
  return recommended.length > 0 ? recommended : options.slice(0, 2)
}

function createCondition(type = 'order_total') {
  const option = getOption(CONDITION_OPTIONS, type)
  return {
    id: `condition-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type,
    value: option.placeholder.replace(/^Orn\. /, ''),
  }
}

function createAction(type = 'total_order_discount_percent') {
  const option = getOption(REWARD_OPTIONS, type)
  return {
    id: `action-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type,
    value: option.placeholder.replace(/^Orn\. /, ''),
  }
}

function describeCondition(item) {
  const option = getOption(CONDITION_OPTIONS, item.type)
  return `${option.label}${item.value ? `: ${item.value}` : ''}`
}

function describeAction(item) {
  const option = getOption(REWARD_OPTIONS, item.type)
  return `${option.label}${item.value ? `: ${item.value}` : ''}`
}

function OptionScopeToggle({ value, onChange, recommendedCount, totalCount }) {
  return (
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: 12 }}>
      <span style={{ fontSize: '.76rem', color: '#64748b', fontWeight: 900 }}>Gosterim:</span>
      <button className={value === 'guided' ? 'btn-p' : 'btn-o'} type="button" onClick={() => onChange('guided')}>
        Onerilenler ({recommendedCount})
      </button>
      <button className={value === 'all' ? 'btn-p' : 'btn-o'} type="button" onClick={() => onChange('all')}>
        Tum kutuphane ({totalCount})
      </button>
    </div>
  )
}

function StatusBadge({ statusKey }) {
  const status = STATUS_META[statusKey] || STATUS_META.model
  return (
    <span
      title={status.detail}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        borderRadius: 999,
        border: `1px solid ${status.border}`,
        background: status.background,
        color: status.color,
        padding: '4px 9px',
        fontSize: '.68rem',
        fontWeight: 900,
        whiteSpace: 'nowrap',
      }}
    >
      {status.label}
    </span>
  )
}

function Panel({ title, children, tone = 'plain' }) {
  const tones = {
    plain: { background: '#fff', border: '#e2e8f0' },
    blue: { background: '#f8fbff', border: '#dbeafe' },
    warm: { background: '#fff7ed', border: '#fed7aa' },
  }
  const palette = tones[tone] || tones.plain
  return (
    <section style={{ border: `1px solid ${palette.border}`, background: palette.background, borderRadius: 8, padding: 16 }}>
      {title ? <div style={{ fontWeight: 900, color: '#0f172a', marginBottom: 12 }}>{title}</div> : null}
      {children}
    </section>
  )
}

function ChoiceButton({ active, title, text, status, group, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        textAlign: 'left',
        borderRadius: 8,
        border: `1px solid ${active ? '#f59e0b' : '#dbeafe'}`,
        background: active ? '#fff7ed' : '#fff',
        padding: 14,
        cursor: 'pointer',
        display: 'grid',
        gap: 8,
        minHeight: 108,
      }}
    >
      <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <span>
          {group ? <span style={{ display: 'block', color: active ? '#c2410c' : '#64748b', fontSize: '.68rem', fontWeight: 900, marginBottom: 4 }}>{group}</span> : null}
          <span style={{ fontWeight: 900, color: active ? '#92400e' : '#0f172a' }}>{title}</span>
        </span>
        {status ? <StatusBadge statusKey={status} /> : null}
      </div>
      <span style={{ fontSize: '.84rem', color: active ? '#9a3412' : '#475569', lineHeight: 1.45 }}>{text}</span>
    </button>
  )
}

function StepRail({ activeStep, completion, onStep }) {
  return (
    <div style={{ display: 'grid', gap: 8 }}>
      {STEPS.map((step, index) => {
        const active = step.id === activeStep
        const done = completion[step.id]
        return (
          <button
            key={step.id}
            type="button"
            onClick={() => onStep(step.id)}
            style={{
              display: 'grid',
              gridTemplateColumns: '32px 1fr',
              gap: 10,
              textAlign: 'left',
              alignItems: 'center',
              padding: 11,
              borderRadius: 8,
              border: `1px solid ${active ? '#fdba74' : '#e2e8f0'}`,
              background: active ? '#fff7ed' : '#fff',
              cursor: 'pointer',
            }}
          >
            <span style={{
              width: 28,
              height: 28,
              borderRadius: 999,
              display: 'grid',
              placeItems: 'center',
              background: active ? '#f59e0b' : (done ? '#2563eb' : '#e2e8f0'),
              color: active || done ? '#fff' : '#64748b',
              fontWeight: 900,
              fontSize: '.78rem',
            }}>
              {index + 1}
            </span>
            <span>
              <span style={{ display: 'block', fontWeight: 900, color: active ? '#92400e' : '#334155' }}>{step.title}</span>
              <span style={{ display: 'block', marginTop: 2, color: '#64748b', fontSize: '.76rem' }}>{done ? 'Tamam' : 'Bekliyor'}</span>
            </span>
          </button>
        )
      })}
    </div>
  )
}

export default function LoyaltyCampaignWizardPreview() {
  const navigate = useNavigate()
  const [draft, setDraft] = useState(INITIAL_DRAFT)
  const [blocks, setBlocks] = useState(INITIAL_BLOCKS)
  const [activeBlockId, setActiveBlockId] = useState(INITIAL_BLOCKS[0].id)
  const [activeStep, setActiveStep] = useState('goal')
  const [conditionScope, setConditionScope] = useState('guided')
  const [rewardScope, setRewardScope] = useState('guided')

  const activeStepIndex = STEPS.findIndex(step => step.id === activeStep)
  const activeStepMeta = STEPS[activeStepIndex] || STEPS[0]
  const goal = getOption(GOAL_OPTIONS, draft.goal)
  const audience = getOption(AUDIENCE_OPTIONS, draft.audience)
  const channel = getOption(CHANNEL_OPTIONS, draft.channel)
  const windowMode = getOption(WINDOW_OPTIONS, draft.windowMode)
  const condition = getOption(CONDITION_OPTIONS, draft.condition)
  const reward = getOption(REWARD_OPTIONS, draft.reward)
  const checkout = getOption(CHECKOUT_OPTIONS, draft.checkoutMode)
  const activeBlock = blocks.find(block => block.id === activeBlockId) || blocks[0]
  const activeCondition = activeBlock?.conditions?.[0] || createCondition(draft.condition)
  const activeAction = activeBlock?.actions?.[0] || createAction(draft.reward)
  const guidedConditions = useMemo(
    () => getGuidedOptions(CONDITION_OPTIONS, goal.recommendedConditions, draft.condition),
    [draft.condition, goal.recommendedConditions],
  )
  const guidedRewards = useMemo(
    () => getGuidedOptions(REWARD_OPTIONS, goal.recommendedRewards, draft.reward),
    [draft.reward, goal.recommendedRewards],
  )
  const visibleConditions = conditionScope === 'all' ? CONDITION_OPTIONS : guidedConditions
  const visibleRewards = rewardScope === 'all' ? REWARD_OPTIONS : guidedRewards

  const completion = useMemo(() => ({
    goal: Boolean(draft.goal && draft.name.trim()),
    audience: Boolean(draft.audience),
    window: Boolean(draft.channel && draft.windowMode),
    condition: blocks.some(block => block.conditions.length > 0),
    reward: blocks.some(block => block.actions.length > 0),
    checkout: Boolean(draft.checkoutMode),
    review: true,
  }), [blocks, draft])

  const runtimeStatuses = useMemo(() => {
    const values = new Set([
      ...blocks.flatMap(block => block.conditions.map(item => getOption(CONDITION_OPTIONS, item.type).status)),
      ...blocks.flatMap(block => block.actions.map(item => getOption(REWARD_OPTIONS, item.type).status)),
      windowMode.status,
    ].filter(Boolean))
    return Array.from(values)
  }, [blocks, windowMode.status])

  const summaryText = useMemo(() => {
    const timing = draft.windowMode === 'always'
      ? 'surekli acik'
      : (draft.windowMode === 'happy_hour' ? 'belirli saat araliginda' : 'belirli tarih araliginda')
    const blockText = blocks.length === 1
      ? `${blocks[0].conditions.length} kosul ve ${blocks[0].actions.length} eylemli tek blog`
      : `${blocks.length} kosul blogu`
    return `${draft.name || 'Yeni kampanya'}, ${audience.label.toLowerCase()} icin ${channel.label.toLowerCase()} kanalinda ${timing}; ${blockText} ile calisir ve kasada ${checkout.label.toLowerCase()} akisiyle ilerler.`
  }, [audience.label, blocks, channel.label, checkout.label, draft.name, draft.windowMode])

  function updateField(key, value) {
    setDraft(current => ({ ...current, [key]: value }))
  }

  function chooseGoal(option) {
    const nextCondition = option.recommendedConditions?.[0] || 'order_total'
    const nextReward = option.recommendedRewards?.[0] || 'total_order_discount_percent'
    setDraft(current => ({
      ...current,
      goal: option.value,
      condition: nextCondition,
      reward: nextReward,
    }))
    setBlocks([{
      ...INITIAL_BLOCKS[0],
      conditions: [createCondition(nextCondition)],
      actions: [createAction(nextReward)],
    }])
    setActiveBlockId(INITIAL_BLOCKS[0].id)
    setConditionScope('guided')
    setRewardScope('guided')
  }

  function updateActiveBlock(patch) {
    setBlocks(current => current.map(block => (
      block.id === activeBlock.id ? { ...block, ...patch } : block
    )))
  }

  function addBlock() {
    const id = `block-${Date.now()}`
    const next = {
      id,
      name: `Kosul blogu ${blocks.length + 1}`,
      conditionMode: 'and',
      actionMode: 'sequence',
      conditions: [createCondition(goal.recommendedConditions?.[0] || 'order_total')],
      actions: [createAction(goal.recommendedRewards?.[0] || 'total_order_discount_percent')],
    }
    setBlocks(current => [...current, next])
    setActiveBlockId(id)
  }

  function removeBlock(blockId) {
    setBlocks(current => {
      const next = current.filter(block => block.id !== blockId)
      if (next.length === 0) return INITIAL_BLOCKS
      if (blockId === activeBlockId) setActiveBlockId(next[0].id)
      return next
    })
  }

  function addConditionToActive(type = draft.condition) {
    updateActiveBlock({
      conditions: [...activeBlock.conditions, createCondition(type)],
    })
  }

  function addActionToActive(type = draft.reward) {
    updateActiveBlock({
      actions: [...activeBlock.actions, createAction(type)],
    })
  }

  function updateConditionItem(itemId, patch) {
    setBlocks(current => current.map(block => (
      block.id !== activeBlock.id
        ? block
        : { ...block, conditions: block.conditions.map(item => (item.id === itemId ? { ...item, ...patch } : item)) }
    )))
  }

  function updateActionItem(itemId, patch) {
    setBlocks(current => current.map(block => (
      block.id !== activeBlock.id
        ? block
        : { ...block, actions: block.actions.map(item => (item.id === itemId ? { ...item, ...patch } : item)) }
    )))
  }

  function removeConditionItem(itemId) {
    if (activeBlock.conditions.length <= 1) return
    updateActiveBlock({
      conditions: activeBlock.conditions.filter(item => item.id !== itemId),
    })
  }

  function removeActionItem(itemId) {
    if (activeBlock.actions.length <= 1) return
    updateActiveBlock({
      actions: activeBlock.actions.filter(item => item.id !== itemId),
    })
  }

  function goStep(direction) {
    const nextIndex = activeStepIndex + direction
    if (nextIndex < 0 || nextIndex >= STEPS.length) return
    setActiveStep(STEPS[nextIndex].id)
  }

  return (
    <div>
      <Header
        title="Akilli Kampanya Kur"
        subtitle="Mevcut kampanya editorunden ayri bir onizleme. Kaydetmez; karar akisinin nasil hissedilecegini gosterir."
        actions={(
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button className="btn-o" type="button" onClick={() => navigate('/sadakat')}>
              <i className="fa-solid fa-arrow-left" style={{ marginRight: 6 }} />
              Sadakat Ekranina Don
            </button>
            <button className="btn-p" type="button" disabled>
              <i className="fa-solid fa-floppy-disk" style={{ marginRight: 6 }} />
              Kaydetme Sonra Baglanacak
            </button>
          </div>
        )}
      />

      <div style={{ display: 'grid', gridTemplateColumns: '260px minmax(0, 1fr) 340px', gap: 16, alignItems: 'start' }}>
        <Panel title="Adimlar">
          <StepRail activeStep={activeStep} completion={completion} onStep={setActiveStep} />
        </Panel>

        <main style={{ display: 'grid', gap: 14 }}>
          <Panel tone="blue">
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start' }}>
              <div>
                <div style={{ fontSize: '.74rem', fontWeight: 900, color: '#2563eb', letterSpacing: '.06em', textTransform: 'uppercase' }}>
                  Adim {activeStepIndex + 1}
                </div>
                <h2 style={{ margin: '6px 0 0', fontSize: '1.35rem', color: '#0f172a', letterSpacing: 0 }}>{activeStepMeta.title}</h2>
                <p style={{ margin: '8px 0 0', color: '#475569', lineHeight: 1.5 }}>{activeStepMeta.prompt}</p>
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                {runtimeStatuses.length === 0 ? <StatusBadge statusKey="local" /> : runtimeStatuses.map(status => <StatusBadge key={status} statusKey={status} />)}
              </div>
            </div>
          </Panel>

          {activeStep === 'goal' ? (
            <Panel title="Kampanya niyeti">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 220px', gap: 12, marginBottom: 12 }}>
                <div>
                  <div className="f-label">Kampanya adi</div>
                  <input className="f-input" value={draft.name} onChange={event => updateField('name', event.target.value)} placeholder="Orn. Aksam Sepeti" />
                </div>
                <div>
                  <div className="f-label">Birlesme kurali</div>
                  <select className="f-input" value={draft.stackRule} onChange={event => updateField('stackRule', event.target.value)}>
                    <option value="exclusive">Tek basina calissin</option>
                    <option value="stackable">Digerleriyle birlessin</option>
                    <option value="group">Ayni grupta en iyisi secilsin</option>
                  </select>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
                {GOAL_OPTIONS.map(option => (
                  <ChoiceButton key={option.value} active={draft.goal === option.value} title={option.label} text={option.text} onClick={() => chooseGoal(option)} />
                ))}
              </div>
            </Panel>
          ) : null}

          {activeStep === 'audience' ? (
            <Panel title="Hedef kitle">
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
                {AUDIENCE_OPTIONS.map(option => (
                  <ChoiceButton key={option.value} active={draft.audience === option.value} title={option.label} text={option.text} onClick={() => updateField('audience', option.value)} />
                ))}
              </div>
            </Panel>
          ) : null}

          {activeStep === 'window' ? (
            <Panel title="Yayin yeri ve zamani">
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, minmax(0, 1fr))', gap: 8, marginBottom: 14 }}>
                {CHANNEL_OPTIONS.map(option => (
                  <button
                    key={option.value}
                    className={draft.channel === option.value ? 'btn-p' : 'btn-o'}
                    type="button"
                    onClick={() => updateField('channel', option.value)}
                    style={{ justifyContent: 'center' }}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 10, marginBottom: 12 }}>
                {WINDOW_OPTIONS.map(option => (
                  <ChoiceButton key={option.value} active={draft.windowMode === option.value} title={option.label} text={option.text} status={option.status} onClick={() => updateField('windowMode', option.value)} />
                ))}
              </div>
              {draft.windowMode !== 'always' ? (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                  <div>
                    <div className="f-label">Baslangic</div>
                    <input className="f-input" value={draft.startAt} onChange={event => updateField('startAt', event.target.value)} placeholder="Orn. 01.06.2026 18:00" />
                  </div>
                  <div>
                    <div className="f-label">Bitis</div>
                    <input className="f-input" value={draft.endAt} onChange={event => updateField('endAt', event.target.value)} placeholder="Orn. 30.06.2026 22:00" />
                  </div>
                </div>
              ) : null}
            </Panel>
          ) : null}

          {activeStep === 'condition' ? (
            <Panel title="Tetikleme kosulu">
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {blocks.map((block, index) => (
                    <button
                      key={block.id}
                      className={block.id === activeBlock.id ? 'btn-p' : 'btn-o'}
                      type="button"
                      onClick={() => setActiveBlockId(block.id)}
                    >
                      Blog {index + 1}
                    </button>
                  ))}
                </div>
                <button className="btn-o" type="button" onClick={addBlock}>
                  <i className="fa-solid fa-plus" style={{ marginRight: 6 }} />
                  Yeni Blog
                </button>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 10, alignItems: 'end', marginBottom: 12 }}>
                <div>
                  <div className="f-label">Aktif blog adi</div>
                  <input className="f-input" value={activeBlock.name} onChange={event => updateActiveBlock({ name: event.target.value })} />
                </div>
                <div>
                  <div className="f-label">Kosullar nasil baglansin?</div>
                  <select className="f-input" value={activeBlock.conditionMode} onChange={event => updateActiveBlock({ conditionMode: event.target.value })}>
                    <option value="and">Hepsi gerekli (VE)</option>
                    <option value="or">Herhangi biri yeterli (VEYA)</option>
                  </select>
                </div>
                <button className="btn-o" type="button" onClick={() => removeBlock(activeBlock.id)} disabled={blocks.length <= 1}>
                  Blogu Sil
                </button>
              </div>
              <OptionScopeToggle
                value={conditionScope}
                onChange={setConditionScope}
                recommendedCount={guidedConditions.length}
                totalCount={CONDITION_OPTIONS.length}
              />
              <div style={{ borderRadius: 8, background: '#f8fafc', border: '1px solid #e2e8f0', padding: 12, color: '#475569', fontSize: '.84rem', lineHeight: 1.55, marginBottom: 12 }}>
                {conditionScope === 'guided'
                  ? `${goal.label} icin once en uygun kosullari gosteriyorum. Diger kosullar sakli kalsin; gerekiyorsa tum kutuphaneyi ac.`
                  : 'Tum kosullar acik. Bu mod daha esnek ama kullanici icin daha yogun.'}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
                {visibleConditions.map(option => (
                  <ChoiceButton
                    key={option.value}
                    active={draft.condition === option.value}
                    title={option.label}
                    text={option.text}
                    status={option.status}
                    group={option.group}
                    onClick={() => {
                      updateField('condition', option.value)
                      if (activeBlock.conditions.length === 1) {
                        updateConditionItem(activeBlock.conditions[0].id, { type: option.value, value: option.placeholder.replace(/^Orn\. /, '') })
                      } else {
                        addConditionToActive(option.value)
                      }
                    }}
                  />
                ))}
              </div>
              <div style={{ marginTop: 14, border: '1px solid #dbeafe', borderRadius: 8, padding: 12, background: '#f8fbff' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center', marginBottom: 10 }}>
                  <div style={{ fontWeight: 900, color: '#1e3a8a' }}>Bu blogdaki kosullar</div>
                  <button className="btn-o" type="button" onClick={() => addConditionToActive(goal.recommendedConditions?.[0] || 'order_total')}>
                    <i className="fa-solid fa-plus" style={{ marginRight: 6 }} />
                    Kosul Ekle
                  </button>
                </div>
                <div style={{ display: 'grid', gap: 8 }}>
                  {activeBlock.conditions.map((item, index) => {
                    const itemOption = getOption(CONDITION_OPTIONS, item.type)
                    return (
                      <div key={item.id} style={{ display: 'grid', gridTemplateColumns: 'minmax(180px, 240px) 1fr auto', gap: 8, alignItems: 'center', border: '1px solid #dbeafe', borderRadius: 8, padding: 10, background: '#fff' }}>
                        <div>
                          <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 6 }}>
                            {index > 0 ? <span style={{ color: '#2563eb', fontSize: '.72rem', fontWeight: 900 }}>{activeBlock.conditionMode === 'and' ? 'VE' : 'VEYA'}</span> : null}
                            <StatusBadge statusKey={itemOption.status} />
                          </div>
                          <select className="f-input" value={item.type} onChange={event => updateConditionItem(item.id, { type: event.target.value, value: getOption(CONDITION_OPTIONS, event.target.value).placeholder.replace(/^Orn\. /, '') })}>
                            {CONDITION_OPTIONS.map(option => <option key={option.value} value={option.value}>{`${option.group} - ${option.label}`}</option>)}
                          </select>
                        </div>
                        <div>
                          <div className="f-label">{itemOption.inputLabel}</div>
                          <input className="f-input" value={item.value} onChange={event => updateConditionItem(item.id, { value: event.target.value })} placeholder={itemOption.placeholder} />
                        </div>
                        <button className="btn-o" type="button" onClick={() => removeConditionItem(item.id)} disabled={activeBlock.conditions.length <= 1}>
                          Sil
                        </button>
                      </div>
                    )
                  })}
                </div>
              </div>
            </Panel>
          ) : null}

          {activeStep === 'reward' ? (
            <Panel title="Kampanya eylemi">
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {blocks.map((block, index) => (
                    <button
                      key={block.id}
                      className={block.id === activeBlock.id ? 'btn-p' : 'btn-o'}
                      type="button"
                      onClick={() => setActiveBlockId(block.id)}
                    >
                      Blog {index + 1}
                    </button>
                  ))}
                </div>
                <div style={{ color: '#64748b', fontSize: '.8rem', fontWeight: 800 }}>
                  Eylemler secili blog kosullari saglaninca calisir.
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 10, alignItems: 'end', marginBottom: 12 }}>
                <div>
                  <div className="f-label">Eylemler nasil uygulansin?</div>
                  <select className="f-input" value={activeBlock.actionMode} onChange={event => updateActiveBlock({ actionMode: event.target.value })}>
                    <option value="sequence">Sirayla uygula</option>
                    <option value="best">En iyi eylemi sec</option>
                    <option value="ask">Kasiyere sectir</option>
                  </select>
                </div>
                <button className="btn-o" type="button" onClick={() => addActionToActive(goal.recommendedRewards?.[0] || 'total_order_discount_percent')}>
                  <i className="fa-solid fa-plus" style={{ marginRight: 6 }} />
                  Eylem Ekle
                </button>
              </div>
              <OptionScopeToggle
                value={rewardScope}
                onChange={setRewardScope}
                recommendedCount={guidedRewards.length}
                totalCount={REWARD_OPTIONS.length}
              />
              <div style={{ borderRadius: 8, background: '#f8fafc', border: '1px solid #e2e8f0', padding: 12, color: '#475569', fontSize: '.84rem', lineHeight: 1.55, marginBottom: 12 }}>
                {rewardScope === 'guided'
                  ? `${goal.label} icin once en uygun eylemleri gosteriyorum. Puan, kupon veya mesaj gibi yan yollar gerekli olursa tum kutuphane acilir.`
                  : 'Tum eylemler acik. Her eylemin tanimi farkli oldugu icin bu mod daha dikkatli kullanilmali.'}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
                {visibleRewards.map(option => (
                  <ChoiceButton
                    key={option.value}
                    active={draft.reward === option.value}
                    title={option.label}
                    text={option.text}
                    status={option.status}
                    group={option.group}
                    onClick={() => {
                      updateField('reward', option.value)
                      if (activeBlock.actions.length === 1) {
                        updateActionItem(activeBlock.actions[0].id, { type: option.value, value: option.placeholder.replace(/^Orn\. /, '') })
                      } else {
                        addActionToActive(option.value)
                      }
                    }}
                  />
                ))}
              </div>
              <div style={{ marginTop: 14, border: '1px solid #fed7aa', borderRadius: 8, padding: 12, background: '#fff7ed' }}>
                <div style={{ fontWeight: 900, color: '#9a3412', marginBottom: 10 }}>Bu blogdaki eylemler</div>
                <div style={{ display: 'grid', gap: 8 }}>
                  {activeBlock.actions.map((item, index) => {
                    const itemOption = getOption(REWARD_OPTIONS, item.type)
                    return (
                      <div key={item.id} style={{ display: 'grid', gridTemplateColumns: 'minmax(180px, 240px) 1fr auto', gap: 8, alignItems: 'center', border: '1px solid #fed7aa', borderRadius: 8, padding: 10, background: '#fff' }}>
                        <div>
                          <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 6 }}>
                            {index > 0 ? <span style={{ color: '#c2410c', fontSize: '.72rem', fontWeight: 900 }}>{activeBlock.actionMode === 'sequence' ? 'SONRA' : (activeBlock.actionMode === 'best' ? 'VEYA' : 'SECIM')}</span> : null}
                            <StatusBadge statusKey={itemOption.status} />
                          </div>
                          <select className="f-input" value={item.type} onChange={event => updateActionItem(item.id, { type: event.target.value, value: getOption(REWARD_OPTIONS, event.target.value).placeholder.replace(/^Orn\. /, '') })}>
                            {REWARD_OPTIONS.map(option => <option key={option.value} value={option.value}>{`${option.group} - ${option.label}`}</option>)}
                          </select>
                        </div>
                        <div>
                          <div className="f-label">{itemOption.inputLabel}</div>
                          <input className="f-input" value={item.value} onChange={event => updateActionItem(item.id, { value: event.target.value })} placeholder={itemOption.placeholder} />
                        </div>
                        <button className="btn-o" type="button" onClick={() => removeActionItem(item.id)} disabled={activeBlock.actions.length <= 1}>
                          Sil
                        </button>
                      </div>
                    )
                  })}
                </div>
              </div>
            </Panel>
          ) : null}

          {activeStep === 'checkout' ? (
            <Panel title="Kasa davranisi">
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 10 }}>
                {CHECKOUT_OPTIONS.map(option => (
                  <ChoiceButton key={option.value} active={draft.checkoutMode === option.value} title={option.label} text={option.text} onClick={() => updateField('checkoutMode', option.value)} />
                ))}
              </div>
            </Panel>
          ) : null}

          {activeStep === 'review' ? (
            <Panel title="Son kontrol" tone="warm">
              <div style={{ display: 'grid', gap: 12 }}>
                <div style={{ color: '#7c2d12', fontWeight: 800, lineHeight: 1.6 }}>{summaryText}</div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {runtimeStatuses.map(status => <StatusBadge key={status} statusKey={status} />)}
                  {windowMode.status ? <StatusBadge statusKey={windowMode.status} /> : null}
                </div>
                <div style={{ borderTop: '1px solid #fed7aa', paddingTop: 12, color: '#9a3412', fontSize: '.86rem', lineHeight: 1.55 }}>
                  Bu onizleme henuz kaydetmez. Gercek kullanima alinirken bu taslak mevcut kampanya kayit modeline cevrilecek ve motor eksik/deger defteri isteyen secimler icin ayri uygulama paketi acilacak.
                </div>
              </div>
            </Panel>
          ) : null}

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
            <button className="btn-o" type="button" onClick={() => goStep(-1)} disabled={activeStepIndex === 0}>
              Onceki
            </button>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn-o" type="button" onClick={() => setDraft(INITIAL_DRAFT)}>
                Sifirla
              </button>
              <button className="btn-p" type="button" onClick={() => goStep(1)} disabled={activeStepIndex === STEPS.length - 1}>
                Bu tamam, devam et
              </button>
            </div>
          </div>
        </main>

        <aside style={{ display: 'grid', gap: 14 }}>
          <Panel title="Biriken tanim" tone="warm">
            <div style={{ color: '#7c2d12', fontWeight: 800, lineHeight: 1.6, marginBottom: 14 }}>{summaryText}</div>
            <div style={{ display: 'grid', gap: 8 }}>
              {[
                ['Amac', goal.label],
                ['Hedef', audience.label],
                ['Kanal', channel.label],
                ['Zaman', windowMode.label],
                ['Blog', `${blocks.length} blog / ${blocks.reduce((total, block) => total + block.conditions.length, 0)} kosul / ${blocks.reduce((total, block) => total + block.actions.length, 0)} eylem`],
                ['Kasa', checkout.label],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'grid', gridTemplateColumns: '82px 1fr', gap: 8, alignItems: 'start', borderTop: '1px solid #fed7aa', paddingTop: 8 }}>
                  <span style={{ color: '#c2410c', fontWeight: 900, fontSize: '.76rem' }}>{label}</span>
                  <span style={{ color: '#7c2d12', fontWeight: 700, lineHeight: 1.45 }}>{value}</span>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Kosul ve eylem bloklari">
            <div style={{ display: 'grid', gap: 10 }}>
              {blocks.map((block, index) => (
                <div key={block.id} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: 10, background: block.id === activeBlock.id ? '#f8fbff' : '#fff' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                    <button type="button" className={block.id === activeBlock.id ? 'btn-p' : 'btn-o'} onClick={() => setActiveBlockId(block.id)}>
                      Blog {index + 1}
                    </button>
                    <span style={{ fontSize: '.72rem', color: '#64748b', fontWeight: 900 }}>
                      {block.conditionMode === 'and' ? 'VE' : 'VEYA'} / {block.actionMode === 'sequence' ? 'Sirali' : (block.actionMode === 'best' ? 'En iyi' : 'Secimli')}
                    </span>
                  </div>
                  <div style={{ color: '#334155', fontSize: '.8rem', lineHeight: 1.5 }}>
                    <strong>Kosul:</strong> {block.conditions.map(describeCondition).join(block.conditionMode === 'and' ? ' + ' : ' veya ')}
                  </div>
                  <div style={{ color: '#334155', fontSize: '.8rem', lineHeight: 1.5, marginTop: 6 }}>
                    <strong>Eylem:</strong> {block.actions.map(describeAction).join(block.actionMode === 'sequence' ? ' sonra ' : ' veya ')}
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Davranis uyarilari">
            <div style={{ display: 'grid', gap: 10 }}>
              {[...new Set([...runtimeStatuses, windowMode.status].filter(Boolean))].map(status => (
                <div key={status} style={{ borderRadius: 8, border: `1px solid ${STATUS_META[status].border}`, background: STATUS_META[status].background, color: STATUS_META[status].color, padding: 10 }}>
                  <div style={{ marginBottom: 6 }}><StatusBadge statusKey={status} /></div>
                  <div style={{ fontSize: '.8rem', fontWeight: 700, lineHeight: 1.45 }}>{STATUS_META[status].detail}</div>
                </div>
              ))}
            </div>
          </Panel>
        </aside>
      </div>
    </div>
  )
}
