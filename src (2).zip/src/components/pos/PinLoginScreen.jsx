export default function PinLoginScreen({
  title,
  subtitle,
  branchName,
  pin,
  error,
  loading = false,
  onPinChange,
  onSubmit,
  onClose,
}) {
  const keypad = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'sil', '0']

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      zIndex: 500,
      background: 'radial-gradient(circle at top, rgba(30,41,99,.9), rgba(3,7,30,.98))',
      display: 'grid',
      placeItems: 'center',
      padding: 24,
    }}>
      <div style={{
        width: 'min(560px, 100%)',
        borderRadius: 28,
        border: '1px solid rgba(148,163,184,.18)',
        background: 'linear-gradient(180deg, rgba(15,23,42,.94), rgba(7,13,36,.98))',
        boxShadow: '0 30px 90px rgba(2,6,23,.42)',
        padding: 28,
        display: 'grid',
        gap: 20,
      }}>
        <div>
          <div style={{ display:'flex', justifyContent:'space-between', gap:12, alignItems:'flex-start' }}>
            <div>
              <div style={{ color: '#fbbf24', fontSize: '.75rem', fontWeight: 900, letterSpacing: '.14em', textTransform: 'uppercase' }}>
                Personel PIN
              </div>
              <div style={{ color: '#fff', fontSize: '1.5rem', fontWeight: 900, marginTop: 8 }}>
                {title}
              </div>
            </div>
            {typeof onClose === 'function' && (
              <button
                type="button"
                onClick={onClose}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 999,
                  border: '1px solid rgba(148,163,184,.2)',
                  background: 'rgba(15,23,42,.52)',
                  color: '#cbd5e1',
                  cursor: 'pointer',
                  fontSize: '1.1rem',
                  fontWeight: 900,
                }}
              >
                ×
              </button>
            )}
          </div>
          <div style={{ color: '#94a3b8', lineHeight: 1.6, marginTop: 8 }}>
            {subtitle}
          </div>
          {branchName && (
            <div style={{ color: '#7dd3fc', fontWeight: 800, marginTop: 10 }}>
              {branchName}
            </div>
          )}
        </div>

        <div style={{
          minHeight: 72,
          borderRadius: 18,
          border: `1px solid ${error ? 'rgba(248,113,113,.42)' : 'rgba(251,191,36,.2)'}`,
          background: error ? 'rgba(127,29,29,.26)' : 'rgba(15,23,42,.68)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#fff',
          fontSize: '1.9rem',
          fontWeight: 900,
          letterSpacing: '.24em',
        }}>
          {(pin || '').padEnd(4, '•')}
        </div>

        {error && (
          <div style={{ color: '#fca5a5', fontSize: '.84rem', fontWeight: 700 }}>
            {error}
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 10 }}>
          {keypad.map(key => (
            <button
              key={key}
              type="button"
              disabled={loading}
              onClick={() => {
                if (key === 'sil') {
                  onPinChange((pin || '').slice(0, -1))
                  return
                }
                onPinChange(`${pin || ''}${key}`)
              }}
              style={{
                minHeight: 58,
                borderRadius: 16,
                border: '1px solid rgba(148,163,184,.18)',
                background: key === 'sil' ? 'rgba(239,68,68,.14)' : 'rgba(30,41,59,.78)',
                color: key === 'sil' ? '#fca5a5' : '#fff',
                fontWeight: 900,
                fontSize: key === 'sil' ? '.9rem' : '1.15rem',
                cursor: loading ? 'not-allowed' : 'pointer',
              }}
            >
              {key === 'sil' ? 'Sil' : key}
            </button>
          ))}
        </div>

        <button
          type="button"
          disabled={loading || (pin || '').length < 4}
          onClick={onSubmit}
          style={{
            minHeight: 56,
            borderRadius: 16,
            border: 'none',
            background: loading ? 'rgba(255,255,255,.12)' : 'linear-gradient(135deg,#f59e0b,#fbbf24)',
            color: loading ? 'rgba(255,255,255,.45)' : '#111827',
            fontWeight: 900,
            fontSize: '1rem',
            cursor: loading ? 'not-allowed' : 'pointer',
          }}
        >
          {loading ? 'Kontrol Ediliyor...' : 'Giris Yap'}
        </button>

      </div>
    </div>
  )
}
