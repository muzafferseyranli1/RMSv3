import { useWorkspace } from '@/context/WorkspaceContext'
import { getWorkspaceScopeOption, isBranchScopedScope } from '@/lib/workspace'
import { useSidebar } from '@/context/SidebarContext'

function chipStyle(background, color) {
  return {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    padding: '4px 10px',
    borderRadius: 999,
    background,
    color,
    fontSize: '.72rem',
    fontWeight: 800,
  }
}

export default function Header({ title, subtitle, actions }) {
  const { scope, branchName } = useWorkspace()
  const scopeOption = getWorkspaceScopeOption(scope)
  const showBranchChip = isBranchScopedScope(scope) && branchName
  const sidebar = useSidebar()

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      marginBottom: 20, background: 'var(--topbar-bg)',
      borderBottom: '0.5px solid var(--border)',
      padding: '12px 0 16px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {sidebar?.mode === 'closed' && (
          <button
            type="button"
            aria-label="Yan menuyu ac"
            onClick={() => sidebar.setMobileOpen(open => !open)}
            style={{
              width: 36, height: 36, border: 'none', borderRadius: 8,
              background: 'var(--surface-2)', color: 'var(--text-muted)',
              cursor: 'pointer', display: 'flex', alignItems: 'center',
              justifyContent: 'center', flexShrink: 0, fontSize: '.85rem',
            }}
          >
            <i className="fa-solid fa-bars" />
          </button>
        )}
        {sidebar?.mode === 'icon' && (
          <button
            type="button"
            aria-label="Sidebar'i genislet"
            onClick={() => sidebar.togglePin()}
            style={{
              width: 32, height: 32, border: 'none', borderRadius: 7,
              background: 'var(--surface-2)', color: 'var(--text-muted)',
              cursor: 'pointer', display: 'flex', alignItems: 'center',
              justifyContent: 'center', flexShrink: 0, fontSize: '.75rem',
            }}
          >
            <i className="fa-solid fa-angles-right" />
          </button>
        )}
        <div>
          <h1 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-strong)', margin: 0 }}>{title}</h1>
          {subtitle && <p style={{ fontSize: '.8rem', color: 'var(--text-muted)', margin: '4px 0 0' }}>{subtitle}</p>}
          {(scopeOption || showBranchChip) && (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
              {scopeOption && (
                <span style={chipStyle(scopeOption.bg, scopeOption.accent)}>
                  <i className={`fa-solid ${scopeOption.icon}`} />
                  {scopeOption.label}
                </span>
              )}
              {showBranchChip && (
                <span style={chipStyle('rgba(245,158,11,.1)', 'var(--warning)')}>
                  <i className="fa-solid fa-location-dot" />
                  {branchName}
                </span>
              )}
            </div>
          )}
        </div>
      </div>
      {actions && <div style={{ display: 'flex', gap: 8 }}>{actions}</div>}
    </div>
  )
}
