import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist/legacy/build/pdf.mjs'
import pdfWorker from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url'
import {
  TABLE_LAYOUT_UPDATED_EVENT,
  hydrateTableLayoutFromDb,
  readLocalLayoutSnapshot,
} from '@/lib/posTablePersistence'

GlobalWorkerOptions.workerSrc = pdfWorker

const DEFAULT_FLOOR_COLOR = '#0b173a'

const STATUS_META = {
  empty: { label: 'Bos', code: 'y', color: '#22c55e' },
  occupied: { label: 'Dolu', code: 'k', color: '#ef4444' },
  reserved: { label: 'Rezerve', code: 'm', color: '#3b82f6' },
}

const SHAPE_META = {
  round: { label: 'Yuvarlak', code: 'y' },
  square: { label: 'Kare', code: 'k' },
}

const PRESET_ASSETS = Array.from({ length: 10 }, (_, index) => index + 1).flatMap(seats =>
  Object.entries(SHAPE_META).flatMap(([shape, shapeMeta]) =>
    Object.entries(STATUS_META).map(([status, statusMeta]) => ({
      id: `${shapeMeta.code}${seats}-${statusMeta.code}`,
      shape,
      seats,
      status,
      label: `${shapeMeta.label} ${seats} Kisilik ${statusMeta.label}`,
      src: `/assets/masa-icons/${shapeMeta.code}${seats}-${statusMeta.code}.pdf`,
    })),
  ),
)

const PRESET_BY_ID = new Map(PRESET_ASSETS.map(asset => [asset.id, asset]))
const PDF_CACHE = new Map()
const PDF_PROMISES = new Map()

function uid(prefix) {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}`
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value))
}

function clampSeatCount(value) {
  return clamp(Number(value) || 1, 1, 10)
}

function getTableSize(shape, seats) {
  const safeSeats = clampSeatCount(seats)
  const base = shape === 'square' ? 10 + safeSeats * 1.9 : 11 + safeSeats * 2.1
  const size = clamp(base, 14, 34)
  return { w: size, h: size }
}

function getPreset(shape, seats, status = 'empty') {
  const safeShape = SHAPE_META[shape] ? shape : 'round'
  const safeSeats = clampSeatCount(seats)
  const safeStatus = STATUS_META[status] ? status : 'empty'
  return PRESET_BY_ID.get(`${SHAPE_META[safeShape].code}${safeSeats}-${STATUS_META[safeStatus].code}`) || null
}

function createZone(index) {
  return {
    id: uid('zone'),
    name: `Bolge ${index}`,
    x: 8 + ((index - 1) % 3) * 8,
    y: 10 + ((index - 1) % 2) * 7,
    w: 30,
    h: 24,
    color: '#38bdf8',
    opacity: 0.14,
  }
}

function createTable(index, options = {}) {
  const shape = SHAPE_META[options.shape] ? options.shape : 'round'
  const seats = clampSeatCount(options.seats ?? 4)
  const status = STATUS_META[options.status] ? options.status : 'empty'
  const size = getTableSize(shape, seats)
  return {
    id: uid('table'),
    name: options.name || `Masa ${String(index).padStart(2, '0')}`,
    shape,
    seats,
    status,
    x: 18 + ((index - 1) % 4) * 16,
    y: 18 + ((index - 1) % 3) * 16,
    w: size.w,
    h: size.h,
    zoneId: options.zoneId || '',
  }
}

function createFloor(index) {
  const zone = createZone(1)
  return {
    id: uid('floor'),
    name: `Kat ${index}`,
    bgColor: DEFAULT_FLOOR_COLOR,
    bgImage: '',
    zones: [zone],
    tables: [
      createTable(1, { shape: 'round', seats: 4, zoneId: zone.id }),
      createTable(2, { shape: 'square', seats: 4, zoneId: zone.id }),
      createTable(3, { shape: 'round', seats: 6 }),
    ],
  }
}

function getDefaultEditor() {
  const firstFloor = createFloor(1)
  const secondFloor = createFloor(2)
  secondFloor.name = 'Teras'
  secondFloor.bgColor = '#12203f'
  secondFloor.zones[0].name = 'Dis Alan'
  secondFloor.tables[0].name = 'Teras 01'
  secondFloor.tables[1].name = 'Teras 02'
  secondFloor.tables[2].name = 'Teras 03'
  return { activeFloorId: firstFloor.id, floors: [firstFloor, secondFloor] }
}

function normalizeEditor(raw) {
  if (!raw || !Array.isArray(raw.floors) || raw.floors.length === 0) return getDefaultEditor()
  const floors = raw.floors.map((floor, floorIndex) => ({
    id: floor.id || uid('floor'),
    name: floor.name || `Kat ${floorIndex + 1}`,
    bgColor: floor.bgColor || DEFAULT_FLOOR_COLOR,
    bgImage: floor.bgImage || '',
    zones: Array.isArray(floor.zones)
      ? floor.zones.map((zone, zoneIndex) => ({
        id: zone.id || uid('zone'),
        name: zone.name || `Bolge ${zoneIndex + 1}`,
        x: Number.isFinite(zone.x) ? zone.x : 10,
        y: Number.isFinite(zone.y) ? zone.y : 10,
        w: Number.isFinite(zone.w) ? zone.w : 30,
        h: Number.isFinite(zone.h) ? zone.h : 24,
        color: zone.color || '#38bdf8',
        opacity: Number.isFinite(zone.opacity) ? zone.opacity : 0.14,
      }))
      : [],
    tables: Array.isArray(floor.tables)
      ? floor.tables.map((table, tableIndex) => {
        const shape = SHAPE_META[table.shape] ? table.shape : 'round'
        const seats = clampSeatCount(table.seats ?? 4)
        const size = getTableSize(shape, seats)
        return {
          id: table.id || uid('table'),
          name: table.name || `Masa ${tableIndex + 1}`,
          shape,
          seats,
          status: STATUS_META[table.status] ? table.status : 'empty',
          x: Number.isFinite(table.x) ? table.x : 20,
          y: Number.isFinite(table.y) ? table.y : 20,
          w: Number.isFinite(table.w) ? table.w : size.w,
          h: Number.isFinite(table.h) ? table.h : size.h,
          zoneId: table.zoneId || '',
        }
      })
      : [],
  }))
  const activeFloorId = floors.some(floor => floor.id === raw.activeFloorId) ? raw.activeFloorId : floors[0].id
  return { activeFloorId, floors }
}

async function renderPdfPreview(src) {
  if (!src) return ''
  if (PDF_CACHE.has(src)) return PDF_CACHE.get(src)
  if (PDF_PROMISES.has(src)) return PDF_PROMISES.get(src)

  const promise = (async () => {
    const pdf = await getDocument(src).promise
    const page = await pdf.getPage(1)
    const viewport = page.getViewport({ scale: 1.8 })
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('2d', { alpha: true })

    canvas.width = Math.ceil(viewport.width)
    canvas.height = Math.ceil(viewport.height)

    await page.render({
      canvasContext: context,
      viewport,
      background: 'rgba(0,0,0,0)',
    }).promise

    const dataUrl = canvas.toDataURL('image/png')
    PDF_CACHE.set(src, dataUrl)
    PDF_PROMISES.delete(src)
    return dataUrl
  })().catch(error => {
    PDF_PROMISES.delete(src)
    throw error
  })

  PDF_PROMISES.set(src, promise)
  return promise
}

function usePdfPreview(src) {
  const [preview, setPreview] = useState(() => (src && PDF_CACHE.has(src) ? PDF_CACHE.get(src) : ''))

  useEffect(() => {
    let cancelled = false

    if (!src) {
      setPreview('')
      return undefined
    }

    if (PDF_CACHE.has(src)) {
      setPreview(PDF_CACHE.get(src))
      return undefined
    }

    renderPdfPreview(src)
      .then(dataUrl => {
        if (!cancelled) setPreview(dataUrl)
      })
      .catch(() => {
        if (!cancelled) setPreview('')
      })

    return () => {
      cancelled = true
    }
  }, [src])

  return preview
}

function TablePresetGraphic({ table }) {
  const preset = getPreset(table.shape, table.seats, table.status)
  const preview = usePdfPreview(preset?.src || '')

  if (!preview) {
    return (
      <div style={{
        width: '100%',
        height: '100%',
        borderRadius: 999,
        background: 'radial-gradient(circle, rgba(148,163,184,.36), rgba(15,23,42,.1))',
        opacity: 0.55,
      }} />
    )
  }

  return <img src={preview} alt={preset?.label || table.name} draggable="false" style={{ width: '100%', height: '100%', objectFit: 'contain', pointerEvents: 'none', filter: 'drop-shadow(0 10px 16px rgba(7,16,53,.28))' }} />
}

function getMasaValue(tableName) {
  const match = String(tableName || '').match(/(\d+)/)
  if (match?.[1]) return match[1].padStart(2, '0')
  return String(tableName || '').slice(0, 8) || '01'
}

function matchesMasa(table, masaNo) {
  if (!table || !masaNo) return false
  return getMasaValue(table.name) === String(masaNo).trim()
}

function getTableKey(table, floorName = '', tableIndex = 0) {
  const rawId = String(table?.id || '').trim()
  if (rawId) return rawId
  const label = String(table?.name || '').trim() || `Masa ${getMasaValue(tableIndex + 1)}`
  return `${floorName || 'Kat'}::${label}::${tableIndex}`
}

function getTableDescriptor(table, floorName = '', tableIndex = 0) {
  const masaNo = getMasaValue(table?.name || tableIndex + 1)
  return {
    tableKey: getTableKey(table, floorName, tableIndex),
    masaNo,
    label: String(table?.name || '').trim() || `Masa ${masaNo}`,
  }
}

function ViewModeToggle({ value, onChange }) {
  const options = [
    { key: 'layout', label: 'Kroki' },
    { key: 'simple', label: 'Basit' },
  ]

  return (
    <div style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: 4,
      borderRadius: 999,
      border: '1px solid rgba(148,163,184,.2)',
      background: 'rgba(15,23,42,.42)',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,.04)',
      flexShrink: 0,
    }}>
      {options.map(option => {
        const active = value === option.key
        return (
          <button
            key={option.key}
            type="button"
            onClick={() => onChange?.(option.key)}
            style={{
              minHeight: 38,
              minWidth: 88,
              padding: '0 16px',
              borderRadius: 999,
              border: 'none',
              background: active ? 'linear-gradient(135deg,#fbbf24,#f59e0b)' : 'transparent',
              color: active ? '#071035' : '#dbeafe',
              fontWeight: 900,
              cursor: 'pointer',
              transition: '.15s ease',
            }}
          >
            {option.label}
          </button>
        )
      })}
    </div>
  )
}

export default function GarsonTableLayout({ masaNo, selectedTableKey = '', occupiedTableKeys = [], coverCountByTable = {}, onSelectTable }) {
  const navigate = useNavigate()
  const initialEditor = useMemo(() => normalizeEditor(readLocalLayoutSnapshot()), [])
  const [savedEditor, setSavedEditor] = useState(() => initialEditor)
  const [activeFloorId, setActiveFloorId] = useState(() => initialEditor?.activeFloorId || '')
  const [selectedTableId, setSelectedTableId] = useState('')
  const [viewMode, setViewMode] = useState('layout')
  const hasSavedLayout = (savedEditor?.floors?.length || 0) > 0
  const occupiedTableSet = useMemo(
    () => new Set((occupiedTableKeys || []).map(tableKey => String(tableKey || '').trim()).filter(Boolean)),
    [occupiedTableKeys],
  )

  useEffect(() => {
    let cancelled = false

    function applyEditor(nextEditor) {
      setSavedEditor(nextEditor)
      setActiveFloorId(current => nextEditor?.floors?.some(floor => floor.id === current) ? current : (nextEditor?.activeFloorId || ''))
    }

    hydrateTableLayoutFromDb()
      .then(layoutValue => {
        if (cancelled || !layoutValue) return
        applyEditor(normalizeEditor(layoutValue))
      })
      .catch(error => {
        if (!cancelled) console.error('GarsonTableLayout hydrate failed', error)
      })

    const handleLayoutUpdated = () => {
      hydrateTableLayoutFromDb()
        .then(layoutValue => {
          if (!layoutValue) return
          applyEditor(normalizeEditor(layoutValue))
        })
        .catch(error => console.error('GarsonTableLayout refresh failed', error))
    }

    window.addEventListener(TABLE_LAYOUT_UPDATED_EVENT, handleLayoutUpdated)
    return () => {
      cancelled = true
      window.removeEventListener(TABLE_LAYOUT_UPDATED_EVENT, handleLayoutUpdated)
    }
  }, [])

  const activeFloor = useMemo(
    () => savedEditor?.floors?.find(floor => floor.id === activeFloorId) || savedEditor?.floors?.[0] || null,
    [activeFloorId, savedEditor],
  )

  const selectedTable = useMemo(
    () => activeFloor?.tables.find(table => table.id === selectedTableId) || activeFloor?.tables[0] || null,
    [activeFloor, selectedTableId],
  )

  useEffect(() => {
    if (!activeFloor) {
      setSelectedTableId('')
      return
    }
    const matchingTable = activeFloor.tables.find((table, tableIndex) => {
      const descriptor = getTableDescriptor(table, activeFloor.name, tableIndex)
      if (selectedTableKey) return descriptor.tableKey === selectedTableKey
      return matchesMasa(table, masaNo)
    })
    if (matchingTable) {
      setSelectedTableId(matchingTable.id)
      return
    }
    setSelectedTableId(current => activeFloor.tables.some(table => table.id === current) ? current : (activeFloor.tables[0]?.id || ''))
  }, [activeFloor, masaNo, selectedTableKey])

  function handleTableClick(table, tableIndex) {
    setSelectedTableId(table.id)
    const descriptor = getTableDescriptor(table, activeFloor?.name || '', tableIndex)
    const isOccupied = occupiedTableSet.has(descriptor.tableKey)
    onSelectTable?.({
      tableKey: descriptor.tableKey,
      masaNo: descriptor.masaNo,
      label: descriptor.label,
      keepLayoutOpen: isOccupied,
      occupied: isOccupied,
    })
  }

  if (!hasSavedLayout) {
    return (
      <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: 14, minHeight: 0, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ color: '#fff', fontSize: '1.05rem', fontWeight: 900 }}>
            Kayitli plan bulunamadi
          </div>
          <button
            type="button"
            onClick={() => navigate('/pos-masa')}
            style={{
              minHeight: 42,
              padding: '0 16px',
              borderRadius: 999,
              border: '1px solid rgba(251,191,36,.3)',
              background: 'linear-gradient(135deg,#fbbf24,#f59e0b)',
              color: '#071035',
              fontWeight: 900,
              cursor: 'pointer',
            }}
          >
            Salon duzenini planla
          </button>
        </div>

        <div style={{
          minHeight: 0,
          borderRadius: 24,
          border: '1px solid rgba(148,163,184,.12)',
          background: 'linear-gradient(180deg, rgba(11,20,64,.62), rgba(7,14,49,.82))',
          display: 'grid',
          placeItems: 'center',
          padding: 28,
          textAlign: 'center',
        }}>
          <div style={{ maxWidth: 560 }}>
            <div style={{
              width: 72,
              height: 72,
              margin: '0 auto 18px',
              borderRadius: 20,
              background: 'rgba(56,189,248,.12)',
              color: '#7dd3fc',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '1.6rem',
            }}>
              <i className="fa-solid fa-table-cells-large" />
            </div>
            <div style={{ color: '#fff', fontSize: '1.18rem', fontWeight: 900 }}>
              Henuz tanimlanmis bir salon veya masa yok
            </div>
            <div style={{ color: 'rgba(191,219,254,.78)', lineHeight: 1.7, marginTop: 10 }}>
              Ilk kullanim icin once salon duzeni planlama ekraninda katlari, bolgeleri ve masalari kaydetmeniz gerekiyor.
            </div>
            <button
              type="button"
              onClick={() => navigate('/pos-masa')}
              style={{
                marginTop: 20,
                minHeight: 48,
                padding: '0 18px',
                borderRadius: 14,
                border: '1px solid rgba(251,191,36,.3)',
                background: 'linear-gradient(135deg,#fbbf24,#f59e0b)',
                color: '#071035',
                fontWeight: 900,
                cursor: 'pointer',
              }}
            >
              Duzenleme ekranina git
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: 14, minHeight: 0, height: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%', flexWrap: 'wrap' }}>
          <ViewModeToggle value={viewMode} onChange={setViewMode} />
          <div style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.max(savedEditor?.floors?.length || 0, 1)}, minmax(0, 1fr))`, gap: 8, flex: '1 1 320px', minWidth: 0 }}>
            {savedEditor.floors.map(floor => (
              <button
                key={floor.id}
                type="button"
                onClick={() => setActiveFloorId(floor.id)}
                style={{
                  minHeight: 40,
                  width: '100%',
                  padding: '0 10px',
                  borderRadius: 999,
                  border: `1px solid ${floor.id === activeFloor?.id ? 'rgba(56,189,248,.48)' : 'rgba(148,163,184,.16)'}`,
                  background: floor.id === activeFloor?.id ? 'rgba(56,189,248,.14)' : 'rgba(15,23,42,.42)',
                  color: floor.id === activeFloor?.id ? '#7dd3fc' : '#dbeafe',
                  fontWeight: 800,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                {floor.name}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => navigate('/pos-masa')}
            style={{
              minHeight: 40,
              padding: '0 16px',
              borderRadius: 999,
              border: '1px solid rgba(251,191,36,.3)',
              background: 'linear-gradient(135deg,#fbbf24,#f59e0b)',
              color: '#071035',
              fontWeight: 900,
              cursor: 'pointer',
              flexShrink: 0,
            }}
          >
            Duzenle
          </button>
      </div>

      <div style={{ minHeight: 0, borderRadius: 24, padding: 14, background: 'rgba(4,8,28,.44)', border: '1px solid rgba(148,163,184,.12)' }}>
        {viewMode === 'simple' ? (
          <div style={{
            width: '100%',
            height: '100%',
            minHeight: 460,
            borderRadius: 20,
            overflow: 'auto',
            background: 'linear-gradient(180deg, rgba(14,24,63,.96), rgba(9,16,43,.98))',
            padding: 18,
            display: 'grid',
            alignContent: 'start',
            gap: 12,
          }}>
            <div style={{ color: 'rgba(191,219,254,.72)', fontSize: '.78rem', fontWeight: 800, letterSpacing: '.08em', textTransform: 'uppercase' }}>
              Basit Masa Gorunumu
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(132px, 1fr))', gap: 12 }}>
              {activeFloor?.tables.map((table, tableIndex) => {
                const descriptor = getTableDescriptor(table, activeFloor?.name || '', tableIndex)
                const effectiveStatus = occupiedTableSet.has(descriptor.tableKey) ? 'occupied' : table.status
                const statusMeta = STATUS_META[effectiveStatus] || STATUS_META.empty
                const isSelected = selectedTable?.id === table.id
                const liveCoverCount = Math.max(0, parseInt(coverCountByTable?.[descriptor.tableKey], 10) || 0)
                return (
                  <button
                    key={descriptor.tableKey}
                    type="button"
                    onClick={() => handleTableClick(table, tableIndex)}
                    style={{
                      minHeight: 112,
                      borderRadius: 18,
                      border: `1px solid ${isSelected ? 'rgba(251,191,36,.48)' : 'rgba(148,163,184,.16)'}`,
                      background: isSelected ? 'rgba(251,191,36,.12)' : 'rgba(15,23,42,.52)',
                      boxShadow: `0 10px 24px ${statusMeta.color}22`,
                      padding: 14,
                      cursor: 'pointer',
                      textAlign: 'left',
                      display: 'grid',
                      gap: 10,
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                      <span style={{ color: '#fff', fontWeight: 900, fontSize: '.95rem' }}>{descriptor.label}</span>
                      <span style={{
                        width: 12,
                        height: 12,
                        borderRadius: 999,
                        background: statusMeta.color,
                        boxShadow: `0 0 0 4px ${statusMeta.color}22`,
                        flexShrink: 0,
                      }} />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                      <span style={{ color: 'rgba(191,219,254,.74)', fontSize: '.78rem', fontWeight: 700 }}>
                        Canli kuver
                      </span>
                      <span style={{
                        borderRadius: 999,
                        padding: '4px 8px',
                        background: `${statusMeta.color}22`,
                        color: statusMeta.color,
                        fontSize: '.72rem',
                        fontWeight: 900,
                      }}>
                        {statusMeta.label}
                      </span>
                    </div>
                    <div style={{ color:'#f8fafc', fontSize:'.76rem', fontWeight:800 }}>
                      Kuver: {liveCoverCount}
                    </div>
                  </button>
                )
              })}
            </div>
          </div>
        ) : (
          <div
            style={{
              position: 'relative',
              width: '100%',
              aspectRatio: '16 / 10',
              minHeight: 460,
              borderRadius: 20,
              overflow: 'hidden',
              backgroundColor: activeFloor?.bgColor || DEFAULT_FLOOR_COLOR,
              backgroundImage: activeFloor?.bgImage
                ? `linear-gradient(rgba(4,8,28,.28), rgba(4,8,28,.28)), url(${activeFloor.bgImage})`
                : 'linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px)',
              backgroundSize: activeFloor?.bgImage ? 'cover' : '28px 28px',
              backgroundPosition: 'center',
            }}
          >
            {activeFloor?.zones.map(zone => (
              <div
                key={zone.id}
                style={{
                  position: 'absolute',
                  left: `${zone.x}%`,
                  top: `${zone.y}%`,
                  width: `${zone.w}%`,
                  height: `${zone.h}%`,
                  border: '1px dashed rgba(255,255,255,.5)',
                  borderRadius: 18,
                  display: 'flex',
                  alignItems: 'flex-start',
                  justifyContent: 'flex-start',
                  padding: 12,
                  color: '#e0f2fe',
                  fontWeight: 800,
                  pointerEvents: 'none',
                  background: `rgba(8, 15, 49, ${zone.opacity || 0.14})`,
                  borderColor: zone.color,
                  backdropFilter: 'blur(1px)',
                }}
              >
                <span>{zone.name}</span>
              </div>
            ))}

            {activeFloor?.tables.map((table, tableIndex) => {
              const descriptor = getTableDescriptor(table, activeFloor?.name || '', tableIndex)
              const effectiveStatus = occupiedTableSet.has(descriptor.tableKey) ? 'occupied' : table.status
              const renderTable = effectiveStatus === table.status ? table : { ...table, status: effectiveStatus }
              const statusMeta = STATUS_META[effectiveStatus] || STATUS_META.empty
              const liveCoverCount = Math.max(0, parseInt(coverCountByTable?.[descriptor.tableKey], 10) || 0)
              const glow = statusMeta.color === '#22c55e'
                ? 'rgba(34,197,94,.42)'
                : statusMeta.color === '#ef4444'
                  ? 'rgba(239,68,68,.42)'
                  : 'rgba(59,130,246,.42)'

              return (
                <button
                  key={descriptor.tableKey}
                  type="button"
                  onClick={() => handleTableClick(table, tableIndex)}
                  style={{
                    position: 'absolute',
                    left: `${table.x}%`,
                    top: `${table.y}%`,
                    width: `${table.w}%`,
                    height: `${table.h}%`,
                    border: `2px solid ${selectedTable?.id === table.id ? 'rgba(255,255,255,.28)' : 'transparent'}`,
                    background: 'transparent',
                    boxShadow: `0 10px 28px ${glow}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    padding: 0,
                  }}
                >
                  <div style={{ position: 'absolute', inset: 0, padding: '5%' }}>
                    <TablePresetGraphic table={renderTable} />
                  </div>
                  {liveCoverCount > 0 && (
                    <span style={{
                      position: 'absolute',
                      left: '50%',
                      top: '50%',
                      transform: 'translate(-50%, -50%)',
                      color: '#f8fafc',
                      fontSize: table.shape === 'square' ? '.95rem' : '1rem',
                      fontWeight: 900,
                      lineHeight: 1,
                      textShadow: '0 2px 8px rgba(2,6,23,.95), 0 0 1px rgba(2,6,23,.9)',
                      pointerEvents: 'none',
                      letterSpacing: '.01em',
                    }}>
                      {liveCoverCount}
                    </span>
                  )}
                  <span style={{
                    position: 'absolute',
                    left: '50%',
                    bottom: 8,
                    transform: 'translateX(-50%)',
                    background: 'rgba(7,16,53,.78)',
                    color: '#eef4ff',
                    borderRadius: 999,
                    padding: '4px 10px',
                    fontSize: '.7rem',
                    fontWeight: 800,
                    whiteSpace: 'nowrap',
                    boxShadow: '0 6px 14px rgba(2,6,23,.24)',
                    pointerEvents: 'none',
                  }}>
                    {descriptor.label}
                  </span>
                </button>
              )
            })}
          </div>
        )}
      </div>

    </div>
  )
}
