﻿import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import QRCode from 'qrcode'
import Header from '@/components/layout/Header'
import { useWorkspace } from '@/context/WorkspaceContext'
import { loadLoyaltyWorkspace } from '@/lib/loyalty'
import { loadBranchContextsFromDb } from '@/lib/branchContexts'
import {
  extractPosLoyaltyToken,
  linkCustomerToPosLoyaltySession,
  loadCustomerLoyaltyCategoryIds,
  readPosLoyaltyLinkSession,
} from '@/lib/posCustomerLink'
import {
  linkCustomerToKioskSession,
  readKioskLoyaltyLinkSession,
} from '@/lib/kioskSettings'
import { readSettingValue, writeSettingValue } from '@/lib/settingsStore'
import { db } from '@/lib/db'

const MOBILE_APP_SETTING_KEY = 'loyalty_mobile_app_config'
const MOBILE_APP_CONFIG_VERSION = 1

const BACKGROUND_PRESETS = [
  {
    id: 'charcoal-burger',
    label: 'Koyu restoran',
    preview: 'linear-gradient(180deg, rgba(10,10,10,.82), rgba(10,10,10,.92)), radial-gradient(circle at top, rgba(196,77,14,.45), transparent 42%), linear-gradient(135deg, #3a1f0f 0%, #0f0f10 54%, #23160c 100%)',
    phone: 'linear-gradient(180deg, rgba(10,10,10,.82), rgba(10,10,10,.94)), radial-gradient(circle at 50% -10%, rgba(250,204,21,.18), transparent 35%), radial-gradient(circle at 85% 10%, rgba(248,113,113,.16), transparent 24%), linear-gradient(135deg, #2b170c 0%, #101214 55%, #1d120c 100%)',
  },
  {
    id: 'amber-night',
    label: 'Gece amber',
    preview: 'linear-gradient(180deg, rgba(24,24,27,.76), rgba(24,24,27,.9)), radial-gradient(circle at top right, rgba(251,191,36,.4), transparent 34%), linear-gradient(135deg, #4a2310 0%, #161616 48%, #0f172a 100%)',
    phone: 'linear-gradient(180deg, rgba(24,24,27,.74), rgba(24,24,27,.92)), radial-gradient(circle at top right, rgba(251,191,36,.32), transparent 28%), radial-gradient(circle at bottom left, rgba(59,130,246,.18), transparent 24%), linear-gradient(135deg, #4a2310 0%, #141416 50%, #111827 100%)',
  },
  {
    id: 'forest-glow',
    label: 'Yesil vurgu',
    preview: 'linear-gradient(180deg, rgba(7,18,18,.8), rgba(7,18,18,.92)), radial-gradient(circle at top, rgba(74,222,128,.25), transparent 32%), linear-gradient(135deg, #10261d 0%, #101114 52%, #1a100d 100%)',
    phone: 'linear-gradient(180deg, rgba(7,18,18,.82), rgba(7,18,18,.94)), radial-gradient(circle at 18% 8%, rgba(74,222,128,.26), transparent 24%), radial-gradient(circle at 82% 15%, rgba(251,191,36,.18), transparent 20%), linear-gradient(135deg, #10261d 0%, #101114 52%, #1a100d 100%)',
  },
]

const BUTTON_SHAPE_OPTIONS = [
  { value: 'soft', label: 'Yumusak', radius: 20 },
  { value: 'square', label: 'Kose keskin', radius: 12 },
  { value: 'pill', label: 'Tam oval', radius: 999 },
]

const PRIMARY_ACTION_LIBRARY = [
  {
    value: 'call',
    label: 'Telefon Et',
    icon: 'fa-phone-volume',
    description: 'Tek dokunusla isletmeyi aratir.',
    suggestedHref: 'tel:+905551112233',
    color: '#f97316',
    badge: 'Hizli erisim',
  },
  {
    value: 'order',
    label: 'Siparis Ver',
    icon: 'fa-burger',
    description: 'Mobil siparis akisini baslatir.',
    suggestedHref: '/mobil-app/siparis',
    color: '#ef4444',
    badge: 'Gelir',
  },
  {
    value: 'reservation',
    label: 'Rezervasyon',
    icon: 'fa-calendar-check',
    description: 'Rezervasyon formu veya entegrasyon ekranina gider.',
    suggestedHref: '/mobil-app/rezervasyon',
    color: '#f59e0b',
    badge: 'Masa doluluk',
  },
  {
    value: 'feedback',
    label: 'Goruslerini Bildir',
    icon: 'fa-comments',
    description: 'Memnuniyet ve oneriler icin form acar.',
    suggestedHref: '/mobil-app/gorus-bildir',
    color: '#22c55e',
    badge: 'Memnuniyet',
  },
  {
    value: 'branches',
    label: 'Sube Bilgileri',
    icon: 'fa-store',
    description: 'Sube bilgileri ve yol tarifi ekranini acar.',
    suggestedHref: '/mobil-app/subeler',
    color: '#38bdf8',
    badge: 'Konum',
  },
  {
    value: 'campaigns',
    label: 'Kampanyalar',
    icon: 'fa-percent',
    description: 'Aktif kampanya listesine yonlendirir.',
    suggestedHref: '/mobil-app/kampanyalar',
    color: '#eab308',
    badge: 'Sadakat',
  },
  {
    value: 'qr',
    label: 'QR Kodum',
    icon: 'fa-qrcode',
    description: 'Musterinin QR uyelik kartini gosterir.',
    suggestedHref: '/mobil-app/qr',
    color: '#a855f7',
    badge: 'Kasada kullan',
  },
  {
    value: 'scan',
    label: 'QR Oku',
    icon: 'fa-camera',
    description: 'QR kampanya veya masa/fis okutma akisi.',
    suggestedHref: '/mobil-app/qr-oku',
    color: '#14b8a6',
    badge: 'Tarama',
  },
]

const SECONDARY_ACTION_LIBRARY = [
  { value: 'campaigns', label: 'Kampanyalar', icon: 'fa-percent', suggestedHref: '/mobil-app/kampanyalar' },
  { value: 'points', label: 'Puanlarim', icon: 'fa-star', suggestedHref: '/mobil-app/hesabim#puanlar' },
  { value: 'wallet', label: 'Kuponlarim', icon: 'fa-wallet', suggestedHref: '/mobil-app/hesabim#kuponlar' },
  { value: 'qr', label: 'QR Kodum', icon: 'fa-qrcode', suggestedHref: '/mobil-app/qr' },
  { value: 'scan', label: 'QR Oku', icon: 'fa-camera', suggestedHref: '/mobil-app/qr-oku' },
  { value: 'menu', label: 'Dijital Menu', icon: 'fa-book-open', suggestedHref: '/mobil-app/menu' },
  { value: 'branches', label: 'Subeler', icon: 'fa-location-dot', suggestedHref: '/mobil-app/subeler' },
  { value: 'feedback', label: 'Goruslerini Bildir', icon: 'fa-comment-dots', suggestedHref: '/mobil-app/gorus-bildir' },
  { value: 'reservation', label: 'Rezervasyon', icon: 'fa-calendar-check', suggestedHref: '/mobil-app/rezervasyon' },
  { value: 'order', label: 'Siparis Ver', icon: 'fa-basket-shopping', suggestedHref: '/mobil-app/siparis' },
  { value: 'support', label: 'Canli Destek', icon: 'fa-headset', suggestedHref: '/mobil-app/destek' },
  { value: 'whatsapp', label: 'WhatsApp', icon: 'fa-brands fa-whatsapp', suggestedHref: 'https://wa.me/905551112233' },
]

const MOBILE_TAB_OPTIONS = [
  { value: 'home', label: 'Anasayfa', icon: 'fa-house' },
  { value: 'campaigns', label: 'Kampanyalar', icon: 'fa-percent' },
  { value: 'qr', label: 'QR', icon: 'fa-qrcode' },
  { value: 'account', label: 'Hesabim', icon: 'fa-user' },
]

const MOBILE_APP_BASE_PATH = '/mobil-app'

const SAMPLE_CUSTOMER = {
  name: 'Asli Dogan',
  level: 'Gold uye',
  phone: '+90 555 111 22 33',
  points: 1240,
  qrPayload: 'LOYALTY|customer-demo-1001|Asli Dogan|1240',
  nextReward: '250 puan sonra ucretsiz kahve',
  memberSince: 'Mart 2025',
  availableCoupons: 3,
  visits: 18,
}

function buildDefaultPrimaryActions() {
  return PRIMARY_ACTION_LIBRARY.slice(0, 4).map((item, index) => ({
    id: `primary-${index + 1}`,
    slotLabel: `${index + 1}. kutu`,
    type: item.value,
    label: item.label,
    icon: item.icon,
    href: item.suggestedHref,
    note: item.description,
    enabled: true,
  }))
}

function buildDefaultSecondaryActions() {
  return SECONDARY_ACTION_LIBRARY.slice(0, 8).map((item, index) => ({
    id: `secondary-${index + 1}`,
    type: item.value,
    label: item.label,
    icon: item.icon,
    href: item.suggestedHref,
    enabled: true,
  }))
}

function createDefaultDraft() {
  return {
    businessName: 'Rest Burger',
    tagline: 'Lezzet, sadakat ve tek ekranda hizli erisim',
    welcomeText: 'Hos geldiniz, Asli Dogan',
    announcementText: 'Puanlarini kullan, kampanyalari incele ve QR kodunu tek dokunusla goster.',
    logoText: 'RB',
    activeBackgroundPreset: BACKGROUND_PRESETS[0].id,
    customBackgroundDataUrl: '',
    logoDataUrl: '',
    buttonShape: BUTTON_SHAPE_OPTIONS[0].value,
    accentColor: '#ff5a36',
    requireLogin: true,
    showQrCode: true,
    showQrScanner: true,
    showPoints: true,
    showCampaigns: true,
    qrPayload: SAMPLE_CUSTOMER.qrPayload,
    customer: { ...SAMPLE_CUSTOMER },
    primaryActions: buildDefaultPrimaryActions(),
    secondaryActions: buildDefaultSecondaryActions(),
  }
}

function sanitizeDraftForPersistence(value) {
  const draft = normalizeDraft(value)
  return {
    businessName: draft.businessName,
    tagline: draft.tagline,
    welcomeText: draft.welcomeText,
    announcementText: draft.announcementText,
    logoText: draft.logoText,
    activeBackgroundPreset: draft.activeBackgroundPreset,
    customBackgroundDataUrl: draft.customBackgroundDataUrl,
    logoDataUrl: draft.logoDataUrl,
    buttonShape: draft.buttonShape,
    accentColor: draft.accentColor,
    requireLogin: draft.requireLogin,
    showQrCode: draft.showQrCode,
    showQrScanner: draft.showQrScanner,
    showPoints: draft.showPoints,
    showCampaigns: draft.showCampaigns,
    primaryActions: draft.primaryActions,
    secondaryActions: draft.secondaryActions,
  }
}

function normalizeArray(input, fallbackFactory) {
  return Array.isArray(input) ? input : fallbackFactory()
}

function normalizeDraft(value) {
  const fallback = createDefaultDraft()
  const defaultPrimary = buildDefaultPrimaryActions()
  const defaultSecondary = buildDefaultSecondaryActions()
  if (!value || typeof value !== 'object') return fallback

  return {
    ...fallback,
    ...value,
    customer: {
      ...fallback.customer,
      ...(value.customer || {}),
    },
    primaryActions: normalizeArray(value.primaryActions, buildDefaultPrimaryActions).slice(0, 4).map((item, index) => ({
      ...defaultPrimary[index],
      ...(item || {}),
    })),
    secondaryActions: normalizeArray(value.secondaryActions, buildDefaultSecondaryActions).slice(0, 8).map((item, index) => ({
      ...defaultSecondary[index],
      ...(item || {}),
    })),
  }
}

function createDefaultConfigMeta() {
  return {
    hasPersistedConfig: false,
    updatedAt: '',
    workspace: {
      scope: '',
      branchId: '',
      branchName: '',
    },
  }
}

function parseStoredMobileAppConfig(value) {
  if (!value || typeof value !== 'object') {
    return {
      draft: createDefaultDraft(),
      meta: createDefaultConfigMeta(),
    }
  }

  const workspace = value.workspace && typeof value.workspace === 'object'
    ? {
        scope: String(value.workspace.scope || '').trim(),
        branchId: String(value.workspace.branchId || '').trim(),
        branchName: String(value.workspace.branchName || '').trim(),
      }
    : createDefaultConfigMeta().workspace

  return {
    draft: normalizeDraft(value.draft || value),
    meta: {
      hasPersistedConfig: true,
      updatedAt: String(value.updatedAt || ''),
      workspace,
    },
  }
}

function buildMobileAppConfigPayload(draft, workspace = {}) {
  return {
    version: MOBILE_APP_CONFIG_VERSION,
    updatedAt: new Date().toISOString(),
    workspace: {
      scope: String(workspace.scope || '').trim(),
      branchId: String(workspace.branchId || '').trim(),
      branchName: String(workspace.branchName || '').trim(),
    },
    draft: sanitizeDraftForPersistence(draft),
  }
}

async function readMobileAppConfigFromDb() {
  const value = await readSettingValue(MOBILE_APP_SETTING_KEY, null)
  return parseStoredMobileAppConfig(value)
}

async function writeMobileAppConfigToDb(draft, workspace = {}) {
  const payload = buildMobileAppConfigPayload(draft, workspace)
  await writeSettingValue(MOBILE_APP_SETTING_KEY, payload)
  return parseStoredMobileAppConfig(payload)
}

function isPublicMobileAppPath(pathname = '') {
  const path = String(pathname || '')
  return path === MOBILE_APP_BASE_PATH || path.startsWith(`${MOBILE_APP_BASE_PATH}/`)
}

function getMobileAppTabPath(tab = 'home') {
  switch (tab) {
    case 'campaigns':
      return `${MOBILE_APP_BASE_PATH}/kampanyalar`
    case 'qr':
      return `${MOBILE_APP_BASE_PATH}/qr`
    case 'account':
      return `${MOBILE_APP_BASE_PATH}/hesabim`
    default:
      return MOBILE_APP_BASE_PATH
  }
}

function resolveMobileAppTab(pathname = '') {
  const path = String(pathname || '').toLowerCase()
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/kampanyalar`)) return 'campaigns'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/qr`)) return 'qr'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/hesabim`)) return 'account'
  return 'home'
}

function resolveActionTab(action = {}) {
  const href = String(action?.href || '').toLowerCase()
  const type = String(action?.type || '').toLowerCase()
  if (href.startsWith(`${MOBILE_APP_BASE_PATH}/kampanyalar`) || type === 'campaigns') return 'campaigns'
  if (href.startsWith(`${MOBILE_APP_BASE_PATH}/qr`) || href.startsWith(`${MOBILE_APP_BASE_PATH}/qr-oku`) || type === 'qr' || type === 'scan') return 'qr'
  if (href.startsWith(`${MOBILE_APP_BASE_PATH}/hesabim`) || type === 'points' || type === 'wallet') return 'account'
  return ''
}

function getPublicMobileAppUrl() {
  if (typeof window === 'undefined') return MOBILE_APP_BASE_PATH
  return `${window.location.origin}${MOBILE_APP_BASE_PATH}`
}

async function copyTextToClipboard(value) {
  const text = String(value || '')
  if (!text) return false

  try {
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(text)
      return true
    }
  } catch {
    // fall through to legacy copy
  }

  if (typeof document === 'undefined') return false

  try {
    const textarea = document.createElement('textarea')
    textarea.value = text
    textarea.setAttribute('readonly', 'readonly')
    textarea.style.position = 'absolute'
    textarea.style.left = '-9999px'
    document.body.appendChild(textarea)
    textarea.select()
    textarea.setSelectionRange(0, text.length)
    const copied = document.execCommand('copy')
    document.body.removeChild(textarea)
    return copied
  } catch {
    return false
  }
}

function getBackgroundPreset(presetId) {
  return BACKGROUND_PRESETS.find(item => item.id === presetId) || BACKGROUND_PRESETS[0]
}

function getShapeRadius(shape) {
  return BUTTON_SHAPE_OPTIONS.find(option => option.value === shape)?.radius || BUTTON_SHAPE_OPTIONS[0].radius
}

function getPrimaryActionMeta(type) {
  return PRIMARY_ACTION_LIBRARY.find(item => item.value === type) || PRIMARY_ACTION_LIBRARY[0]
}

function getSecondaryActionMeta(type) {
  return SECONDARY_ACTION_LIBRARY.find(item => item.value === type) || SECONDARY_ACTION_LIBRARY[0]
}

function formatPoints(points) {
  return new Intl.NumberFormat('tr-TR').format(Number(points) || 0)
}

function formatCurrency(value) {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    maximumFractionDigits: 2,
  }).format(Number(value) || 0)
}

function formatDateTime(value) {
  if (!value) return 'Tarih yok'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return 'Tarih yok'
  return new Intl.DateTimeFormat('tr-TR', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ''))
    reader.onerror = () => reject(reader.error || new Error('Dosya okunamadi'))
    reader.readAsDataURL(file)
  })
}

function normalizePhoneDigits(value) {
  return String(value || '').replace(/\D/g, '')
}

function buildPhoneLookupCandidates(value) {
  const rawDigits = normalizePhoneDigits(value)
  if (!rawDigits) return []

  const candidates = new Set([rawDigits])
  let localDigits = rawDigits

  if (localDigits.startsWith('90') && localDigits.length > 10) {
    localDigits = localDigits.slice(2)
  }
  if (localDigits.startsWith('0') && localDigits.length > 10) {
    localDigits = localDigits.slice(1)
  }
  if (localDigits.length > 10) {
    localDigits = localDigits.slice(-10)
  }
  if (localDigits) {
    candidates.add(localDigits)
    candidates.add(`0${localDigits}`)
    candidates.add(`90${localDigits}`)
  }

  return Array.from(candidates).filter(Boolean)
}

function formatCustomerLevel(status) {
  const text = String(status || '').trim()
  if (!text) return 'Sadakat uyeligi'
  return `${text.charAt(0).toUpperCase()}${text.slice(1)} uye`
}

function formatMonthYear(value) {
  if (!value) return 'Uyelik tarihi yok'
  try {
    return new Intl.DateTimeFormat('tr-TR', {
      month: 'long',
      year: 'numeric',
    }).format(new Date(value))
  } catch {
    return 'Uyelik tarihi yok'
  }
}

function formatCustomerPhone(customer = {}) {
  const code = String(customer.telefon_ulke || '').trim()
  const phone = String(customer.telefon || '').trim()
  return `${code}${phone}`.trim() || 'Telefon yok'
}

function buildGuestCustomerProfile(draft) {
  return {
    id: '',
    name: draft.businessName || 'Misafir',
    level: 'Giris yapilmadi',
    phone: 'Telefon ile giris gerekli',
    points: 0,
    qrPayload: '',
    nextReward: 'Telefon ile giris yaparak puan ve kuponlarini gorun',
    memberSince: '-',
    availableCoupons: 0,
    visits: 0,
    coupons: [],
    recentSales: [],
    dataWarnings: [],
  }
}

function parseScannedSessionPayload(rawValue) {
  const raw = String(rawValue || '').trim()
  if (!raw) return { type: 'unknown', token: '', raw }

  const kioskMatch = raw.match(/\/kiosk-link\/([^/?#]+)/i)
  if (kioskMatch?.[1]) {
    return {
      type: 'kiosk',
      token: kioskMatch[1],
      raw,
    }
  }

  const posToken = extractPosLoyaltyToken(raw)
  if (posToken && /\/pos-loyalty-link\//i.test(raw)) {
    return {
      type: 'pos',
      token: posToken,
      raw,
    }
  }

  if (raw.startsWith('LOYALTY|')) {
    return {
      type: 'customer_qr',
      token: '',
      raw,
    }
  }

  return {
    type: 'unknown',
    token: '',
    raw,
  }
}

function isSchemaMissingError(error) {
  const message = String(error?.message || error?.details || error?.hint || '').toLowerCase()
  return error?.code === 'PGRST204' || error?.code === '42703' || message.includes('does not exist')
}

function mapCouponPreviewRow(coupon = {}) {
  return {
    id: coupon.id,
    code: coupon.code,
    expiresAt: coupon.expires_at || coupon.metadata?.expires_at || coupon.metadata?.expiresAt || null,
    note: coupon.metadata?.note || '',
  }
}

async function loadCustomerAvailableCoupons(customerId) {
  const primaryResult = await db
    .from('loyalty_coupons')
    .select('id,code,expires_at,redemption_status,metadata')
    .eq('customer_id', customerId)
    .eq('redemption_status', 'available')

  if (!primaryResult.error) {
    return (primaryResult.data || []).map(mapCouponPreviewRow)
  }

  if (!isSchemaMissingError(primaryResult.error)) {
    throw primaryResult.error
  }

  const fallbackResult = await db
    .from('loyalty_coupons')
    .select('id,code,is_used,used_at,metadata,active')
    .eq('customer_id', customerId)

  if (fallbackResult.error) throw fallbackResult.error

  return (fallbackResult.data || [])
    .filter(coupon => coupon.active !== false && !coupon.is_used && !coupon.used_at)
    .map(mapCouponPreviewRow)
}

function mapCustomerToPreviewProfile(customer, pointsBalance = 0, couponCount = 0) {
  const name = String(customer.ad_soyad || customer.sirket_adi || 'Misafir').trim()
  return {
    id: customer.id,
    name,
    level: formatCustomerLevel(customer.loyalty_status),
    phone: formatCustomerPhone(customer),
    points: Number(pointsBalance) || 0,
    qrPayload: `LOYALTY|${customer.id}|${name}|${Number(pointsBalance) || 0}`,
    nextReward: couponCount > 0 ? `${couponCount} hazir kuponunuz var` : 'Aktif kampanyalari inceleyin',
    memberSince: formatMonthYear(customer.loyalty_enrolled_at || customer.created_at),
    availableCoupons: couponCount,
    visits: Number(customer.total_order_count) || 0,
    coupons: [],
    recentSales: [],
    dataWarnings: [],
  }
}

function resolveMobileAppScreen(pathname = '') {
  const path = String(pathname || '').toLowerCase()
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/kampanyalar`)) return 'campaigns'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/qr-oku`)) return 'scan'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/qr`)) return 'qr'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/hesabim`)) return 'account'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/subeler`)) return 'branches'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/siparis`)) return 'order'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/rezervasyon`)) return 'reservation'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/gorus-bildir`)) return 'feedback'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/destek`)) return 'support'
  if (path.startsWith(`${MOBILE_APP_BASE_PATH}/menu`)) return 'menu'
  return 'home'
}

function getNavigationTabForScreen(screen) {
  if (screen === 'campaigns') return 'campaigns'
  if (screen === 'qr' || screen === 'scan') return 'qr'
  if (screen === 'account') return 'account'
  return 'home'
}

function SummaryCard({ icon, label, value, hint, accent }) {
  return (
    <div className="card" style={{ padding: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span
          style={{
            width: 38,
            height: 38,
            borderRadius: 12,
            background: `${accent}16`,
            color: accent,
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}
        >
          <i className={`fa-solid ${icon}`} />
        </span>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: '.74rem', color: '#64748b', fontWeight: 800 }}>{label}</div>
          <div style={{ marginTop: 6, fontSize: '1.35rem', color: '#0f172a', fontWeight: 900 }}>{value}</div>
          <div style={{ marginTop: 4, fontSize: '.76rem', color: '#94a3b8' }}>{hint}</div>
        </div>
      </div>
    </div>
  )
}

function SectionCard({ title, subtitle, children, action = null }) {
  return (
    <div className="card" style={{ padding: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start', flexWrap: 'wrap', marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: '.92rem', fontWeight: 900, color: '#0f172a' }}>{title}</div>
          <div style={{ fontSize: '.78rem', color: '#64748b', marginTop: 4, lineHeight: 1.55 }}>{subtitle}</div>
        </div>
        {action}
      </div>
      {children}
    </div>
  )
}

function Field({ label, hint, children }) {
  return (
    <label style={{ display: 'grid', gap: 6 }}>
      <span style={{ fontSize: '.76rem', fontWeight: 800, color: '#64748b' }}>{label}</span>
      {children}
      {hint ? <span style={{ fontSize: '.72rem', color: '#94a3b8', lineHeight: 1.5 }}>{hint}</span> : null}
    </label>
  )
}

function TogglePill({ active, onClick, label, icon, accent }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        borderRadius: 999,
        border: `1px solid ${active ? accent : '#e2e8f0'}`,
        background: active ? `${accent}16` : '#fff',
        color: active ? accent : '#475569',
        fontWeight: 800,
        fontSize: '.76rem',
        padding: '9px 12px',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        cursor: 'pointer',
      }}
    >
      <i className={`fa-solid ${icon}`} />
      {label}
    </button>
  )
}

function SmallBadge({ children, accent = '#1d4ed8', background = '#eff6ff' }) {
  return (
    <span
      style={{
        borderRadius: 999,
        padding: '4px 10px',
        fontSize: '.7rem',
        fontWeight: 900,
        color: accent,
        background,
        border: `1px solid ${background === '#fff' ? '#e2e8f0' : 'transparent'}`,
      }}
    >
      {children}
    </span>
  )
}

function LinkTargetRow({ label, href, icon, note }) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '36px minmax(0, 1fr)',
        gap: 10,
        alignItems: 'start',
        padding: '10px 12px',
        borderRadius: 14,
        border: '1px solid #e2e8f0',
        background: '#fff',
      }}
    >
      <span
        style={{
          width: 36,
          height: 36,
          borderRadius: 12,
          background: '#eff6ff',
          color: '#1d4ed8',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <i className={icon?.startsWith('fa-brands') ? icon : `fa-solid ${icon}`} />
      </span>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: '.8rem', fontWeight: 800, color: '#0f172a' }}>{label}</div>
        <div style={{ fontSize: '.73rem', color: '#1d4ed8', marginTop: 4, wordBreak: 'break-word' }}>{href || '-'}</div>
        <div style={{ fontSize: '.72rem', color: '#64748b', marginTop: 6, lineHeight: 1.5 }}>{note}</div>
      </div>
    </div>
  )
}

function useLoyaltyMobileConfigState() {
  const [draft, setDraft] = useState(() => createDefaultDraft())
  const [configMeta, setConfigMeta] = useState(() => createDefaultConfigMeta())
  const [persistedDraftJson, setPersistedDraftJson] = useState(() => JSON.stringify(sanitizeDraftForPersistence(createDefaultDraft())))
  const [loadingConfig, setLoadingConfig] = useState(true)
  const [configError, setConfigError] = useState('')
  const [savingConfig, setSavingConfig] = useState(false)
  const [saveError, setSaveError] = useState('')

  const reloadConfig = async () => {
    setLoadingConfig(true)
    setConfigError('')
    try {
      const nextConfig = await readMobileAppConfigFromDb()
      setDraft(nextConfig.draft)
      setConfigMeta(nextConfig.meta)
      setPersistedDraftJson(JSON.stringify(sanitizeDraftForPersistence(nextConfig.draft)))
    } catch (error) {
      setDraft(createDefaultDraft())
      setConfigMeta(createDefaultConfigMeta())
      setPersistedDraftJson(JSON.stringify(sanitizeDraftForPersistence(createDefaultDraft())))
      setConfigError(String(error?.message || error || 'Mobil app konfigurasyonu okunamadi.'))
    } finally {
      setLoadingConfig(false)
    }
  }

  useEffect(() => {
    void reloadConfig()
  }, [])

  const saveConfig = async workspace => {
    setSavingConfig(true)
    setSaveError('')
    try {
      const nextConfig = await writeMobileAppConfigToDb(draft, workspace)
      setDraft(nextConfig.draft)
      setConfigMeta(nextConfig.meta)
      setPersistedDraftJson(JSON.stringify(sanitizeDraftForPersistence(nextConfig.draft)))
      return true
    } catch (error) {
      setSaveError(String(error?.message || error || 'Mobil app konfigurasyonu kaydedilemedi.'))
      return false
    } finally {
      setSavingConfig(false)
    }
  }

  return {
    draft,
    setDraft,
    configMeta,
    persistedDraftJson,
    loadingConfig,
    configError,
    savingConfig,
    saveError,
    reloadConfig,
    saveConfig,
  }
}

function useLoyaltyMobileCampaigns(scope = '', branchId = '', branchName = '') {
  const [campaigns, setCampaigns] = useState([])
  const [loadingCampaigns, setLoadingCampaigns] = useState(true)
  const [campaignError, setCampaignError] = useState('')

  useEffect(() => {
    let cancelled = false

    async function loadCampaigns() {
      setLoadingCampaigns(true)
      setCampaignError('')
      try {
        const result = await loadLoyaltyWorkspace({ scope, branchId, branchName })
        if (!cancelled) {
          setCampaigns(Array.isArray(result?.campaigns) ? result.campaigns : [])
        }
      } catch (error) {
        if (!cancelled) {
          setCampaigns([])
          setCampaignError(String(error?.message || error || 'Kampanyalar okunamadi.'))
        }
      } finally {
        if (!cancelled) setLoadingCampaigns(false)
      }
    }

    loadCampaigns()
    return () => {
      cancelled = true
    }
  }, [scope, branchId, branchName])

  const activeCampaigns = useMemo(
    () => campaigns.filter(item => item.active !== false),
    [campaigns],
  )

  return {
    campaigns,
    activeCampaigns,
    loadingCampaigns,
    campaignError,
  }
}

function useMobileBranches(enabled = false) {
  const [branches, setBranches] = useState([])
  const [loadingBranches, setLoadingBranches] = useState(enabled)
  const [branchError, setBranchError] = useState('')

  useEffect(() => {
    if (!enabled) {
      setLoadingBranches(false)
      return
    }

    let cancelled = false

    async function loadBranches() {
      setLoadingBranches(true)
      setBranchError('')
      try {
        const rows = await loadBranchContextsFromDb()
        if (!cancelled) setBranches(Array.isArray(rows) ? rows : [])
      } catch (error) {
        if (!cancelled) {
          setBranches([])
          setBranchError(String(error?.message || error || 'Subeler okunamadi.'))
        }
      } finally {
        if (!cancelled) setLoadingBranches(false)
      }
    }

    void loadBranches()
    return () => {
      cancelled = true
    }
  }, [enabled])

  return {
    branches,
    loadingBranches,
    branchError,
  }
}

function QrScannerCard({ onDetected }) {
  const videoRef = useRef(null)
  const detectorRef = useRef(null)
  const streamRef = useRef(null)
  const frameRef = useRef(0)
  const [state, setState] = useState('idle')
  const [message, setMessage] = useState('QR okutma hazir. Baslat ile kamerayi acabilirsiniz.')

  const stopScanner = () => {
    if (frameRef.current) {
      window.cancelAnimationFrame(frameRef.current)
      frameRef.current = 0
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    detectorRef.current = null
    setState('idle')
  }

  useEffect(() => stopScanner, [])

  const scanFrame = async () => {
    if (!videoRef.current || !detectorRef.current) return
    try {
      if (videoRef.current.readyState >= 2) {
        const codes = await detectorRef.current.detect(videoRef.current)
        if (codes?.length) {
          const rawValue = String(codes[0].rawValue || '').trim()
          if (rawValue) {
            setMessage(`QR okundu: ${rawValue}`)
            onDetected(rawValue)
            stopScanner()
            return
          }
        }
      }
      frameRef.current = window.requestAnimationFrame(scanFrame)
    } catch (error) {
      setState('error')
      setMessage(`QR okuma basarisiz: ${String(error?.message || error)}`)
      stopScanner()
    }
  }

  const startScanner = async () => {
    if (typeof window === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setState('unsupported')
      setMessage('Bu tarayici kamera erisimini desteklemiyor.')
      return
    }

    if (!('BarcodeDetector' in window)) {
      setState('unsupported')
      setMessage('Bu tarayicida BarcodeDetector destegi yok. Mobil Chrome/Edge ile tekrar deneyin.')
      return
    }

    try {
      detectorRef.current = new window.BarcodeDetector({ formats: ['qr_code'] })
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 720 },
          height: { ideal: 720 },
        },
        audio: false,
      })

      if (!videoRef.current) {
        stream.getTracks().forEach(track => track.stop())
        return
      }

      streamRef.current = stream
      videoRef.current.srcObject = stream
      await videoRef.current.play()
      setState('running')
      setMessage('QR araniyor... kod kameraya girdiginde otomatik okunacak.')
      frameRef.current = window.requestAnimationFrame(scanFrame)
    } catch (error) {
      setState('error')
      setMessage(`Kamera acilamadi: ${String(error?.message || error)}`)
      stopScanner()
    }
  }

  return (
    <div style={{ borderRadius: 16, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.04)', padding: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center', marginBottom: 10 }}>
        <div>
          <div style={{ color: '#fff', fontSize: '.78rem', fontWeight: 900 }}>QR Okut</div>
          <div style={{ color: 'rgba(255,255,255,.62)', fontSize: '.66rem', marginTop: 4 }}>
            Tarama ozelligi destekliyorsa kamera ile calisir.
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            type="button"
            onClick={startScanner}
            style={{
              border: 'none',
              borderRadius: 999,
              background: '#ff5a36',
              color: '#fff',
              fontWeight: 800,
              padding: '7px 10px',
              cursor: 'pointer',
            }}
          >
            Baslat
          </button>
          <button
            type="button"
            onClick={stopScanner}
            style={{
              border: '1px solid rgba(255,255,255,.16)',
              borderRadius: 999,
              background: 'transparent',
              color: '#fff',
              fontWeight: 800,
              padding: '7px 10px',
              cursor: 'pointer',
            }}
          >
            Kapat
          </button>
        </div>
      </div>

      <div style={{ position: 'relative', overflow: 'hidden', borderRadius: 16, border: '1px solid rgba(255,255,255,.12)', background: '#050505', minHeight: 120 }}>
        <video ref={videoRef} muted playsInline style={{ width: '100%', height: 120, objectFit: 'cover', display: state === 'running' ? 'block' : 'none' }} />
        {state !== 'running' && (
          <div style={{ minHeight: 120, display: 'grid', placeItems: 'center', padding: 12, textAlign: 'center', color: 'rgba(255,255,255,.62)' }}>
            <div>
              <div style={{ fontSize: '1.2rem', marginBottom: 8 }}>
                <i className="fa-solid fa-camera" />
              </div>
              <div style={{ fontSize: '.68rem', lineHeight: 1.45 }}>{message}</div>
            </div>
          </div>
        )}
      </div>

      <div style={{ marginTop: 8, fontSize: '.64rem', color: state === 'unsupported' ? '#fcd34d' : 'rgba(255,255,255,.58)', lineHeight: 1.45 }}>
        {message}
      </div>
    </div>
  )
}

function LoyaltyMobilePhonePreview({
  draft,
  campaigns,
  mode = 'management',
  previewLoggedIn = false,
  campaignError = '',
  configNotice = '',
  branches = [],
  loadingBranches = false,
  branchError = '',
}) {
  const location = useLocation()
  const navigate = useNavigate()
  const isPublicAppRoute = isPublicMobileAppPath(location.pathname)
  const [activeTab, setActiveTab] = useState('home')
  const [qrDataUrl, setQrDataUrl] = useState('')
  const [scannedCode, setScannedCode] = useState('')
  const [loginPhone, setLoginPhone] = useState('')
  const [loginLoading, setLoginLoading] = useState(false)
  const [loginError, setLoginError] = useState('')
  const [dbCustomer, setDbCustomer] = useState(null)
  const [actionFeedback, setActionFeedback] = useState('')
  const [scanLinkState, setScanLinkState] = useState({ status: 'idle', message: '' })

  useEffect(() => {
    if (!isPublicAppRoute) return
    setActiveTab(getNavigationTabForScreen(resolveMobileAppScreen(location.pathname)))
  }, [isPublicAppRoute, location.pathname])

  useEffect(() => {
    let active = true
    const qrPayload = dbCustomer?.qrPayload || draft.qrPayload || SAMPLE_CUSTOMER.qrPayload
    QRCode.toDataURL(qrPayload, {
      width: 220,
      margin: 1,
      color: {
        dark: '#111827',
        light: '#ffffff',
      },
    })
      .then(url => {
        if (active) setQrDataUrl(url)
      })
      .catch(() => {
        if (active) setQrDataUrl('')
      })
    return () => {
      active = false
    }
  }, [draft.qrPayload, dbCustomer])

  const radius = getShapeRadius(draft.buttonShape)
  const backgroundPreset = getBackgroundPreset(draft.activeBackgroundPreset)
  const primaryActions = draft.primaryActions.filter(item => item.enabled).slice(0, 4)
  const secondaryActions = draft.secondaryActions.filter(item => item.enabled).slice(0, 8)
  const visibleCampaigns = (campaigns || []).filter(item => item.active !== false)
  const screen = isPublicAppRoute ? resolveMobileAppScreen(location.pathname) : activeTab
  const customerProfile = dbCustomer || (mode === 'management' && previewLoggedIn ? draft.customer : null)
  const displayProfile = customerProfile || buildGuestCustomerProfile(draft)
  const isLoggedInView = !draft.requireLogin || Boolean(dbCustomer) || (mode === 'management' && previewLoggedIn)
  const loginCardStyle = {
    borderRadius: 18,
    border: '1px solid rgba(255,255,255,.14)',
    background: 'rgba(255,255,255,.08)',
    padding: 12,
    boxShadow: '0 14px 28px rgba(0,0,0,.2)',
  }

  const changeTab = tab => {
    if (isPublicAppRoute) {
      navigate(getMobileAppTabPath(tab))
      return
    }
    setActiveTab(tab)
  }

  const handleActionPress = action => {
    const href = String(action?.href || '').trim()
    const tab = resolveActionTab(action)

    if (tab) {
      setActionFeedback('')
      changeTab(tab)
      return
    }

    if (href.startsWith('tel:')) {
      if (typeof window !== 'undefined') window.location.href = href
      return
    }

    if (/^https?:\/\//i.test(href)) {
      if (typeof window !== 'undefined') window.open(href, '_blank', 'noopener,noreferrer')
      return
    }

    if (href.startsWith(MOBILE_APP_BASE_PATH)) {
      if (isPublicAppRoute) {
        navigate(href)
        return
      }
      setActionFeedback(`"${action.label}" ekrani public route uzerinden acilabilir.`)
      return
    }

    setActionFeedback(`"${action.label}" butonu hazir. Nihai link baglantisini sonraki turda ekleyecegiz.`)
  }

  async function handlePhoneLogin() {
    const candidates = buildPhoneLookupCandidates(loginPhone)
    if (!candidates.length) {
      setLoginError('Gecerli bir cep telefonu girin.')
      return
    }

    setLoginLoading(true)
    setLoginError('')

    try {
      let customer = null
      const { data: normalizedRows, error: normalizedError } = await db
        .from('musteriler')
        .select('id,ad_soyad,sirket_adi,telefon,telefon_ulke,normalized_phone,loyalty_status,loyalty_enrolled_at,total_order_count,created_at')
        .in('normalized_phone', candidates)
        .is('deleted_at', null)
        .limit(1)

      if (normalizedError) throw normalizedError
      customer = normalizedRows?.[0] || null

      if (!customer) {
        const localDigits = candidates.find(item => item.length === 10) || candidates.at(-1)
        const { data: phoneRows, error: phoneError } = await db
          .from('musteriler')
          .select('id,ad_soyad,sirket_adi,telefon,telefon_ulke,normalized_phone,loyalty_status,loyalty_enrolled_at,total_order_count,created_at')
          .eq('telefon', localDigits)
          .is('deleted_at', null)
          .limit(1)

        if (phoneError) throw phoneError
        customer = phoneRows?.[0] || null
      }

      if (!customer) {
        setDbCustomer(null)
        setLoginError('Bu numara ile eslesen musteri bulunamadi.')
        return
      }

      const [
        { data: wallets, error: walletError },
        couponRows,
        recentSalesResult,
      ] = await Promise.all([
        db.from('loyalty_wallets').select('current_points_balance').eq('customer_id', customer.id),
        loadCustomerAvailableCoupons(customer.id),
        db
          .from('sales')
          .select('id,sale_datetime,branch_name,net_total_after_discount,status,source')
          .eq('customer_id', customer.id)
          .is('deleted_at', null)
          .order('sale_datetime', { ascending: false })
          .limit(4),
      ])

      if (walletError) throw walletError

      const pointsBalance = (wallets || []).reduce((sum, wallet) => sum + Number(wallet.current_points_balance || 0), 0)
      const profile = mapCustomerToPreviewProfile(customer, pointsBalance, (couponRows || []).length)
      profile.coupons = couponRows || []

      if (recentSalesResult?.error) {
        profile.dataWarnings = ['Son siparisler okunamadi.']
      } else {
        profile.recentSales = (recentSalesResult?.data || []).map(sale => ({
          id: sale.id,
          saleDateTime: sale.sale_datetime,
          branchName: sale.branch_name,
          total: sale.net_total_after_discount,
          status: sale.status,
          source: sale.source,
        }))
      }

      setDbCustomer(profile)
      setScanLinkState({ status: 'idle', message: '' })
      setActiveTab('home')
    } catch (error) {
      setDbCustomer(null)
      setLoginError(`Musteri okunamadi: ${String(error?.message || error)}`)
    } finally {
      setLoginLoading(false)
    }
  }

  async function linkScannedSession(rawValue) {
    setScannedCode(String(rawValue || '').trim())
    setScanLinkState({ status: 'loading', message: 'QR baglantisi kontrol ediliyor...' })

    const parsed = parseScannedSessionPayload(rawValue)

    if (parsed.type === 'customer_qr') {
      setScanLinkState({
        status: 'info',
        message: 'Bu kod musteri karti QR kodu. POS, Garson veya Kiosk baglanti QR kodunu okutun.',
      })
      return
    }

    if (parsed.type === 'unknown' || !parsed.token) {
      setScanLinkState({
        status: 'error',
        message: 'Okunan QR, desteklenen bir POS/Garson/Kiosk baglanti kodu degil.',
      })
      return
    }

    if (!dbCustomer?.id) {
      setScanLinkState({
        status: 'error',
        message: 'Baglanti kurmadan once telefon ile giris yapip musteri hesabini acin.',
      })
      return
    }

    try {
      const { data: customerRow, error: customerError } = await db
        .from('musteriler')
        .select('id,ad_soyad,telefon,telefon_ulke')
        .eq('id', dbCustomer.id)
        .is('deleted_at', null)
        .maybeSingle()

      if (customerError) throw customerError
      if (!customerRow?.id) {
        throw new Error('Musteri kaydi baglanti icin tekrar okunamadi.')
      }

      if (parsed.type === 'pos') {
        const session = await readPosLoyaltyLinkSession(parsed.token)
        if (!session) {
          throw new Error('Bu POS/Garson baglanti oturumu bulunamadi veya suresi doldu.')
        }
        if (session.customerId && String(session.customerId) !== String(customerRow.id)) {
          throw new Error(`${session.registerLabel || 'Bu ekran'} baska bir musteriye bagli.`)
        }
        await linkCustomerToPosLoyaltySession(parsed.token, customerRow)
        setScanLinkState({
          status: 'success',
          message: `${customerRow.ad_soyad || 'Musteri'} hesabi ${session.registerLabel || 'POS/Garson'} ekranina baglandi.`,
        })
        return
      }

      if (parsed.type === 'kiosk') {
        const session = await readKioskLoyaltyLinkSession(parsed.token)
        if (!session) {
          throw new Error('Bu kiosk baglanti oturumu bulunamadi veya suresi doldu.')
        }
        if (session.customerId && String(session.customerId) !== String(customerRow.id)) {
          throw new Error(`${session.kioskStationName || 'Bu kiosk'} baska bir musteriye bagli.`)
        }
        const customerCategoryIds = await loadCustomerLoyaltyCategoryIds({
          branchId: session.branchId || '',
          branchName: session.branchName || '',
        }, customerRow.id)
        await linkCustomerToKioskSession(parsed.token, customerRow, { customerCategoryIds })
        setScanLinkState({
          status: 'success',
          message: `${customerRow.ad_soyad || 'Musteri'} hesabi ${session.kioskStationName || 'Kiosk'} ekranina baglandi.`,
        })
        return
      }

      setScanLinkState({
        status: 'error',
        message: 'Desteklenmeyen baglanti tipi.',
      })
    } catch (error) {
      setScanLinkState({
        status: 'error',
        message: String(error?.message || error || 'QR baglantisi tamamlanamadi.'),
      })
    }
  }

  const renderHome = () => (
    <div style={{ display: 'grid', gap: 10 }}>
      {draft.requireLogin && !isLoggedInView ? (
        <div style={loginCardStyle}>
          <div style={{ color: '#fff', fontSize: '.96rem', fontWeight: 900 }}>Musteri girisi</div>
          <div style={{ marginTop: 4, color: 'rgba(255,255,255,.72)', fontSize: '.72rem', lineHeight: 1.45 }}>
            Telefon numarasi ile hizli giris ve sadakat kartina erisim.
          </div>
          <div style={{ display: 'grid', gap: 8, marginTop: 10 }}>
            <input className="f-input" value={loginPhone} onChange={event => setLoginPhone(event.target.value)} placeholder="5xx xxx xx xx" inputMode="tel" />
            <button
              type="button"
              onClick={handlePhoneLogin}
              disabled={loginLoading}
              style={{
                border: 'none',
                borderRadius: 999,
                background: draft.accentColor,
                color: '#fff',
                fontWeight: 900,
                padding: '11px 14px',
                cursor: 'pointer',
              }}
            >
              {loginLoading ? 'Musteri araniyor...' : 'Telefon ile giris yap'}
            </button>
            {loginError ? <div style={{ fontSize: '.7rem', color: '#fecaca', lineHeight: 1.45 }}>{loginError}</div> : null}
          </div>
        </div>
      ) : (
        <>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
            <div>
              <div style={{ color: 'rgba(255,255,255,.74)', fontSize: '.72rem', textTransform: 'uppercase', letterSpacing: '.08em', fontWeight: 800 }}>
                Sadakat cebi
              </div>
              <div style={{ color: '#fff', fontSize: '1rem', fontWeight: 900, marginTop: 4 }}>{draft.welcomeText.replace('Asli Dogan', displayProfile.name)}</div>
            </div>
            {draft.showPoints && (
              <div
                style={{
                  minWidth: 74,
                  borderRadius: 999,
                  background: 'rgba(239,68,68,.92)',
                  color: '#fff',
                  padding: '8px 10px',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: '.58rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '.08em', opacity: 0.8 }}>Puan</div>
                <div style={{ fontSize: '.92rem', fontWeight: 900, marginTop: 2 }}>{formatPoints(displayProfile.points)}</div>
              </div>
            )}
          </div>

          <div
            style={{
              borderRadius: 16,
              background: 'rgba(255,255,255,.08)',
              border: '1px solid rgba(255,255,255,.14)',
              padding: '10px 12px',
            }}
          >
            <div style={{ color: 'rgba(255,255,255,.7)', fontSize: '.68rem', lineHeight: 1.45 }}>{draft.announcementText}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
              <SmallBadge accent="#7c2d12" background="#fde68a">{displayProfile.level}</SmallBadge>
              <SmallBadge accent="#0f766e" background="#ccfbf1">{displayProfile.nextReward}</SmallBadge>
            </div>
          </div>
        </>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {primaryActions.map(action => {
          const meta = getPrimaryActionMeta(action.type)
          return (
            <button
              key={action.id}
              type="button"
              onClick={() => handleActionPress(action)}
              style={{
                textAlign: 'center',
                minHeight: 104,
                border: '1px solid rgba(255,255,255,.12)',
                borderRadius: radius,
                background: 'rgba(14,14,14,.82)',
                color: '#fff',
                padding: '12px',
                display: 'grid',
                justifyItems: 'center',
                alignContent: 'center',
                gap: 12,
              }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 14,
                  background: `${meta.color}1f`,
                  color: '#fff',
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <i className={`fa-solid ${action.icon || meta.icon}`} style={{ fontSize: '1rem' }} />
              </div>
              <div style={{ fontSize: '.88rem', fontWeight: 900, letterSpacing: '.01em', lineHeight: 1.2 }}>{action.label}</div>
            </button>
          )
        })}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 8 }}>
        {secondaryActions.map(action => (
          <button
            key={action.id}
            type="button"
            onClick={() => handleActionPress(action)}
            style={{
              borderRadius: 16,
              border: '1px solid rgba(255,255,255,.12)',
              background: 'rgba(255,255,255,.08)',
              color: '#fff',
              padding: '9px 6px',
              display: 'grid',
              justifyItems: 'center',
              gap: 5,
              minHeight: 58,
            }}
          >
            <i className={action.icon?.startsWith('fa-brands') ? action.icon : `fa-solid ${action.icon}`} style={{ fontSize: '.74rem' }} />
            <span style={{ fontSize: '.56rem', fontWeight: 800, textAlign: 'center', lineHeight: 1.2 }}>{action.label}</span>
          </button>
        ))}
      </div>

      {actionFeedback ? (
        <div style={{ borderRadius: 16, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.08)', padding: 10 }}>
          <div style={{ color: '#fff', fontSize: '.72rem', fontWeight: 800 }}>Baglanti notu</div>
          <div style={{ color: 'rgba(255,255,255,.72)', fontSize: '.68rem', lineHeight: 1.45, marginTop: 4 }}>{actionFeedback}</div>
        </div>
      ) : null}

      {configNotice ? (
        <div style={{ borderRadius: 16, border: '1px solid rgba(251,191,36,.28)', background: 'rgba(251,191,36,.14)', padding: 10 }}>
          <div style={{ color: '#fef3c7', fontSize: '.72rem', fontWeight: 800 }}>Konfigurasyon notu</div>
          <div style={{ color: '#fef3c7', fontSize: '.68rem', lineHeight: 1.45, marginTop: 4 }}>{configNotice}</div>
        </div>
      ) : null}
    </div>
  )

  const renderCampaigns = () => (
    <div style={{ display: 'grid', gap: 10 }}>
      <div style={loginCardStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center' }}>
          <div>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '.92rem' }}>Aktif kampanyalar</div>
            <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.68rem', marginTop: 4 }}>
              Bu ekranda mobil kanalda aktif olan kampanyalar listelenir.
            </div>
          </div>
          <SmallBadge accent="#065f46" background="#d1fae5">{visibleCampaigns.length} aktif</SmallBadge>
        </div>
      </div>

      {campaignError ? (
        <div style={{ borderRadius: 16, border: '1px solid rgba(248,113,113,.32)', background: 'rgba(127,29,29,.32)', padding: 10 }}>
          <div style={{ color: '#fecaca', fontWeight: 900, fontSize: '.74rem' }}>Kampanya verisi okunamadi</div>
          <div style={{ color: '#fecaca', fontSize: '.68rem', lineHeight: 1.45, marginTop: 4 }}>{campaignError}</div>
        </div>
      ) : null}

      {(draft.showCampaigns ? visibleCampaigns : []).map(campaign => (
        <div
          key={campaign.id}
          style={{
            borderRadius: 18,
            border: '1px solid rgba(255,255,255,.12)',
            background: 'rgba(255,255,255,.08)',
            padding: 10,
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center' }}>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '.8rem' }}>{campaign.name}</div>
            <SmallBadge accent="#7c2d12" background="#fde68a">mobil</SmallBadge>
          </div>
          <div style={{ color: 'rgba(255,255,255,.66)', fontSize: '.66rem', lineHeight: 1.4, marginTop: 6 }}>
            {campaign.description || 'Mobil kullaniciya kart olarak sunulan kampanya ozeti.'}
          </div>
        </div>
      ))}

      {!draft.showCampaigns && (
        <div style={loginCardStyle}>
          <div style={{ color: '#fff', fontWeight: 900, fontSize: '.92rem' }}>Kampanya kartlari gizli</div>
          <div style={{ color: 'rgba(255,255,255,.66)', fontSize: '.75rem', marginTop: 6, lineHeight: 1.55 }}>
            Panelde kampanya gorunurlugu kapandiginda kullanici sadece temel aksiyonlari gorur.
          </div>
        </div>
      )}
    </div>
  )

  const renderQr = () => (
    <div style={{ display: 'grid', gap: 10 }}>
      {draft.showQrCode && qrDataUrl && (dbCustomer || mode === 'management') ? (
        <div style={{ borderRadius: 20, background: '#fff', padding: 12, textAlign: 'center' }}>
          <img src={qrDataUrl} alt="Loyalty QR" style={{ width: '100%', maxWidth: 158, borderRadius: 14 }} />
          <div style={{ marginTop: 8, color: '#111827', fontWeight: 900, fontSize: '.82rem' }}>{displayProfile.name}</div>
          <div style={{ color: '#64748b', fontSize: '.64rem', marginTop: 4 }}>{dbCustomer ? 'DB eslesmesi aktif' : 'Taslak QR'}</div>
        </div>
      ) : draft.showQrCode && mode === 'public' ? (
        <div style={loginCardStyle}>
          <div style={{ color: '#fff', fontWeight: 900 }}>QR icin giris gerekli</div>
          <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.7rem', lineHeight: 1.45, marginTop: 6 }}>
            Musteri QR karti sadece gercek musteri eslesmesi sonrasinda olusturulur.
          </div>
        </div>
      ) : (
        <div style={loginCardStyle}>
          <div style={{ color: '#fff', fontWeight: 900 }}>QR gosterimi kapali</div>
        </div>
      )}

      {draft.showQrScanner && (
        <QrScannerCard onDetected={linkScannedSession} />
      )}

      <div style={{ color: 'rgba(255,255,255,.64)', fontSize: '.66rem', lineHeight: 1.45 }}>
        POS, Garson ve Kiosk ekranlarinda acilan baglanti QR kodlari bu alandan okutulabilir. Musteri girisi aciksa hesap ayni oturuma baglanir.
      </div>

      {scannedCode && (
        <div style={{ borderRadius: 16, border: '1px solid rgba(74,222,128,.28)', background: 'rgba(34,197,94,.14)', padding: 10 }}>
          <div style={{ color: '#dcfce7', fontWeight: 900, fontSize: '.74rem' }}>Okunan icerik</div>
          <div style={{ color: '#ecfccb', fontSize: '.68rem', lineHeight: 1.45, marginTop: 4 }}>{scannedCode}</div>
        </div>
      )}

      {scanLinkState.message ? (
        <div
          style={{
            borderRadius: 16,
            border: scanLinkState.status === 'error'
              ? '1px solid rgba(248,113,113,.32)'
              : scanLinkState.status === 'success'
                ? '1px solid rgba(74,222,128,.28)'
                : '1px solid rgba(191,219,254,.28)',
            background: scanLinkState.status === 'error'
              ? 'rgba(127,29,29,.32)'
              : scanLinkState.status === 'success'
                ? 'rgba(34,197,94,.14)'
                : 'rgba(59,130,246,.14)',
            padding: 10,
          }}
        >
          <div style={{ color: '#fff', fontWeight: 900, fontSize: '.74rem' }}>
            {scanLinkState.status === 'loading'
              ? 'Baglanti kontrolu'
              : scanLinkState.status === 'success'
                ? 'Baglanti tamamlandi'
                : scanLinkState.status === 'error'
                  ? 'Baglanti hatasi'
                  : 'QR notu'}
          </div>
          <div style={{ color: 'rgba(255,255,255,.82)', fontSize: '.68rem', lineHeight: 1.45, marginTop: 4 }}>
            {scanLinkState.message}
          </div>
        </div>
      ) : null}
    </div>
  )

  const renderAccount = () => {
    const accountProfile = dbCustomer || (mode === 'management' && previewLoggedIn ? draft.customer : null)

    if (!isLoggedInView || !accountProfile) {
      return (
        <div style={{ display: 'grid', gap: 10 }}>
          <div style={loginCardStyle}>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '.92rem' }}>Hesabim icin giris yapin</div>
            <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.72rem', lineHeight: 1.5, marginTop: 6 }}>
              Puan, kupon ve son siparis bilgileri yalnizca gercek musteri eslesmesi sonrasinda gosterilir.
            </div>
          </div>
        </div>
      )
    }

    return (
      <div style={{ display: 'grid', gap: 10 }}>
        <div style={loginCardStyle}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
            <div>
              <div style={{ color: '#fff', fontWeight: 900, fontSize: '.92rem' }}>{accountProfile.name}</div>
              <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.68rem', marginTop: 4 }}>
                Uyelik baslangici {accountProfile.memberSince}
              </div>
              <div style={{ color: 'rgba(255,255,255,.56)', fontSize: '.66rem', marginTop: 4 }}>
                {accountProfile.phone}
              </div>
            </div>
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: 14,
                background: 'rgba(255,255,255,.12)',
                color: '#fff',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1rem',
              }}
            >
              <i className="fa-solid fa-user" />
            </div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          <div style={loginCardStyle}>
            <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.62rem', textTransform: 'uppercase', letterSpacing: '.08em', fontWeight: 800 }}>
              Puan
            </div>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '1.05rem', marginTop: 6 }}>{formatPoints(accountProfile.points)}</div>
          </div>
          <div style={loginCardStyle}>
            <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.62rem', textTransform: 'uppercase', letterSpacing: '.08em', fontWeight: 800 }}>
              Kupon
            </div>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '1.05rem', marginTop: 6 }}>{accountProfile.availableCoupons}</div>
          </div>
          <div style={loginCardStyle}>
            <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.62rem', textTransform: 'uppercase', letterSpacing: '.08em', fontWeight: 800 }}>
              Ziyaret
            </div>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '1.05rem', marginTop: 6 }}>{accountProfile.visits}</div>
          </div>
        </div>

        <div style={loginCardStyle}>
          <div style={{ color: '#fff', fontWeight: 900, fontSize: '.8rem' }}>Onerilen sonraki adim</div>
          <div style={{ color: 'rgba(255,255,255,.7)', fontSize: '.68rem', marginTop: 5, lineHeight: 1.45 }}>
            {accountProfile.nextReward}
          </div>
        </div>

        {accountProfile.coupons?.length ? (
          <div style={loginCardStyle}>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '.8rem' }}>Hazir kuponlar</div>
            <div style={{ display: 'grid', gap: 8, marginTop: 8 }}>
              {accountProfile.coupons.slice(0, 3).map(coupon => (
                <div key={coupon.id} style={{ borderRadius: 14, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.06)', padding: 10 }}>
                  <div style={{ color: '#fff', fontWeight: 900, fontSize: '.74rem' }}>{coupon.code || 'Kupon'}</div>
                  <div style={{ color: 'rgba(255,255,255,.66)', fontSize: '.66rem', marginTop: 4 }}>
                    {coupon.expiresAt ? `Son kullanim ${formatDateTime(coupon.expiresAt)}` : 'Sure bilgisi yok'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <div style={loginCardStyle}>
          <div style={{ color: '#fff', fontWeight: 900, fontSize: '.8rem' }}>Son siparisler</div>
          {accountProfile.recentSales?.length ? (
            <div style={{ display: 'grid', gap: 8, marginTop: 8 }}>
              {accountProfile.recentSales.map(sale => (
                <div key={sale.id} style={{ borderRadius: 14, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.06)', padding: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
                    <div style={{ color: '#fff', fontWeight: 800, fontSize: '.72rem' }}>{sale.branchName || 'Sube bilgisi yok'}</div>
                    <div style={{ color: '#fff', fontWeight: 900, fontSize: '.72rem' }}>{formatCurrency(sale.total)}</div>
                  </div>
                  <div style={{ color: 'rgba(255,255,255,.62)', fontSize: '.64rem', marginTop: 4 }}>
                    {formatDateTime(sale.saleDateTime)} • {sale.source || 'satis'}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ color: 'rgba(255,255,255,.66)', fontSize: '.68rem', marginTop: 8 }}>
              Bu musteri icin okunabilir siparis kaydi bulunamadi.
            </div>
          )}
        </div>

        {accountProfile.dataWarnings?.length ? (
          <div style={{ borderRadius: 16, border: '1px solid rgba(251,191,36,.28)', background: 'rgba(251,191,36,.14)', padding: 10 }}>
            <div style={{ color: '#fef3c7', fontWeight: 900, fontSize: '.72rem' }}>Veri notu</div>
            <div style={{ color: '#fef3c7', fontSize: '.68rem', lineHeight: 1.45, marginTop: 4 }}>
              {accountProfile.dataWarnings.join(' ')}
            </div>
          </div>
        ) : null}
      </div>
    )
  }

  const renderBranches = () => (
    <div style={{ display: 'grid', gap: 10 }}>
      <div style={loginCardStyle}>
        <div style={{ color: '#fff', fontWeight: 900, fontSize: '.92rem' }}>Subeler</div>
        <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.7rem', marginTop: 4 }}>
          Veritabani baglamindan okunan sube listesi.
        </div>
      </div>

      {loadingBranches ? (
        <div style={loginCardStyle}>
          <div style={{ color: '#fff', fontSize: '.78rem' }}>Subeler yukleniyor...</div>
        </div>
      ) : null}

      {branchError ? (
        <div style={{ borderRadius: 16, border: '1px solid rgba(248,113,113,.32)', background: 'rgba(127,29,29,.32)', padding: 10 }}>
          <div style={{ color: '#fecaca', fontWeight: 900, fontSize: '.74rem' }}>Sube verisi okunamadi</div>
          <div style={{ color: '#fecaca', fontSize: '.68rem', lineHeight: 1.45, marginTop: 4 }}>{branchError}</div>
        </div>
      ) : null}

      {(branches || []).slice(0, 6).map(branch => (
        <div key={branch.branchId} style={{ borderRadius: 16, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.08)', padding: 10 }}>
          <div style={{ color: '#fff', fontWeight: 900, fontSize: '.78rem' }}>{branch.branchName}</div>
          <div style={{ color: 'rgba(255,255,255,.62)', fontSize: '.66rem', marginTop: 4 }}>
            {branch.companyName || 'Sirket bilgisi yok'}
          </div>
        </div>
      ))}
    </div>
  )

  const renderInfoScreen = (title, description) => (
    <div style={{ display: 'grid', gap: 10 }}>
      <div style={loginCardStyle}>
        <div style={{ color: '#fff', fontWeight: 900, fontSize: '.92rem' }}>{title}</div>
        <div style={{ color: 'rgba(255,255,255,.68)', fontSize: '.72rem', lineHeight: 1.5, marginTop: 6 }}>
          {description}
        </div>
      </div>
    </div>
  )

  const renderCurrentScreen = () => {
    if (screen === 'campaigns') return renderCampaigns()
    if (screen === 'qr' || screen === 'scan') return renderQr()
    if (screen === 'account') return renderAccount()
    if (screen === 'branches') return renderBranches()
    if (screen === 'order') return renderInfoScreen('Siparis', 'Siparis aksiyonu icin canli entegrasyon baglantisi tanimlandiginda bu ekran onunla degistirilebilir.')
    if (screen === 'reservation') return renderInfoScreen('Rezervasyon', 'Rezervasyon aksiyonu burada gercek entegrasyon veya form akisina baglanabilir.')
    if (screen === 'feedback') return renderInfoScreen('Gorus Bildir', 'Musteri geri bildirimi icin form veya harici servis baglantisi bu rotaya tasinabilir.')
    if (screen === 'support') return renderInfoScreen('Canli Destek', 'Destek aksiyonu icin WhatsApp, chat veya yardim merkezi baglantisi tanimlanabilir.')
    if (screen === 'menu') return renderInfoScreen('Dijital Menu', 'Menu aksiyonu icin gercek katalog veya siparis deneyimi baglanabilir.')
    return renderHome()
  }

  const phoneScreen = (
    <div
      style={{
        position: 'relative',
        overflow: 'hidden',
        borderRadius: isPublicAppRoute ? 0 : 30,
        height: isPublicAppRoute ? '100dvh' : 680,
        background: draft.customBackgroundDataUrl
          ? `linear-gradient(180deg, rgba(0,0,0,.48), rgba(0,0,0,.78)), url(${draft.customBackgroundDataUrl}) center / cover`
          : backgroundPreset.phone,
        padding: '10px 14px 76px',
        display: 'grid',
        gridTemplateRows: 'auto minmax(0, 1fr)',
        gap: 10,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {draft.logoDataUrl ? (
            <img
              src={draft.logoDataUrl}
              alt="Mobil app logo"
              style={{
                width: 46,
                height: 46,
                borderRadius: 18,
                objectFit: 'cover',
                boxShadow: '0 12px 28px rgba(0,0,0,.28)',
              }}
            />
          ) : (
            <div
              style={{
                width: 46,
                height: 46,
                borderRadius: 18,
                background: 'rgba(255,255,255,.1)',
                color: '#fff',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '.92rem',
                fontWeight: 900,
                boxShadow: '0 12px 28px rgba(0,0,0,.24)',
              }}
            >
              {draft.logoText}
            </div>
          )}
          <div>
            <div style={{ color: 'rgba(255,255,255,.74)', fontSize: '.58rem', textTransform: 'uppercase', letterSpacing: '.12em', fontWeight: 800 }}>
              Mobil sadakat
            </div>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: '1.05rem', marginTop: 3 }}>{draft.businessName}</div>
          </div>
        </div>
        <button
          type="button"
          style={{
            width: 34,
            height: 34,
            borderRadius: 12,
            border: '1px solid rgba(255,255,255,.16)',
            background: 'rgba(255,255,255,.08)',
            color: '#fff',
          }}
        >
          <i className="fa-solid fa-bars" />
        </button>
      </div>

      <div style={{ minHeight: 0, overflow: 'hidden' }}>
        {renderCurrentScreen()}
      </div>

      <div
        style={{
          position: 'absolute',
          left: 14,
          right: 14,
          bottom: 14,
          borderRadius: 18,
          border: '1px solid rgba(255,255,255,.12)',
          background: 'rgba(10,10,10,.72)',
          padding: '8px 10px',
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 6,
          backdropFilter: 'blur(12px)',
        }}
      >
        {MOBILE_TAB_OPTIONS.map(option => (
          <button
            key={`bottom-${option.value}`}
            type="button"
            onClick={() => changeTab(option.value)}
            style={{
              border: 'none',
              background: 'transparent',
              color: getNavigationTabForScreen(screen) === option.value ? '#fff' : 'rgba(255,255,255,.56)',
              display: 'grid',
              justifyItems: 'center',
              gap: 4,
              cursor: 'pointer',
            }}
          >
            <i className={`fa-solid ${option.icon}`} style={{ fontSize: '.8rem' }} />
            <span style={{ fontSize: '.58rem', fontWeight: 800 }}>{option.label}</span>
          </button>
        ))}
      </div>
    </div>
  )

  if (isPublicAppRoute) {
    return (
      <div style={{ minHeight: '100dvh', background: '#050505', display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: '100%', maxWidth: 480 }}>
          {phoneScreen}
        </div>
      </div>
    )
  }

  return (
    <div style={{ display: 'grid', gap: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <div>
          <div style={{ fontWeight: 900, color: '#0f172a' }}>Canli telefon onizlemesi</div>
          <div style={{ fontSize: '.77rem', color: '#64748b', marginTop: 4 }}>
            Mobil yuz tek ekrana sigacak sekilde kompaktlandi.
          </div>
        </div>
        <SmallBadge accent="#1d4ed8" background="#dbeafe">
          {draft.requireLogin ? (isLoggedInView ? 'Uye oturumu' : 'Telefon girisi') : 'Acik erisim'}
        </SmallBadge>
      </div>

      <div
        style={{
          margin: '0 auto',
          width: '100%',
          maxWidth: 362,
          padding: 10,
          borderRadius: 40,
          background: '#050505',
          boxShadow: '0 24px 70px rgba(15,23,42,.28)',
        }}
      >
        {phoneScreen}
      </div>
    </div>
  )
}

export function LoyaltyMobileAppPublic() {
  const {
    draft,
    configMeta,
    loadingConfig,
    configError,
  } = useLoyaltyMobileConfigState()
  const { activeCampaigns, campaignError } = useLoyaltyMobileCampaigns(
    configMeta.workspace.scope,
    configMeta.workspace.branchId,
    configMeta.workspace.branchName,
  )
  const { branches, loadingBranches, branchError } = useMobileBranches(true)

  const configNotice = loadingConfig
    ? 'Mobil app konfigurasyonu veritabanindan yukleniyor...'
    : (configError
        ? `DATABASE UNAVAILABLE: ${configError}`
        : (!configMeta.hasPersistedConfig ? 'CONFIG FALLBACK: Kayitli mobil app konfigurasyonu bulunamadi; varsayilan gorunum kullaniliyor.' : ''))

  return (
    <LoyaltyMobilePhonePreview
      draft={draft}
      campaigns={activeCampaigns}
      mode="public"
      campaignError={campaignError}
      configNotice={configNotice}
      branches={branches}
      loadingBranches={loadingBranches}
      branchError={branchError}
    />
  )
}

export default function LoyaltyMobileAppManagement() {
  const workspace = useWorkspace()
  const {
    draft,
    setDraft,
    configMeta,
    persistedDraftJson,
    loadingConfig,
    configError,
    savingConfig,
    saveError,
    reloadConfig,
    saveConfig,
  } = useLoyaltyMobileConfigState()
  const [linkFeedback, setLinkFeedback] = useState('')
  const [previewLoggedIn, setPreviewLoggedIn] = useState(true)
  const [saveFeedback, setSaveFeedback] = useState('')
  const { activeCampaigns, loadingCampaigns, campaignError } = useLoyaltyMobileCampaigns(workspace.scope, workspace.branchId, workspace.branchName)
  const { branches, loadingBranches, branchError } = useMobileBranches(true)
  const primaryActions = draft.primaryActions
  const secondaryActions = draft.secondaryActions
  const mobileAppLink = useMemo(() => getPublicMobileAppUrl(), [])
  const currentDraftJson = useMemo(
    () => JSON.stringify(sanitizeDraftForPersistence(draft)),
    [draft],
  )
  const hasUnsavedChanges = currentDraftJson !== persistedDraftJson

  const suggestedTargets = useMemo(() => {
    const rows = []

    primaryActions.forEach(action => {
      const meta = getPrimaryActionMeta(action.type)
      rows.push({
        id: action.id,
        label: action.label,
        href: action.href,
        icon: action.icon || meta.icon,
        note: meta.description,
      })
    })

    secondaryActions
      .filter(action => action.enabled)
      .forEach(action => {
        const meta = getSecondaryActionMeta(action.type)
        rows.push({
          id: action.id,
          label: action.label,
          href: action.href,
          icon: action.icon || meta.icon,
          note: 'Ikincil hizli erisim veya kampanya/kart altina baglanacak alan.',
        })
      })

    return rows
  }, [primaryActions, secondaryActions])

  const updateDraft = patch => {
    setDraft(current => normalizeDraft(typeof patch === 'function' ? patch(current) : { ...current, ...patch }))
  }

  const updatePrimaryAction = (id, field, value) => {
    updateDraft(current => ({
      ...current,
      primaryActions: current.primaryActions.map(item => (
        item.id === id ? { ...item, [field]: value } : item
      )),
    }))
  }

  const updatePrimaryActionType = (id, type) => {
    const meta = getPrimaryActionMeta(type)
    updateDraft(current => ({
      ...current,
      primaryActions: current.primaryActions.map(item => (
        item.id === id
          ? {
              ...item,
              type,
              label: meta.label,
              icon: meta.icon,
              href: meta.suggestedHref,
              note: meta.description,
            }
          : item
      )),
    }))
  }

  const updateSecondaryAction = (id, field, value) => {
    updateDraft(current => ({
      ...current,
      secondaryActions: current.secondaryActions.map(item => (
        item.id === id ? { ...item, [field]: value } : item
      )),
    }))
  }

  const updateSecondaryActionType = (id, type) => {
    const meta = getSecondaryActionMeta(type)
    updateDraft(current => ({
      ...current,
      secondaryActions: current.secondaryActions.map(item => (
        item.id === id
          ? {
              ...item,
              type,
              label: meta.label,
              icon: meta.icon,
              href: meta.suggestedHref,
            }
          : item
      )),
    }))
  }

  const handleImageUpload = async (field, file) => {
    if (!file) return
    try {
      const dataUrl = await readFileAsDataUrl(file)
      updateDraft({ [field]: dataUrl })
    } catch {
      // keep previous value when upload parsing fails
    }
  }

  const openMobileApp = () => {
    if (typeof window === 'undefined') return
    window.open(MOBILE_APP_BASE_PATH, '_blank', 'noopener,noreferrer')
  }

  const handleCopyMobileAppLink = async () => {
    const copied = await copyTextToClipboard(mobileAppLink)
    setLinkFeedback(copied ? 'Mobil app linki kopyalandi.' : 'Link kopyalanamadi.')
    window.setTimeout(() => setLinkFeedback(''), 2200)
  }

  const handleReloadFromDb = async () => {
    await reloadConfig()
    setSaveFeedback('Veritabanindaki konfigurasyon yeniden yuklendi.')
    window.setTimeout(() => setSaveFeedback(''), 2200)
  }

  const handleSaveToDb = async () => {
    const saved = await saveConfig(workspace)
    if (!saved) return
    setSaveFeedback('Mobil app konfigurasyonu veritabanina kaydedildi.')
    window.setTimeout(() => setSaveFeedback(''), 2600)
  }

  return (
    <div>
      <Header
        title="Mobil App Yonetimi"
        subtitle="Sadakat menusu altinda yer alacak mobil web app icin taslak arayuz, buton yapisi, QR akisi ve marka ozellestirme paneli."
        actions={(
          <>
            <button className="btn-o" type="button" onClick={handleReloadFromDb} disabled={loadingConfig || savingConfig}>
              Veritabanindan yenile
            </button>
            <button className="btn-p" type="button" onClick={handleSaveToDb} disabled={loadingConfig || savingConfig}>
              {savingConfig ? 'Kaydediliyor...' : 'Kaydet'}
            </button>
            <button className="btn-o" type="button" onClick={handleCopyMobileAppLink}>
              Linki kopyala
            </button>
            <button className="btn-o" type="button" onClick={openMobileApp}>
              Shortcut
            </button>
            <button className="btn-o" type="button" onClick={() => updateDraft(createDefaultDraft())}>
              Taslagi sifirla
            </button>
            <button className="btn-o" type="button" onClick={() => setPreviewLoggedIn(value => !value)}>
              {previewLoggedIn ? 'Giris ekrani gor' : 'Uye gorunumune don'}
            </button>
          </>
        )}
      />

      <div style={{ borderRadius: 18, border: '1px solid #bfdbfe', background: '#f8fbff', padding: 16, marginBottom: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16, alignItems: 'flex-start', flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontSize: '.74rem', color: '#1d4ed8', fontWeight: 900, letterSpacing: '.04em', textTransform: 'uppercase' }}>
              DB-backed Config
            </div>
            <div style={{ marginTop: 6, fontSize: '.88rem', color: '#334155', lineHeight: 1.65 }}>
              Mobil app gorunus ayarlari artik veritabanindaki `settings` tablosunda tutulur.
              Musteri, puan, kupon ve kampanya verileri ise kendi production tablolarindan okunur.
            </div>
          </div>
          <div style={{ display: 'grid', gap: 8, minWidth: 220 }}>
            <SmallBadge accent="#166534" background="#dcfce7">Data source: settings + loyalty + musteriler + sales</SmallBadge>
            <SmallBadge accent="#1d4ed8" background="#dbeafe">Environment: AWS self-hosted db</SmallBadge>
            <SmallBadge accent="#7c2d12" background="#fde68a">Write target: settings.{MOBILE_APP_SETTING_KEY}</SmallBadge>
            <SmallBadge accent={hasUnsavedChanges ? '#b45309' : '#166534'} background={hasUnsavedChanges ? '#fef3c7' : '#dcfce7'}>
              {hasUnsavedChanges ? 'Kaydedilmemis degisiklik var' : 'Degisiklikler kayitla uyumlu'}
            </SmallBadge>
          </div>
        </div>
      </div>

      {(configError || saveError || saveFeedback) ? (
        <div style={{ display: 'grid', gap: 10, marginBottom: 18 }}>
          {configError ? (
            <div style={{ borderRadius: 14, border: '1px solid #fca5a5', background: '#fff1f2', padding: 12, color: '#991b1b', fontSize: '.82rem', lineHeight: 1.5 }}>
              DATABASE UNAVAILABLE: {configError}
            </div>
          ) : null}
          {saveError ? (
            <div style={{ borderRadius: 14, border: '1px solid #fca5a5', background: '#fff1f2', padding: 12, color: '#991b1b', fontSize: '.82rem', lineHeight: 1.5 }}>
              Kayit hatasi: {saveError}
            </div>
          ) : null}
          {saveFeedback ? (
            <div style={{ borderRadius: 14, border: '1px solid #86efac', background: '#f0fdf4', padding: 12, color: '#166534', fontSize: '.82rem', lineHeight: 1.5 }}>
              {saveFeedback}
            </div>
          ) : null}
        </div>
      ) : null}

      <SectionCard
        title="Canli link ve shortcut"
        subtitle="Sidebar'a eklemeden mobil uygulamayi bu public route uzerinden acabilirsiniz."
        action={<SmallBadge accent="#166534" background="#dcfce7">Public route aktif</SmallBadge>}
      >
        <div style={{ display: 'grid', gap: 12 }}>
          <div style={{ borderRadius: 16, border: '1px solid #e2e8f0', background: '#fff', padding: 14 }}>
            <div style={{ fontSize: '.76rem', color: '#64748b', fontWeight: 800, marginBottom: 8 }}>Mobil app linki</div>
            <div style={{ fontSize: '.88rem', color: '#0f172a', fontWeight: 800, wordBreak: 'break-word' }}>{mobileAppLink}</div>
            <div style={{ fontSize: '.74rem', color: '#64748b', marginTop: 8, lineHeight: 1.5 }}>
              Bu link auth ve sidebar olmadan tam ekran mobil yuz aciyor. Alt sekmeler ve telefon ile musteri girisi calisir durumda.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <button className="btn-p" type="button" onClick={openMobileApp}>
              <i className="fa-solid fa-mobile-screen-button" style={{ marginRight: 8 }} />
              Mobil app shortcut
            </button>
            <button className="btn-o" type="button" onClick={handleCopyMobileAppLink}>
              <i className="fa-solid fa-link" style={{ marginRight: 8 }} />
              Linki kopyala
            </button>
          </div>
          {linkFeedback ? (
            <div style={{ fontSize: '.76rem', color: '#166534', fontWeight: 800 }}>{linkFeedback}</div>
          ) : null}
        </div>
      </SectionCard>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 12, marginBottom: 18 }}>
        <SummaryCard icon="fa-mobile-screen-button" label="Ana kutu" value="4" hint="Telefon et, siparis, rezervasyon, gorus vb." accent="#f97316" />
        <SummaryCard icon="fa-grip" label="Ikincil buton" value="8" hint="Panelden ac/kapat ve yeniden adlandir." accent="#1d4ed8" />
        <SummaryCard icon="fa-qrcode" label="QR akis" value={draft.showQrCode && draft.showQrScanner ? 'Goster + okut' : 'Kisitli'} hint="QR kodu gosterme ve okuma taslagi hazir." accent="#7c3aed" />
        <SummaryCard icon="fa-bullhorn" label="Aktif kampanya" value={loadingCampaigns ? '...' : String(activeCampaigns.length)} hint="Mevcut sadakat kampanyalari mobil kartlarda gorunebilir." accent="#059669" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.25fr) minmax(320px, .95fr)', gap: 18, alignItems: 'start' }}>
        <div style={{ display: 'grid', gap: 18 }}>
          <SectionCard title="Marka ve tema" subtitle="Isletme logosu, arka plan, aksan rengi ve buton sekilleri mobil yuzdeki genel havayi belirler.">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <Field label="Isletme adi"><input className="f-input" value={draft.businessName} onChange={event => updateDraft({ businessName: event.target.value })} /></Field>
              <Field label="Kisa slogan"><input className="f-input" value={draft.tagline} onChange={event => updateDraft({ tagline: event.target.value })} /></Field>
              <Field label="Hos geldin mesaji"><input className="f-input" value={draft.welcomeText} onChange={event => updateDraft({ welcomeText: event.target.value })} /></Field>
              <Field label="Ust bilgilendirme notu"><input className="f-input" value={draft.announcementText} onChange={event => updateDraft({ announcementText: event.target.value })} /></Field>
              <Field label="Logo kisaltmasi" hint="Logo yuklenmezse yuvarlak alanda bu harfler gorunur."><input className="f-input" value={draft.logoText} onChange={event => updateDraft({ logoText: event.target.value.slice(0, 3).toUpperCase() })} /></Field>
              <Field label="Aksan rengi" hint="Primary buton ve aktif sekme rengi."><input className="f-input" type="color" value={draft.accentColor} onChange={event => updateDraft({ accentColor: event.target.value })} style={{ height: 46, padding: 6 }} /></Field>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
              <Field label="Logo yukle" hint="PNG/JPG yukleyebilirsiniz. Kaydet dediginizde veritabanina yazilir.">
                <input className="f-input" type="file" accept="image/*" onChange={event => handleImageUpload('logoDataUrl', event.target.files?.[0])} />
              </Field>
              <Field label="Arka plan gorseli yukle" hint="Yuklenen gorsel secili presetin yerine kullanilir.">
                <input className="f-input" type="file" accept="image/*" onChange={event => handleImageUpload('customBackgroundDataUrl', event.target.files?.[0])} />
              </Field>
            </div>

            <div style={{ marginTop: 16 }}>
              <div style={{ fontSize: '.76rem', fontWeight: 800, color: '#64748b', marginBottom: 8 }}>Arka plan presetleri</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 10 }}>
                {BACKGROUND_PRESETS.map(preset => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => updateDraft({ activeBackgroundPreset: preset.id, customBackgroundDataUrl: '' })}
                    style={{
                      borderRadius: 16,
                      border: `2px solid ${draft.activeBackgroundPreset === preset.id && !draft.customBackgroundDataUrl ? '#fb923c' : '#e2e8f0'}`,
                      background: preset.preview,
                      color: '#fff',
                      minHeight: 90,
                      textAlign: 'left',
                      padding: 12,
                      display: 'grid',
                      alignContent: 'end',
                      fontWeight: 900,
                      cursor: 'pointer',
                    }}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ marginTop: 16 }}>
              <div style={{ fontSize: '.76rem', fontWeight: 800, color: '#64748b', marginBottom: 8 }}>Buton sekli</div>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {BUTTON_SHAPE_OPTIONS.map(option => (
                  <TogglePill key={option.value} active={draft.buttonShape === option.value} onClick={() => updateDraft({ buttonShape: option.value })} label={option.label} icon="fa-vector-square" accent="#f97316" />
                ))}
              </div>
            </div>
          </SectionCard>

          <SectionCard
            title="4 ana buton"
            subtitle="Ana ekranda 2x2 grid olarak duran ana cagri kutulari. Ilk taslakta Telefon Et, Siparis Ver, Rezervasyon ve Goruslerini Bildir akislari baz alindi."
          >
            <div style={{ display: 'grid', gap: 12 }}>
              {primaryActions.map(action => {
                const meta = getPrimaryActionMeta(action.type)
                return (
                  <div key={action.id} style={{ borderRadius: 16, border: '1px solid #e2e8f0', background: '#fff', padding: 14 }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '140px minmax(0, 1fr) minmax(0, 1fr)', gap: 12, alignItems: 'start' }}>
                      <Field label={action.slotLabel}>
                        <div className="sel-wrap">
                          <select className="f-input" value={action.type} onChange={event => updatePrimaryActionType(action.id, event.target.value)}>
                            {PRIMARY_ACTION_LIBRARY.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                          </select>
                        </div>
                      </Field>
                      <Field label="Buton metni"><input className="f-input" value={action.label} onChange={event => updatePrimaryAction(action.id, 'label', event.target.value)} /></Field>
                      <Field label="Hedef baglanti"><input className="f-input" value={action.href} onChange={event => updatePrimaryAction(action.id, 'href', event.target.value)} /></Field>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '120px minmax(0, 1fr) auto', gap: 12, alignItems: 'end', marginTop: 12 }}>
                      <Field label="Ikon"><input className="f-input" value={action.icon} onChange={event => updatePrimaryAction(action.id, 'icon', event.target.value)} /></Field>
                      <Field label="Kisa not" hint="Link yapisini sonra netlestirecegiz; simdilik taslak notu yazabilirsiniz.">
                        <input className="f-input" value={action.note} onChange={event => updatePrimaryAction(action.id, 'note', event.target.value)} />
                      </Field>
                      <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, minHeight: 46, fontSize: '.8rem', fontWeight: 800, color: '#475569' }}>
                        <input type="checkbox" checked={action.enabled} onChange={event => updatePrimaryAction(action.id, 'enabled', event.target.checked)} />
                        Aktif
                      </label>
                    </div>

                    <div style={{ marginTop: 10, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      <SmallBadge accent={meta.color} background={`${meta.color}18`}>{meta.label}</SmallBadge>
                      <SmallBadge accent="#64748b" background="#f8fafc">{meta.description}</SmallBadge>
                    </div>
                  </div>
                )
              })}
            </div>
          </SectionCard>

          <SectionCard
            title="8 ozellestirilebilir buton"
            subtitle="Kampanyalar, puanlar, QR, sube, destek ve benzeri ikincil aksiyonlar yatay kayan chip/mini butonlar olarak kurgulandi."
          >
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {secondaryActions.map(action => (
                <div key={action.id} style={{ borderRadius: 16, border: '1px solid #e2e8f0', background: '#fff', padding: 14 }}>
                  <div style={{ display: 'grid', gap: 10 }}>
                    <Field label="Buton tipi">
                      <div className="sel-wrap">
                        <select className="f-input" value={action.type} onChange={event => updateSecondaryActionType(action.id, event.target.value)}>
                          {SECONDARY_ACTION_LIBRARY.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                        </select>
                      </div>
                    </Field>
                    <Field label="Gorunen metin"><input className="f-input" value={action.label} onChange={event => updateSecondaryAction(action.id, 'label', event.target.value)} /></Field>
                    <Field label="Hedef baglanti"><input className="f-input" value={action.href} onChange={event => updateSecondaryAction(action.id, 'href', event.target.value)} /></Field>
                    <div style={{ display: 'grid', gridTemplateColumns: '120px auto', gap: 12, alignItems: 'end' }}>
                      <Field label="Ikon"><input className="f-input" value={action.icon} onChange={event => updateSecondaryAction(action.id, 'icon', event.target.value)} /></Field>
                      <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, minHeight: 46, fontSize: '.8rem', fontWeight: 800, color: '#475569' }}>
                        <input type="checkbox" checked={action.enabled} onChange={event => updateSecondaryAction(action.id, 'enabled', event.target.checked)} />
                        Aktif
                      </label>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard
            title="Sadakat deneyimi"
            subtitle="Musteri girisi, puan gosterimi, kampanya kartlari ve QR akislarinin nasil davranacagini bu karttan belirleyebilirsiniz."
          >
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
              <TogglePill active={draft.requireLogin} onClick={() => updateDraft({ requireLogin: !draft.requireLogin })} label="Musteri girisi zorunlu" icon="fa-lock" accent="#1d4ed8" />
              <TogglePill active={draft.showPoints} onClick={() => updateDraft({ showPoints: !draft.showPoints })} label="Puan rozetini goster" icon="fa-star" accent="#f97316" />
              <TogglePill active={draft.showCampaigns} onClick={() => updateDraft({ showCampaigns: !draft.showCampaigns })} label="Kampanya kartlarini goster" icon="fa-percent" accent="#059669" />
              <TogglePill active={draft.showQrCode} onClick={() => updateDraft({ showQrCode: !draft.showQrCode })} label="QR kodunu goster" icon="fa-qrcode" accent="#7c3aed" />
              <TogglePill active={draft.showQrScanner} onClick={() => updateDraft({ showQrScanner: !draft.showQrScanner })} label="QR okutma butonu" icon="fa-camera" accent="#0f766e" />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
              <Field label="Demo musteri adi">
                <input className="f-input" value={draft.customer.name} onChange={event => updateDraft(current => ({ ...current, customer: { ...current.customer, name: event.target.value } }))} />
              </Field>
              <Field label="Puan bakiyesi">
                <input className="f-input" value={draft.customer.points} onChange={event => updateDraft(current => ({ ...current, customer: { ...current.customer, points: event.target.value } }))} />
              </Field>
              <Field label="QR payload">
                <input className="f-input" value={draft.qrPayload} onChange={event => updateDraft({ qrPayload: event.target.value })} />
              </Field>
            </div>
          </SectionCard>

          <SectionCard
            title="Baglanti taslagi"
            subtitle="Linklerin hangi ekrana veya entegrasyona baglanacagini sonra netlestirecegiz. Bu liste, ilk taslakta hangi buton nereye baglansin sorusu icin calisma notu verir."
          >
            <div style={{ display: 'grid', gap: 10 }}>
              {suggestedTargets.map(row => (
                <LinkTargetRow key={row.id} label={row.label} href={row.href} icon={row.icon} note={row.note} />
              ))}
            </div>
          </SectionCard>
        </div>

        <div style={{ display: 'grid', gap: 18, position: 'sticky', top: 18 }}>
          <LoyaltyMobilePhonePreview
            draft={draft}
            campaigns={activeCampaigns}
            mode="management"
            previewLoggedIn={previewLoggedIn}
            campaignError={campaignError}
            branches={branches}
            loadingBranches={loadingBranches}
            branchError={branchError}
          />

          <SectionCard
            title="Canli kampanya baglantisi"
            subtitle="Bu alan, mevcut loyalty workspace&apos;teki aktif kampanyalari sadece okur. Mobil app kartlarina hangi kampanyalarin tasinacagini ikinci turda birlikte netlestirebiliriz."
          >
            {campaignError ? (
              <div style={{ fontSize: '.82rem', color: '#991b1b', lineHeight: 1.6, marginBottom: 10 }}>
                Kampanyalar okunamadi: {campaignError}
              </div>
            ) : null}
            {loadingCampaigns ? (
              <div style={{ fontSize: '.82rem', color: '#64748b' }}>
                <i className="fa-solid fa-spinner fa-spin" style={{ marginRight: 8 }} />
                Kampanyalar yukleniyor...
              </div>
            ) : activeCampaigns.length ? (
              <div style={{ display: 'grid', gap: 10 }}>
                {activeCampaigns.slice(0, 6).map(campaign => (
                  <div key={campaign.id} style={{ borderRadius: 14, border: '1px solid #e2e8f0', background: '#fff', padding: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center' }}>
                      <div style={{ fontWeight: 800, color: '#0f172a' }}>{campaign.name}</div>
                      <SmallBadge accent="#166534" background="#dcfce7">aktif</SmallBadge>
                    </div>
                    <div style={{ fontSize: '.76rem', color: '#64748b', marginTop: 6, lineHeight: 1.55 }}>
                      {campaign.description || 'Bu kampanya kart/slider yapisina tasinabilir.'}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ fontSize: '.82rem', color: '#64748b', lineHeight: 1.6 }}>
                Aktif kampanya okunamadi veya bu workspace icin kampanya bulunmuyor.
              </div>
            )}
          </SectionCard>
        </div>
      </div>
    </div>
  )
}
