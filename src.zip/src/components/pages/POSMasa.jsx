import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist/legacy/build/pdf.mjs'
import pdfWorker from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url'
import { useWorkspace } from '@/context/WorkspaceContext'
import {
  TABLE_LAYOUT_UPDATED_EVENT,
  hydrateTableLayoutFromDb,
  persistTableLayoutToDb,
  readLocalLayoutSnapshot,
} from '@/lib/posTablePersistence'

GlobalWorkerOptions.workerSrc = pdfWorker

const DEFAULT_FLOOR_COLOR = '#0b173a'

const STATUS_META = {
  empty: { label: 'Bos', code: 'y', color: '#22c55e', description: 'Yesil masa bos masayi temsil eder.' },
  occupied: { label: 'Dolu', code: 'k', color: '#ef4444', description: 'Kirmizi masa acik adisyon olan masayi temsil eder.' },
  reserved: { label: 'Rezerve', code: 'm', color: '#3b82f6', description: 'Mavi masa rezerveli masayi temsil eder.' },
}

const SHAPE_META = {
  round: { label: 'Yuvarlak', code: 'y', icon: 'fa-circle' },
  square: { label: 'Kare', code: 'k', icon: 'fa-square' },
}

const SEAT_OPTIONS = Array.from({ length: 10 }, (_, index) => index + 1)

const PRESET_ASSETS = SEAT_OPTIONS.flatMap(seats =>
  Object.entries(SHAPE_META).flatMap(([shape, shapeMeta]) =>
    Object.entries(STATUS_META).map(([status, statusMeta]) => {
      const id = `${shapeMeta.code}${seats}-${statusMeta.code}`
      return {
        id,
        shape,
        seats,
        status,
        label: `${shapeMeta.label} ${seats} Kisilik ${statusMeta.label}`,
        src: `/assets/masa-icons/${id}.pdf`,
      }
    }),
  ),
)

const PRESET_BY_ID = new Map(PRESET_ASSETS.map(asset => [asset.id, asset]))
const PDF_CACHE = new Map()
const PDF_PROMISES = new Map()

function uid(prefix) {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}`
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value))
}

function clampSeatCount(value) {
  return clamp(Number(value) || 1, 1, 10)
}

function hexToRgba(hex, alpha = 1) {
  const normalized = (hex || '#38bdf8').replace('#', '')
  const safe = normalized.length === 3
    ? normalized.split('').map(char => `${char}${char}`).join('')
    : normalized.padEnd(6, '0').slice(0, 6)
  const r = parseInt(safe.slice(0, 2), 16)
  const g = parseInt(safe.slice(2, 4), 16)
  const b = parseInt(safe.slice(4, 6), 16)
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

function getPresetId(shape, seats, status = 'empty') {
  const safeShape = SHAPE_META[shape] ? shape : 'round'
  const safeSeats = clampSeatCount(seats)
  const safeStatus = STATUS_META[status] ? status : 'empty'
  return `${SHAPE_META[safeShape].code}${safeSeats}-${STATUS_META[safeStatus].code}`
}

function getPreset(shape, seats, status = 'empty') {
  return PRESET_BY_ID.get(getPresetId(shape, seats, status)) || null
}

function getTableSize(shape, seats) {
  const safeSeats = clampSeatCount(seats)
  const base = shape === 'square' ? 10 + safeSeats * 1.9 : 11 + safeSeats * 2.1
  const size = clamp(base, 14, 34)
  return { w: size, h: size }
}

function createZone(index) {
  return {
    id: uid('zone'),
    name: `Bolge ${index}`,
    x: 8 + ((index - 1) % 3) * 8,
    y: 10 + ((index - 1) % 2) * 7,
    w: 30,
    h: 24,
    color: '#38bdf8',
    opacity: 0.14,
  }
}

function createTable(index, options = {}) {
  const shape = SHAPE_META[options.shape] ? options.shape : 'round'
  const seats = clampSeatCount(options.seats ?? 4)
  const status = STATUS_META[options.status] ? options.status : 'empty'
  const size = getTableSize(shape, seats)
  return {
    id: uid('table'),
    name: options.name || `Masa ${String(index).padStart(2, '0')}`,
    shape,
    seats,
    status,
    x: 18 + ((index - 1) % 4) * 16,
    y: 18 + ((index - 1) % 3) * 16,
    w: size.w,
    h: size.h,
    zoneId: options.zoneId || '',
  }
}

function createFloor(index) {
  const zone = createZone(1)
  const tableA = createTable(1, { shape: 'round', seats: 4, zoneId: zone.id })
  const tableB = createTable(2, { shape: 'square', seats: 4, zoneId: zone.id })
  const tableC = createTable(3, { shape: 'round', seats: 6 })
  return {
    id: uid('floor'),
    name: `Kat ${index}`,
    bgColor: DEFAULT_FLOOR_COLOR,
    bgImage: '',
    zones: [zone],
    tables: [tableA, tableB, tableC],
  }
}

function getDefaultEditor() {
  const firstFloor = createFloor(1)
  const secondFloor = createFloor(2)
  secondFloor.name = 'Teras'
  secondFloor.bgColor = '#12203f'
  secondFloor.zones[0].name = 'Dis Alan'
  secondFloor.tables[0].name = 'Teras 01'
  secondFloor.tables[1].name = 'Teras 02'
  secondFloor.tables[2].name = 'Teras 03'
  return { activeFloorId: firstFloor.id, floors: [firstFloor, secondFloor] }
}

function normalizeEditor(raw) {
  if (!raw || !Array.isArray(raw.floors) || raw.floors.length === 0) return getDefaultEditor()
  const floors = raw.floors.map((floor, floorIndex) => ({
    id: floor.id || uid('floor'),
    name: floor.name || `Kat ${floorIndex + 1}`,
    bgColor: floor.bgColor || DEFAULT_FLOOR_COLOR,
    bgImage: floor.bgImage || '',
    zones: Array.isArray(floor.zones) ? floor.zones.map((zone, zoneIndex) => ({
      id: zone.id || uid('zone'),
      name: zone.name || `Bolge ${zoneIndex + 1}`,
      x: Number.isFinite(zone.x) ? zone.x : 10,
      y: Number.isFinite(zone.y) ? zone.y : 10,
      w: Number.isFinite(zone.w) ? zone.w : 30,
      h: Number.isFinite(zone.h) ? zone.h : 24,
      color: zone.color || '#38bdf8',
      opacity: Number.isFinite(zone.opacity) ? zone.opacity : 0.14,
    })) : [],
    tables: Array.isArray(floor.tables) ? floor.tables.map((table, tableIndex) => {
      const shape = SHAPE_META[table.shape] ? table.shape : 'round'
      const seats = clampSeatCount(table.seats ?? 4)
      const size = getTableSize(shape, seats)
      return {
        id: table.id || uid('table'),
        name: table.name || `Masa ${tableIndex + 1}`,
        shape,
        seats,
        status: STATUS_META[table.status] ? table.status : 'empty',
        x: Number.isFinite(table.x) ? table.x : 20,
        y: Number.isFinite(table.y) ? table.y : 20,
        w: Number.isFinite(table.w) ? table.w : size.w,
        h: Number.isFinite(table.h) ? table.h : size.h,
        zoneId: table.zoneId || '',
      }
    }) : [],
  }))
  const activeFloorId = floors.some(floor => floor.id === raw.activeFloorId) ? raw.activeFloorId : floors[0].id
  return { activeFloorId, floors }
}

async function renderPdfPreview(src) {
  if (!src) return ''
  if (PDF_CACHE.has(src)) return PDF_CACHE.get(src)
  if (PDF_PROMISES.has(src)) return PDF_PROMISES.get(src)

  const promise = (async () => {
    const pdf = await getDocument(src).promise
    const page = await pdf.getPage(1)
    const viewport = page.getViewport({ scale: 1.8 })
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('2d', { alpha: true })

    canvas.width = Math.ceil(viewport.width)
    canvas.height = Math.ceil(viewport.height)

    await page.render({
      canvasContext: context,
      viewport,
      background: 'rgba(0,0,0,0)',
    }).promise

    const dataUrl = canvas.toDataURL('image/png')
    PDF_CACHE.set(src, dataUrl)
    PDF_PROMISES.delete(src)
    return dataUrl
  })().catch(error => {
    PDF_PROMISES.delete(src)
    throw error
  })

  PDF_PROMISES.set(src, promise)
  return promise
}

function usePdfPreview(src) {
  const [preview, setPreview] = useState(() => (src && PDF_CACHE.has(src) ? PDF_CACHE.get(src) : ''))

  useEffect(() => {
    let cancelled = false
    if (!src) {
      setPreview('')
      return undefined
    }
    if (PDF_CACHE.has(src)) {
      setPreview(PDF_CACHE.get(src))
      return undefined
    }
    renderPdfPreview(src)
      .then(dataUrl => {
        if (!cancelled) setPreview(dataUrl)
      })
      .catch(() => {
        if (!cancelled) setPreview('')
      })
    return () => {
      cancelled = true
    }
  }, [src])

  return preview
}

function TablePresetGraphic({ table, className }) {
  const preset = getPreset(table.shape, table.seats, table.status)
  const preview = usePdfPreview(preset?.src || '')
  if (!preview) return <div className={`${className} preset-loading`} />
  return <img src={preview} alt={preset?.label || table.name} className={className} draggable="false" />
}

const QUICK_ACTIONS = [
  { id: 'new-floor', label: 'Yeni Kat', icon: 'fa-layer-group', accent: '#fbbf24' },
  { id: 'new-zone', label: 'Bolge Ciz', icon: 'fa-draw-polygon', accent: '#38bdf8' },
  { id: 'new-table', label: 'Preset Masa', icon: 'fa-table-cells-large', accent: '#34d399' },
  { id: 'bg-edit', label: 'Zemin Ayari', icon: 'fa-image', accent: '#f97316' },
]

export default function POSMasa() {
  const navigate = useNavigate()
  const { branchName } = useWorkspace()
  const canvasRef = useRef(null)
  const imageInputRef = useRef(null)
  const initialEditor = useMemo(() => normalizeEditor(readLocalLayoutSnapshot()), [])
  const [editor, setEditor] = useState(() => initialEditor)
  const [selection, setSelection] = useState(() => ({ type: 'floor', id: initialEditor.activeFloorId }))
  const [showGrid, setShowGrid] = useState(true)
  const [dragState, setDragState] = useState(null)
  const [isTableCreatorOpen, setIsTableCreatorOpen] = useState(false)
  const [tableDraft, setTableDraft] = useState({ shape: 'round', seats: 4 })
  const [saveBusy, setSaveBusy] = useState(false)

  const activeFloor = useMemo(() => editor.floors.find(floor => floor.id === editor.activeFloorId) || editor.floors[0], [editor])
  const selectedZone = selection.type === 'zone' ? activeFloor?.zones.find(zone => zone.id === selection.id) || null : null
  const selectedTable = selection.type === 'table' ? activeFloor?.tables.find(table => table.id === selection.id) || null : null
  const selectedPreset = selectedTable ? getPreset(selectedTable.shape, selectedTable.seats, selectedTable.status) : null

  useEffect(() => {
    let cancelled = false

    hydrateTableLayoutFromDb()
      .then(remoteLayout => {
        if (cancelled || !remoteLayout) return
        const nextEditor = normalizeEditor(remoteLayout)
        setEditor(nextEditor)
        setSelection(current => (
          current?.id && nextEditor.floors.some(floor => floor.id === current.id)
            ? current
            : { type: 'floor', id: nextEditor.activeFloorId }
        ))
      })
      .catch(error => {
        if (!cancelled) console.error('POSMasa layout hydrate failed', error)
      })

    const handleLayoutUpdated = () => {
      hydrateTableLayoutFromDb()
        .then(remoteLayout => {
          if (!remoteLayout) return
          const nextEditor = normalizeEditor(remoteLayout)
          setEditor(nextEditor)
        })
        .catch(error => console.error('POSMasa layout refresh failed', error))
    }

    window.addEventListener(TABLE_LAYOUT_UPDATED_EVENT, handleLayoutUpdated)
    return () => {
      cancelled = true
      window.removeEventListener(TABLE_LAYOUT_UPDATED_EVENT, handleLayoutUpdated)
    }
  }, [])

  function updateEditor(updater) {
    setEditor(prev => normalizeEditor(typeof updater === 'function' ? updater(prev) : updater))
  }

  function updateActiveFloor(updater) {
    updateEditor(prev => ({
      ...prev,
      floors: prev.floors.map(floor => floor.id === prev.activeFloorId ? updater(floor) : floor),
    }))
  }

  function patchActiveZone(zoneId, updater) {
    updateActiveFloor(floor => ({
      ...floor,
      zones: floor.zones.map(zone => (zone.id === zoneId ? updater(zone) : zone)),
    }))
  }

  function patchActiveTable(tableId, updater) {
    updateActiveFloor(floor => ({
      ...floor,
      tables: floor.tables.map(table => (table.id === tableId ? updater(table) : table)),
    }))
  }

  function setActiveFloor(floorId) {
    updateEditor(prev => ({ ...prev, activeFloorId: floorId }))
    setSelection({ type: 'floor', id: floorId })
  }

  function addFloor() {
    updateEditor(prev => {
      const floor = createFloor(prev.floors.length + 1)
      setSelection({ type: 'floor', id: floor.id })
      return { activeFloorId: floor.id, floors: [...prev.floors, floor] }
    })
  }

  function addZone() {
    if (!activeFloor) return
    const zone = createZone(activeFloor.zones.length + 1)
    updateActiveFloor(floor => ({ ...floor, zones: [...floor.zones, zone] }))
    setSelection({ type: 'zone', id: zone.id })
  }

  function openTableCreator() {
    setTableDraft({ shape: 'round', seats: 4 })
    setIsTableCreatorOpen(true)
  }

  async function saveLayoutAndOpenTables() {
    setSaveBusy(true)
    try {
      await persistTableLayoutToDb(editor)
      navigate('/garson')
    } catch (error) {
      console.error('POSMasa layout save failed', error)
    } finally {
      setSaveBusy(false)
    }
  }

  function confirmAddTable() {
    if (!activeFloor) return
    const table = createTable(activeFloor.tables.length + 1, {
      shape: tableDraft.shape,
      seats: tableDraft.seats,
      status: 'empty',
      zoneId: selectedZone?.id || '',
    })
    updateActiveFloor(floor => ({ ...floor, tables: [...floor.tables, table] }))
    setSelection({ type: 'table', id: table.id })
    setIsTableCreatorOpen(false)
  }

  function removeSelection() {
    if (!activeFloor) return
    if (selection.type === 'floor') {
      if (editor.floors.length === 1) return
      updateEditor(prev => {
        const floors = prev.floors.filter(floor => floor.id !== selection.id)
        const nextFloorId = floors[0]?.id || ''
        setSelection({ type: 'floor', id: nextFloorId })
        return { activeFloorId: nextFloorId, floors }
      })
      return
    }
    if (selection.type === 'zone') {
      updateActiveFloor(floor => ({
        ...floor,
        zones: floor.zones.filter(zone => zone.id !== selection.id),
        tables: floor.tables.map(table => table.zoneId === selection.id ? { ...table, zoneId: '' } : table),
      }))
      setSelection({ type: 'floor', id: activeFloor.id })
      return
    }
    updateActiveFloor(floor => ({ ...floor, tables: floor.tables.filter(table => table.id !== selection.id) }))
    setSelection({ type: 'floor', id: activeFloor.id })
  }

  function duplicateSelectedTable() {
    if (!activeFloor || !selectedTable) return
    const copy = {
      ...selectedTable,
      id: uid('table'),
      name: `${selectedTable.name} Kopya`,
      x: clamp(selectedTable.x + 4, 0, 100 - selectedTable.w),
      y: clamp(selectedTable.y + 4, 0, 100 - selectedTable.h),
    }
    updateActiveFloor(floor => ({ ...floor, tables: [...floor.tables, copy] }))
    setSelection({ type: 'table', id: copy.id })
  }

  function updateFloorField(field, value) {
    updateActiveFloor(floor => ({ ...floor, [field]: value }))
  }

  function updateZoneField(field, value) {
    if (!selectedZone) return
    patchActiveZone(selectedZone.id, zone => ({ ...zone, [field]: value }))
  }

  function updateTableField(field, value) {
    if (!selectedTable) return
    patchActiveTable(selectedTable.id, table => {
      const next = { ...table, [field]: value }
      if (field === 'shape' || field === 'seats') {
        next.shape = field === 'shape' ? value : next.shape
        next.seats = field === 'seats' ? clampSeatCount(value) : next.seats
        const size = getTableSize(next.shape, next.seats)
        next.w = size.w
        next.h = size.h
      }
      return next
    })
  }

  function startResize(event, tableId) {
    if (!canvasRef.current || !activeFloor) return
    event.preventDefault()
    event.stopPropagation()
    const rect = canvasRef.current.getBoundingClientRect()
    const pointerX = ((event.clientX - rect.left) / rect.width) * 100
    const pointerY = ((event.clientY - rect.top) / rect.height) * 100
    const table = activeFloor.tables.find(item => item.id === tableId)
    if (!table) return
    setSelection({ type: 'table', id: tableId })
    setDragState({
      type: 'table-resize',
      id: tableId,
      startX: pointerX,
      startY: pointerY,
      startSize: Math.max(table.w, table.h),
    })
  }

  function startDrag(event, type, id) {
    if (!canvasRef.current || !activeFloor) return
    event.preventDefault()
    event.stopPropagation()
    const rect = canvasRef.current.getBoundingClientRect()
    const pointerX = ((event.clientX - rect.left) / rect.width) * 100
    const pointerY = ((event.clientY - rect.top) / rect.height) * 100
    const item = type === 'zone'
      ? activeFloor.zones.find(zone => zone.id === id)
      : activeFloor.tables.find(table => table.id === id)
    if (!item) return
    setSelection({ type, id })
    setDragState({ type, id, offsetX: pointerX - item.x, offsetY: pointerY - item.y })
  }

  useEffect(() => {
    if (!dragState || !activeFloor) return undefined
    function handleMove(event) {
      if (!canvasRef.current) return
      const rect = canvasRef.current.getBoundingClientRect()
      const pointerX = ((event.clientX - rect.left) / rect.width) * 100
      const pointerY = ((event.clientY - rect.top) / rect.height) * 100
      if (dragState.type === 'zone') {
        const zone = activeFloor.zones.find(item => item.id === dragState.id)
        if (!zone) return
        patchActiveZone(zone.id, current => ({
          ...current,
          x: clamp(pointerX - dragState.offsetX, 0, 100 - current.w),
          y: clamp(pointerY - dragState.offsetY, 0, 100 - current.h),
        }))
      } else if (dragState.type === 'table') {
        const table = activeFloor.tables.find(item => item.id === dragState.id)
        if (!table) return
        patchActiveTable(table.id, current => ({
          ...current,
          x: clamp(pointerX - dragState.offsetX, 0, 100 - current.w),
          y: clamp(pointerY - dragState.offsetY, 0, 100 - current.h),
        }))
      } else {
        const table = activeFloor.tables.find(item => item.id === dragState.id)
        if (!table) return
        patchActiveTable(table.id, current => {
          const delta = Math.max(pointerX - dragState.startX, pointerY - dragState.startY)
          const size = clamp(dragState.startSize + delta, 14, 40)
          return { ...current, w: size, h: size }
        })
      }
    }
    function handleUp() {
      setDragState(null)
    }
    window.addEventListener('pointermove', handleMove)
    window.addEventListener('pointerup', handleUp)
    return () => {
      window.removeEventListener('pointermove', handleMove)
      window.removeEventListener('pointerup', handleUp)
    }
  }, [dragState, activeFloor])

  function handleImagePick(event) {
    const file = event.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = loadEvent => updateFloorField('bgImage', loadEvent.target?.result || '')
    reader.readAsDataURL(file)
  }

  const zoneCounts = useMemo(() => (
    (activeFloor?.zones || []).reduce((acc, zone) => ({ ...acc, [zone.id]: activeFloor.tables.filter(table => table.zoneId === zone.id).length }), {})
  ), [activeFloor])

  const inspectorTitle = selection.type === 'floor'
    ? 'Kat Ayarlari'
    : selection.type === 'zone'
      ? 'Bolge Ayarlari'
      : 'Masa Ayarlari'

  return (
    <div className="layout-shell">
      <input ref={imageInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleImagePick} />

      <header className="layout-topbar">
        <div>
          <div className="layout-kicker">POS / Yerlesim Tasarim Araci</div>
          <h1>Masa Plani Editoru</h1>
        </div>
        <div className="layout-actions">
          <span className="layout-badge">{branchName || 'Aktif sube'}</span>
          <button className="layout-btn" onClick={saveLayoutAndOpenTables} disabled={saveBusy}>
            <i className="fa-solid fa-floppy-disk" /> {saveBusy ? 'Kaydediliyor' : 'Kaydet'}
          </button>
        </div>
      </header>

      <div className="layout-toolbar">
        <button className="layout-pill" onClick={addFloor}><i className="fa-solid fa-layer-group" /> Kat Ekle</button>
        <button className="layout-pill" onClick={addZone}><i className="fa-solid fa-draw-polygon" /> Bolge Ekle</button>
        <button className="layout-pill accent-green" onClick={openTableCreator}><i className="fa-solid fa-table-cells-large" /> Masa Ekle</button>
      </div>

      <main className="layout-main">
        <aside className="layout-panel left">
          <div className="panel-title">Katlar</div>
          <div className="floor-list">
            {editor.floors.map(floor => (
              <button key={floor.id} className={`floor-item ${floor.id === activeFloor?.id ? 'active' : ''}`} onClick={() => setActiveFloor(floor.id)}>
                <div>
                  <strong>{floor.name}</strong>
                  <span>{floor.tables.length} masa, {floor.zones.length} bolge</span>
                </div>
                <i className="fa-solid fa-chevron-right" />
              </button>
            ))}
          </div>

          <div className="panel-title spaced">Bu Katta</div>
          <div className="mini-list">
            {(activeFloor?.zones || []).map(zone => (
              <button key={zone.id} className={`mini-item ${selection.type === 'zone' && selection.id === zone.id ? 'active' : ''}`} onClick={() => setSelection({ type: 'zone', id: zone.id })}>
                <span className="mini-dot" style={{ background: zone.color }} />
                {zone.name} <small>{zoneCounts[zone.id] || 0}</small>
              </button>
            ))}
          </div>
        </aside>

        <section className="canvas-panel">
          <div className="canvas-header">
            <div>
              <strong>{activeFloor?.name}</strong>
              <span>Masalari veya bolgeleri surukleyerek yerlestir.</span>
            </div>
            <div className="stack-row">
              {QUICK_ACTIONS.map(action => (
                <span key={action.id} className="quick-chip"><i className={`fa-solid ${action.icon}`} style={{ color: action.accent }} /> {action.label}</span>
              ))}
            </div>
          </div>

          <div className="canvas-frame">
            <div
              ref={canvasRef}
              className={`canvas-surface ${showGrid ? 'show-grid' : ''}`}
              style={{
                backgroundColor: activeFloor?.bgColor || DEFAULT_FLOOR_COLOR,
                '--surface-image': activeFloor?.bgImage ? `url(${activeFloor.bgImage})` : 'none',
                backgroundImage: activeFloor?.bgImage
                  ? `linear-gradient(rgba(4,8,28,.28), rgba(4,8,28,.28)), url(${activeFloor.bgImage})`
                  : undefined,
              }}
              onPointerDown={() => setSelection({ type: 'floor', id: activeFloor?.id })}
            >
              {(activeFloor?.zones || []).map(zone => (
                <button
                  key={zone.id}
                  type="button"
                  className={`zone-box ${selection.type === 'zone' && selection.id === zone.id ? 'active' : ''}`}
                  style={{
                    left: `${zone.x}%`,
                    top: `${zone.y}%`,
                    width: `${zone.w}%`,
                    height: `${zone.h}%`,
                    background: hexToRgba(zone.color, zone.opacity),
                    borderColor: hexToRgba(zone.color, 0.65),
                  }}
                  onClick={event => {
                    event.stopPropagation()
                    setSelection({ type: 'zone', id: zone.id })
                  }}
                  onPointerDown={event => startDrag(event, 'zone', zone.id)}
                >
                  <span>{zone.name}</span>
                </button>
              ))}

              {(activeFloor?.tables || []).map(table => {
                const statusMeta = STATUS_META[table.status] || STATUS_META.empty
                return (
                  <button
                    key={table.id}
                    type="button"
                    className={`table-box preset ${selection.type === 'table' && selection.id === table.id ? 'active' : ''}`}
                    style={{
                      left: `${table.x}%`,
                      top: `${table.y}%`,
                      width: `${table.w}%`,
                      height: `${table.h}%`,
                      '--status-glow': hexToRgba(statusMeta.color, 0.42),
                    }}
                    onClick={event => {
                      event.stopPropagation()
                      setSelection({ type: 'table', id: table.id })
                    }}
                    onPointerDown={event => startDrag(event, 'table', table.id)}
                  >
                    <div className="table-asset-shell">
                      <TablePresetGraphic table={table} className="table-asset-image" />
                    </div>
                    <span className="table-asset-label">{table.name}</span>
                    {selection.type === 'table' && selection.id === table.id && (
                      <span className="resize-handle" onPointerDown={event => startResize(event, table.id)}>
                        <i className="fa-solid fa-up-right-and-down-left-from-center" />
                      </span>
                    )}
                  </button>
                )
              })}
            </div>
          </div>
        </section>

        <aside className="layout-panel right">
          <div className="panel-title">{inspectorTitle}</div>
          <button className="layout-btn ghost inspector-grid-toggle" onClick={() => setShowGrid(value => !value)}>
            <i className="fa-solid fa-border-all" /> {showGrid ? 'Grid Acik' : 'Grid Kapali'}
          </button>

          {selection.type === 'floor' && activeFloor && (
            <div className="inspector-stack">
              <label className="field">
                <span>Kat adi</span>
                <input value={activeFloor.name} onChange={event => updateFloorField('name', event.target.value)} />
              </label>
              <label className="field">
                <span>Zemin rengi</span>
                <input type="color" value={activeFloor.bgColor} onChange={event => updateFloorField('bgColor', event.target.value)} />
              </label>
              <div className="field actions-field">
                <span>Arka plan gorseli</span>
                <div className="stack-row">
                  <button className="layout-btn ghost small" onClick={() => imageInputRef.current?.click()}>
                    <i className="fa-solid fa-image" /> Gorsel Yukle
                  </button>
                  <button className="layout-btn ghost small" onClick={() => updateFloorField('bgImage', '')}>
                    <i className="fa-solid fa-trash" /> Temizle
                  </button>
                </div>
                <small>Gorsel sadece bu tarayicida saklanir.</small>
              </div>
              <button className="layout-btn danger" onClick={removeSelection}>
                <i className="fa-solid fa-trash" /> Bu kati sil
              </button>
            </div>
          )}

          {selection.type === 'zone' && selectedZone && (
            <div className="inspector-stack">
              <label className="field">
                <span>Bolge adi</span>
                <input value={selectedZone.name} onChange={event => updateZoneField('name', event.target.value)} />
              </label>
              <label className="field">
                <span>Bolge rengi</span>
                <input type="color" value={selectedZone.color} onChange={event => updateZoneField('color', event.target.value)} />
              </label>
              <label className="field">
                <span>Gorunurluk</span>
                <input type="range" min="0.05" max="0.4" step="0.01" value={selectedZone.opacity} onChange={event => updateZoneField('opacity', Number(event.target.value))} />
              </label>
              <div className="field-grid">
                <label className="field"><span>X</span><input type="number" value={selectedZone.x} onChange={event => updateZoneField('x', clamp(Number(event.target.value), 0, 100 - selectedZone.w))} /></label>
                <label className="field"><span>Y</span><input type="number" value={selectedZone.y} onChange={event => updateZoneField('y', clamp(Number(event.target.value), 0, 100 - selectedZone.h))} /></label>
                <label className="field"><span>Genislik</span><input type="number" value={selectedZone.w} onChange={event => updateZoneField('w', clamp(Number(event.target.value), 8, 100 - selectedZone.x))} /></label>
                <label className="field"><span>Yukseklik</span><input type="number" value={selectedZone.h} onChange={event => updateZoneField('h', clamp(Number(event.target.value), 8, 100 - selectedZone.y))} /></label>
              </div>
              <button className="layout-btn danger" onClick={removeSelection}>
                <i className="fa-solid fa-trash" /> Bolgeyi sil
              </button>
            </div>
          )}

          {selection.type === 'table' && selectedTable && (
            <div className="inspector-stack">
              <label className="field">
                <span>Masa adi</span>
                <input value={selectedTable.name} onChange={event => updateTableField('name', event.target.value)} />
              </label>
              <div className="field-grid">
                <label className="field">
                  <span>Masa tipi</span>
                  <select value={selectedTable.shape} onChange={event => updateTableField('shape', event.target.value)}>
                    <option value="round">Yuvarlak</option>
                    <option value="square">Kare</option>
                  </select>
                </label>
                <label className="field">
                  <span>Sandalye</span>
                  <input type="number" min="1" max="10" value={selectedTable.seats} onChange={event => updateTableField('seats', clampSeatCount(event.target.value))} />
                </label>
              </div>
              <div className="field">
                <span>Masa durumu</span>
                <div className="status-row">
                  {Object.entries(STATUS_META).map(([statusKey, meta]) => (
                    <button
                      key={statusKey}
                      type="button"
                      className={`status-pill ${selectedTable.status === statusKey ? 'active' : ''}`}
                      style={{ '--pill-color': meta.color }}
                      onClick={() => updateTableField('status', statusKey)}
                    >
                      <span className="status-dot" />
                      {meta.label}
                    </button>
                  ))}
                </div>
                <small>{STATUS_META[selectedTable.status]?.description}</small>
              </div>
              <label className="field">
                <span>Bagli bolge</span>
                <select value={selectedTable.zoneId} onChange={event => updateTableField('zoneId', event.target.value)}>
                  <option value="">Bolgesiz</option>
                  {activeFloor?.zones.map(zone => <option key={zone.id} value={zone.id}>{zone.name}</option>)}
                </select>
              </label>
              <div className="field-grid">
                <label className="field"><span>X</span><input type="number" value={selectedTable.x} onChange={event => updateTableField('x', clamp(Number(event.target.value), 0, 100 - selectedTable.w))} /></label>
                <label className="field"><span>Y</span><input type="number" value={selectedTable.y} onChange={event => updateTableField('y', clamp(Number(event.target.value), 0, 100 - selectedTable.h))} /></label>
                <label className="field"><span>Genislik</span><input type="number" value={selectedTable.w} onChange={event => updateTableField('w', clamp(Number(event.target.value), 14, 40))} /></label>
                <label className="field"><span>Yukseklik</span><input type="number" value={selectedTable.h} onChange={event => updateTableField('h', clamp(Number(event.target.value), 14, 40))} /></label>
              </div>
              {selectedPreset && (
                <div className="helper-box preset-box">
                  <strong>Aktif preset</strong>
                  <div className="preset-preview">
                    <TablePresetGraphic table={selectedTable} className="preset-preview-image" />
                  </div>
                  <small>{selectedPreset.id} / {selectedPreset.label}</small>
                </div>
              )}
              <div className="stack-row">
                <button className="layout-btn ghost small" onClick={duplicateSelectedTable}>
                  <i className="fa-solid fa-copy" /> Kopyala
                </button>
                <button className="layout-btn danger small" onClick={removeSelection}>
                  <i className="fa-solid fa-trash" /> Sil
                </button>
              </div>
            </div>
          )}
        </aside>
      </main>

      {isTableCreatorOpen && (
        <div className="creator-backdrop" onClick={() => setIsTableCreatorOpen(false)}>
          <div className="creator-modal" onClick={event => event.stopPropagation()}>
            <div className="creator-head">
              <div>
                <div className="layout-kicker">Preset Masa Ekle</div>
                <h2>Tip ve sandalye sayisini sec</h2>
              </div>
              <button className="icon-btn" onClick={() => setIsTableCreatorOpen(false)}>
                <i className="fa-solid fa-xmark" />
              </button>
            </div>

            <div className="creator-grid">
              <div className="creator-section">
                <span className="section-label">Masa tipi</span>
                <div className="shape-grid">
                  {Object.entries(SHAPE_META).map(([shapeKey, meta]) => (
                    <button key={shapeKey} type="button" className={`shape-card ${tableDraft.shape === shapeKey ? 'active' : ''}`} onClick={() => setTableDraft(prev => ({ ...prev, shape: shapeKey }))}>
                      <i className={`fa-solid ${meta.icon}`} />
                      {meta.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="creator-section">
                <span className="section-label">Sandalye sayisi</span>
                <div className="seat-grid">
                  {SEAT_OPTIONS.map(seat => (
                    <button key={seat} type="button" className={`seat-card ${tableDraft.seats === seat ? 'active' : ''}`} onClick={() => setTableDraft(prev => ({ ...prev, seats: seat }))}>
                      {seat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="creator-section preview-section">
                <span className="section-label">Canli onizleme</span>
                <div className="creator-preview">
                  <TablePresetGraphic table={{ shape: tableDraft.shape, seats: tableDraft.seats, status: 'empty', name: 'Yeni Masa' }} className="creator-preview-image" />
                </div>
                <small>Yeni masa yesil (bos) olarak acilir ve tasarim bu durumla yapilir.</small>
              </div>
            </div>

            <div className="creator-actions">
              <button className="layout-btn ghost" onClick={() => setIsTableCreatorOpen(false)}>Vazgec</button>
              <button className="layout-btn" onClick={confirmAddTable}>
                <i className="fa-solid fa-plus" /> Masayi Ekle
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .layout-shell{min-height:100vh;background:linear-gradient(180deg,#05082b 0%,#071035 48%,#08123c 100%);color:#eef4ff;padding:22px;display:flex;flex-direction:column;gap:16px}
        .layout-topbar,.layout-toolbar,.layout-panel,.canvas-panel,.creator-modal{background:linear-gradient(180deg,rgba(11,20,64,.95),rgba(7,14,49,.94));border:1px solid rgba(148,163,184,.14);box-shadow:0 20px 50px rgba(2,6,23,.28)}
        .layout-topbar{border-radius:24px;padding:20px;display:flex;justify-content:space-between;gap:18px;align-items:flex-start}
        .layout-topbar h1{margin:4px 0 0;font-size:2rem;letter-spacing:-.03em}
        .layout-kicker{font-size:.75rem;letter-spacing:.12em;text-transform:uppercase;color:rgba(191,219,254,.68)}
        .layout-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}
        .layout-btn,.layout-pill,.icon-btn{border:none;border-radius:16px;padding:0 16px;height:44px;font-weight:800;display:inline-flex;gap:10px;align-items:center;justify-content:center;cursor:pointer}
        .layout-btn{background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#071035}
        .layout-btn.ghost,.layout-pill{background:rgba(15,23,42,.42);color:#dbeafe;border:1px solid rgba(148,163,184,.16)}
        .layout-btn.danger{background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff}
        .layout-btn.small{height:40px;padding:0 14px}
        .icon-btn{width:40px;padding:0;background:rgba(15,23,42,.42);color:#eef4ff;border:1px solid rgba(148,163,184,.16)}
        .layout-pill.accent-green{border-color:rgba(34,197,94,.34);color:#dcfce7;background:rgba(34,197,94,.14)}
        .layout-toolbar{border-radius:20px;padding:12px;display:flex;gap:10px;flex-wrap:wrap}
        .layout-badge{height:44px;border-radius:16px;padding:0 16px;display:inline-flex;align-items:center;background:rgba(15,23,42,.42);border:1px solid rgba(148,163,184,.16);font-weight:700}
        .layout-main{display:grid;grid-template-columns:260px minmax(0,1fr) 360px;gap:16px;align-items:start}
        .layout-panel,.canvas-panel{border-radius:24px;padding:18px}
        .panel-title{font-size:1rem;font-weight:900;margin-bottom:12px}
        .panel-title.spaced{margin-top:20px}
        .inspector-grid-toggle{width:100%;margin-bottom:14px}
        .floor-list,.mini-list,.inspector-stack{display:flex;flex-direction:column;gap:10px}
        .floor-item,.mini-item{width:100%;border:none;border-radius:16px;background:rgba(8,15,49,.72);color:#eef4ff;padding:14px;text-align:left;display:flex;justify-content:space-between;align-items:center;cursor:pointer;border:1px solid rgba(148,163,184,.12)}
        .floor-item.active,.mini-item.active{border-color:rgba(56,189,248,.48);box-shadow:0 12px 24px rgba(2,6,23,.22)}
        .floor-item strong{display:block;margin-bottom:4px}.floor-item span{font-size:.84rem;color:rgba(191,219,254,.68)}
        .mini-dot{width:10px;height:10px;border-radius:999px;display:inline-block;margin-right:10px;flex-shrink:0}.mini-item{justify-content:flex-start;gap:10px}
        .mini-item small{margin-left:auto;color:rgba(191,219,254,.56)}
        .canvas-header{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:14px}
        .canvas-header span{display:block;margin-top:4px;color:rgba(191,219,254,.68);font-size:.9rem}
        .quick-chip{height:36px;border-radius:999px;padding:0 12px;background:rgba(15,23,42,.42);border:1px solid rgba(148,163,184,.12);display:inline-flex;align-items:center;gap:8px;font-size:.82rem;font-weight:700}
        .canvas-frame{border-radius:22px;padding:14px;background:rgba(4,8,28,.44);border:1px solid rgba(148,163,184,.12)}
        .canvas-surface{position:relative;width:100%;aspect-ratio:16/10;border-radius:18px;overflow:hidden;background-size:cover;background-position:center}
        .canvas-surface.show-grid{background-image:
          linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px),
          var(--surface-image);
          background-size:28px 28px,28px 28px,cover}
        .zone-box,.table-box{position:absolute;border:none;padding:0;cursor:grab}.zone-box{border:1px dashed rgba(255,255,255,.5);border-radius:18px;display:flex;align-items:flex-start;justify-content:flex-start;padding:12px;color:#e0f2fe;font-weight:800}
        .zone-box.active{outline:2px solid rgba(255,255,255,.35)}
        .table-box{display:flex;align-items:center;justify-content:center}
        .table-box.preset{background:transparent;box-shadow:0 10px 28px var(--status-glow);border:2px solid transparent}
        .table-box.preset.active{border-color:rgba(255,255,255,.28)}
        .table-asset-shell{position:absolute;inset:0;padding:5%}
        .table-asset-image,.creator-preview-image,.preset-preview-image{width:100%;height:100%;object-fit:contain;pointer-events:none;filter:drop-shadow(0 10px 16px rgba(7,16,53,.28))}
        .table-asset-label{position:absolute;left:50%;bottom:8px;transform:translateX(-50%);background:rgba(7,16,53,.78);color:#eef4ff;border-radius:999px;padding:4px 10px;font-size:.7rem;font-weight:800;pointer-events:none;white-space:nowrap;box-shadow:0 6px 14px rgba(2,6,23,.24)}
        .preset-loading{width:100%;height:100%;border-radius:999px;background:radial-gradient(circle, rgba(148,163,184,.36), rgba(15,23,42,.1));opacity:.55}
        .resize-handle{position:absolute;right:-8px;bottom:-8px;width:26px;height:26px;border-radius:999px;background:#071035;color:#f8fafc;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 18px rgba(2,6,23,.32)}
        .field{display:flex;flex-direction:column;gap:6px}.field span{font-size:.82rem;text-transform:uppercase;letter-spacing:.08em;color:rgba(191,219,254,.68)}
        .field input,.field select{height:42px;border-radius:14px;border:1px solid rgba(148,163,184,.16);background:rgba(8,15,49,.72);color:#eef4ff;padding:0 12px}.field input[type="color"]{padding:4px}.field input[type="range"]{padding:0}
        .field-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.stack-row{display:flex;gap:10px;flex-wrap:wrap}.actions-field small,.field small,.helper-box small{color:rgba(191,219,254,.6);line-height:1.5}
        .status-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
        .status-pill{height:42px;border-radius:14px;border:1px solid rgba(148,163,184,.16);background:rgba(8,15,49,.72);color:#eef4ff;padding:0 12px;font-weight:800;display:flex;align-items:center;justify-content:center;gap:8px;cursor:pointer}
        .status-pill.active{border-color:color-mix(in srgb, var(--pill-color) 70%, white);box-shadow:0 10px 22px color-mix(in srgb, var(--pill-color) 26%, transparent)}
        .status-dot{width:10px;height:10px;border-radius:999px;background:var(--pill-color)}
        .preset-box{margin-top:0}
        .preset-preview{width:100%;aspect-ratio:1;border-radius:20px;background:rgba(8,15,49,.72);display:flex;align-items:center;justify-content:center;padding:12px}
        .helper-box{margin-top:18px;padding:14px 16px;border-radius:18px;background:rgba(15,23,42,.42);border:1px solid rgba(148,163,184,.12)}.helper-box.compact p{margin:8px 0 0;color:rgba(219,234,254,.78);line-height:1.6}
        .helper-box strong{display:block;margin-bottom:8px}.helper-box ul{margin:0;padding-left:18px;color:rgba(219,234,254,.84);line-height:1.7}
        .creator-backdrop{position:fixed;inset:0;background:rgba(2,6,23,.72);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:24px;z-index:1200}
        .creator-modal{width:min(840px,100%);border-radius:28px;padding:22px}
        .creator-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}
        .creator-head h2{margin:6px 0 0;font-size:1.7rem;letter-spacing:-.03em}
        .creator-grid{display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:18px;margin-top:20px}
        .creator-section{display:flex;flex-direction:column;gap:12px}
        .section-label{font-size:.82rem;text-transform:uppercase;letter-spacing:.08em;color:rgba(191,219,254,.68)}
        .shape-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
        .shape-card,.seat-card{border:none;border-radius:18px;background:rgba(8,15,49,.72);border:1px solid rgba(148,163,184,.12);color:#eef4ff;cursor:pointer;font-weight:800}
        .shape-card{height:72px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px}
        .shape-card.active,.seat-card.active{border-color:rgba(251,191,36,.44);box-shadow:0 12px 24px rgba(2,6,23,.22)}
        .seat-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}
        .seat-card{height:56px;font-size:1rem}
        .preview-section{padding-left:8px}
        .creator-preview{aspect-ratio:1;border-radius:24px;background:radial-gradient(circle at center, rgba(34,197,94,.18), rgba(8,15,49,.82));padding:16px;display:flex;align-items:center;justify-content:center}
        .creator-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}
        @media (max-width: 1180px){.layout-main{grid-template-columns:1fr}.field-grid,.creator-grid{grid-template-columns:1fr}.preview-section{padding-left:0}}
        @media (max-width: 760px){.layout-shell{padding:16px}.layout-topbar{padding:16px}.layout-topbar h1{font-size:1.6rem}.layout-actions,.layout-toolbar{justify-content:flex-start}.canvas-header{flex-direction:column;align-items:flex-start}.shape-grid{grid-template-columns:1fr}.seat-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.status-row{grid-template-columns:1fr}}
      `}</style>
    </div>
  )
}
