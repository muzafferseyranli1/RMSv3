import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist/legacy/build/pdf.mjs'
import pdfWorker from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url'
import { useWorkspace } from '@/context/WorkspaceContext'
import {
  TABLE_LAYOUT_UPDATED_EVENT,
  hydrateTableLayoutFromDb,
  readLocalLayoutSnapshot,
} from '@/lib/posTablePersistence'

GlobalWorkerOptions.workerSrc = pdfWorker

const DEFAULT_FLOOR_COLOR = '#0b173a'

const STATUS_META = {
  empty: { label: 'Bos', code: 'y', color: '#22c55e' },
  occupied: { label: 'Dolu', code: 'k', color: '#ef4444' },
  reserved: { label: 'Rezerve', code: 'm', color: '#3b82f6' },
}

const SHAPE_META = {
  round: { label: 'Yuvarlak', code: 'y' },
  square: { label: 'Kare', code: 'k' },
}

const PRESET_ASSETS = Array.from({ length: 10 }, (_, index) => index + 1).flatMap(seats =>
  Object.entries(SHAPE_META).flatMap(([shape, shapeMeta]) =>
    Object.entries(STATUS_META).map(([status, statusMeta]) => ({
      id: `${shapeMeta.code}${seats}-${statusMeta.code}`,
      shape,
      seats,
      status,
      label: `${shapeMeta.label} ${seats} Kisilik ${statusMeta.label}`,
      src: `/assets/masa-icons/${shapeMeta.code}${seats}-${statusMeta.code}.pdf`,
    })),
  ),
)

const PRESET_BY_ID = new Map(PRESET_ASSETS.map(asset => [asset.id, asset]))
const PDF_CACHE = new Map()
const PDF_PROMISES = new Map()

function uid(prefix) {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}`
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value))
}

function clampSeatCount(value) {
  return clamp(Number(value) || 1, 1, 10)
}

function getTableSize(shape, seats) {
  const safeSeats = clampSeatCount(seats)
  const base = shape === 'square' ? 10 + safeSeats * 1.9 : 11 + safeSeats * 2.1
  const size = clamp(base, 14, 34)
  return { w: size.w || size, h: size.h || size }
}

function getPreset(shape, seats, status = 'empty') {
  const safeShape = SHAPE_META[shape] ? shape : 'round'
  const safeSeats = clampSeatCount(seats)
  const safeStatus = STATUS_META[status] ? status : 'empty'
  return PRESET_BY_ID.get(`${SHAPE_META[safeShape].code}${safeSeats}-${STATUS_META[safeStatus].code}`) || null
}

function createZone(index) {
  return {
    id: uid('zone'),
    name: `Bolge ${index}`,
    x: 8 + ((index - 1) % 3) * 8,
    y: 10 + ((index - 1) % 2) * 7,
    w: 30,
    h: 24,
    color: '#38bdf8',
    opacity: 0.14,
  }
}

function createTable(index, options = {}) {
  const shape = SHAPE_META[options.shape] ? options.shape : 'round'
  const seats = clampSeatCount(options.seats ?? 4)
  const status = STATUS_META[options.status] ? options.status : 'empty'
  const size = getTableSize(shape, seats)
  return {
    id: uid('table'),
    name: options.name || `Masa ${String(index).padStart(2, '0')}`,
    shape,
    seats,
    status,
    x: 18 + ((index - 1) % 4) * 16,
    y: 18 + ((index - 1) % 3) * 16,
    w: size.w,
    h: size.h,
    zoneId: options.zoneId || '',
  }
}

function createFloor(index) {
  const zone = createZone(1)
  const tableA = createTable(1, { shape: 'round', seats: 4, zoneId: zone.id })
  const tableB = createTable(2, { shape: 'square', seats: 4, zoneId: zone.id })
  const tableC = createTable(3, { shape: 'round', seats: 6 })
  return {
    id: uid('floor'),
    name: `Kat ${index}`,
    bgColor: DEFAULT_FLOOR_COLOR,
    bgImage: '',
    zones: [zone],
    tables: [tableA, tableB, tableC],
  }
}

function getDefaultEditor() {
  const firstFloor = createFloor(1)
  const secondFloor = createFloor(2)
  secondFloor.name = 'Teras'
  secondFloor.bgColor = '#12203f'
  secondFloor.zones[0].name = 'Dis Alan'
  secondFloor.tables[0].name = 'Teras 01'
  secondFloor.tables[1].name = 'Teras 02'
  secondFloor.tables[2].name = 'Teras 03'
  return { activeFloorId: firstFloor.id, floors: [firstFloor, secondFloor] }
}

function normalizeEditor(raw) {
  if (!raw || !Array.isArray(raw.floors) || raw.floors.length === 0) return getDefaultEditor()
  const floors = raw.floors.map((floor, floorIndex) => ({
    id: floor.id || uid('floor'),
    name: floor.name || `Kat ${floorIndex + 1}`,
    bgColor: floor.bgColor || DEFAULT_FLOOR_COLOR,
    bgImage: floor.bgImage || '',
    zones: Array.isArray(floor.zones)
      ? floor.zones.map((zone, zoneIndex) => ({
        id: zone.id || uid('zone'),
        name: zone.name || `Bolge ${zoneIndex + 1}`,
        x: Number.isFinite(zone.x) ? zone.x : 10,
        y: Number.isFinite(zone.y) ? zone.y : 10,
        w: Number.isFinite(zone.w) ? zone.w : 30,
        h: Number.isFinite(zone.h) ? zone.h : 24,
        color: zone.color || '#38bdf8',
        opacity: Number.isFinite(zone.opacity) ? zone.opacity : 0.14,
      }))
      : [],
    tables: Array.isArray(floor.tables)
      ? floor.tables.map((table, tableIndex) => {
        const shape = SHAPE_META[table.shape] ? table.shape : 'round'
        const seats = clampSeatCount(table.seats ?? 4)
        const size = getTableSize(shape, seats)
        return {
          id: table.id || uid('table'),
          name: table.name || `Masa ${tableIndex + 1}`,
          shape,
          seats,
          status: STATUS_META[table.status] ? table.status : 'empty',
          x: Number.isFinite(table.x) ? table.x : 20,
          y: Number.isFinite(table.y) ? table.y : 20,
          w: Number.isFinite(table.w) ? table.w : size.w,
          h: Number.isFinite(table.h) ? table.h : size.h,
          zoneId: table.zoneId || '',
        }
      })
      : [],
  }))
  const activeFloorId = floors.some(floor => floor.id === raw.activeFloorId) ? raw.activeFloorId : floors[0].id
  return { activeFloorId, floors }
}

async function renderPdfPreview(src) {
  if (!src) return ''
  if (PDF_CACHE.has(src)) return PDF_CACHE.get(src)
  if (PDF_PROMISES.has(src)) return PDF_PROMISES.get(src)

  const promise = (async () => {
    const pdf = await getDocument(src).promise
    const page = await pdf.getPage(1)
    const viewport = page.getViewport({ scale: 1.8 })
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('2d', { alpha: true })
    canvas.width = Math.ceil(viewport.width)
    canvas.height = Math.ceil(viewport.height)
    await page.render({
      canvasContext: context,
      viewport,
      background: 'rgba(0,0,0,0)',
    }).promise
    const dataUrl = canvas.toDataURL('image/png')
    PDF_CACHE.set(src, dataUrl)
    PDF_PROMISES.delete(src)
    return dataUrl
  })().catch(error => {
    PDF_PROMISES.delete(src)
    throw error
  })

  PDF_PROMISES.set(src, promise)
  return promise
}

function usePdfPreview(src) {
  const [preview, setPreview] = useState(() => (src && PDF_CACHE.has(src) ? PDF_CACHE.get(src) : ''))

  useEffect(() => {
    let cancelled = false
    if (!src) {
      setPreview('')
      return undefined
    }
    if (PDF_CACHE.has(src)) {
      setPreview(PDF_CACHE.get(src))
      return undefined
    }
    renderPdfPreview(src)
      .then(dataUrl => {
        if (!cancelled) setPreview(dataUrl)
      })
      .catch(() => {
        if (!cancelled) setPreview('')
      })
    return () => {
      cancelled = true
    }
  }, [src])

  return preview
}

function TablePresetGraphic({ table, className }) {
  const preset = getPreset(table.shape, table.seats, table.status)
  const preview = usePdfPreview(preset?.src || '')
  if (!preview) return <div className={`${className} preset-loading`} />
  return <img src={preview} alt={preset?.label || table.name} className={className} draggable="false" />
}

export default function POSMasalar() {
  const navigate = useNavigate()
  const { branchName } = useWorkspace()
  const [showGrid, setShowGrid] = useState(true)
  const initialEditor = useMemo(() => normalizeEditor(readLocalLayoutSnapshot()), [])
  const [savedEditor, setSavedEditor] = useState(() => initialEditor)
  const [activeFloorId, setActiveFloorId] = useState(() => initialEditor.activeFloorId)
  const [selectedTableId, setSelectedTableId] = useState('')

  useEffect(() => {
    let cancelled = false

    function applyEditor(nextEditor) {
      setSavedEditor(nextEditor)
      setActiveFloorId(current => nextEditor.floors.some(floor => floor.id === current) ? current : nextEditor.activeFloorId)
    }

    hydrateTableLayoutFromDb()
      .then(layoutValue => {
        if (cancelled || !layoutValue) return
        applyEditor(normalizeEditor(layoutValue))
      })
      .catch(error => {
        if (!cancelled) console.error('POSMasalar layout hydrate failed', error)
      })

    const handleLayoutUpdated = () => {
      hydrateTableLayoutFromDb()
        .then(layoutValue => {
          if (!layoutValue) return
          applyEditor(normalizeEditor(layoutValue))
        })
        .catch(error => console.error('POSMasalar layout refresh failed', error))
    }

    window.addEventListener(TABLE_LAYOUT_UPDATED_EVENT, handleLayoutUpdated)
    return () => {
      cancelled = true
      window.removeEventListener(TABLE_LAYOUT_UPDATED_EVENT, handleLayoutUpdated)
    }
  }, [])

  const activeFloor = useMemo(
    () => savedEditor.floors.find(floor => floor.id === activeFloorId) || savedEditor.floors[0],
    [activeFloorId, savedEditor],
  )
  const selectedTable = useMemo(
    () => activeFloor?.tables.find(table => table.id === selectedTableId) || activeFloor?.tables[0] || null,
    [activeFloor, selectedTableId],
  )
  const floorCounts = useMemo(() => ({
    tables: activeFloor?.tables.length || 0,
    zones: activeFloor?.zones.length || 0,
  }), [activeFloor])

  useEffect(() => {
    if (!activeFloor) return
    setSelectedTableId(current => activeFloor.tables.some(table => table.id === current) ? current : (activeFloor.tables[0]?.id || ''))
  }, [activeFloor])

  return (
    <div className="layout-shell">
      <header className="layout-topbar">
        <div>
          <div className="layout-kicker">POS / Kayitli Masa Plani</div>
          <h1>Masalar Ekrani</h1>
          <p>Kaydedilen yerlesim tasarimi bu ekranda okunur. Bir sonraki turda operasyon akisini bu iskeletin ustune kuracagiz.</p>
        </div>
        <div className="layout-actions">
          <span className="layout-badge">{branchName || 'Aktif sube'}</span>
          <button className="layout-btn ghost" onClick={() => setShowGrid(value => !value)}>
            <i className="fa-solid fa-border-all" /> {showGrid ? 'Grid Kapali' : 'Grid Acik'}
          </button>
          <button className="layout-btn" onClick={() => navigate('/pos-masa')}>
            <i className="fa-solid fa-pen-ruler" /> Duzeni Duzenle
          </button>
        </div>
      </header>

      <main className="layout-main readonly-main">
        <aside className="layout-panel left">
          <div className="panel-title">Katlar</div>
          <div className="floor-list">
            {savedEditor.floors.map(floor => (
              <button
                key={floor.id}
                className={`floor-item ${floor.id === activeFloor?.id ? 'active' : ''}`}
                onClick={() => setActiveFloorId(floor.id)}
              >
                <div>
                  <strong>{floor.name}</strong>
                  <span>{floor.tables.length} masa, {floor.zones.length} bolge</span>
                </div>
                <i className="fa-solid fa-chevron-right" />
              </button>
            ))}
          </div>

          <div className="helper-box compact">
            <strong>Durum kodlari</strong>
            <div className="legend-stack">
              {Object.entries(STATUS_META).map(([statusKey, meta]) => (
                <div key={statusKey} className="legend-row">
                  <span className="legend-dot" style={{ background: meta.color }} />
                  <span>{meta.label}</span>
                </div>
              ))}
            </div>
          </div>
        </aside>

        <section className="canvas-panel">
          <div className="canvas-header">
            <div>
              <strong>{activeFloor?.name || 'Kat'}</strong>
              <span>Kaydedilen plan birebir okunuyor. Masa kartlarini secerek detay gorebilirsin.</span>
            </div>
          </div>

          <div className="canvas-frame">
            <div
              className={`canvas-surface readonly-surface ${showGrid ? 'show-grid' : ''}`}
              style={{
                backgroundColor: activeFloor?.bgColor || DEFAULT_FLOOR_COLOR,
                '--surface-image': activeFloor?.bgImage ? `url(${activeFloor.bgImage})` : 'none',
                backgroundImage: activeFloor?.bgImage
                  ? `linear-gradient(rgba(4,8,28,.28), rgba(4,8,28,.28)), url(${activeFloor.bgImage})`
                  : undefined,
              }}
            >
              {activeFloor?.zones.map(zone => (
                <div
                  key={zone.id}
                  className="zone-box readonly"
                  style={{
                    left: `${zone.x}%`,
                    top: `${zone.y}%`,
                    width: `${zone.w}%`,
                    height: `${zone.h}%`,
                    background: `rgba(8, 15, 49, ${zone.opacity || 0.14})`,
                    borderColor: zone.color,
                  }}
                >
                  <span>{zone.name}</span>
                </div>
              ))}

              {activeFloor?.tables.map(table => {
                const statusMeta = STATUS_META[table.status] || STATUS_META.empty
                return (
                  <button
                    key={table.id}
                    type="button"
                    className={`table-box preset readonly ${selectedTable?.id === table.id ? 'active' : ''}`}
                    style={{
                      left: `${table.x}%`,
                      top: `${table.y}%`,
                      width: `${table.w}%`,
                      height: `${table.h}%`,
                      '--status-glow': `rgba(${statusMeta.color === '#22c55e' ? '34,197,94' : statusMeta.color === '#ef4444' ? '239,68,68' : '59,130,246'}, .42)`,
                    }}
                    onClick={() => setSelectedTableId(table.id)}
                  >
                    <div className="table-asset-shell">
                      <TablePresetGraphic table={table} className="table-asset-image" />
                    </div>
                    <span className="table-asset-label">{table.name}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </section>

        <aside className="layout-panel right">
          <div className="panel-title">Secili Masa</div>
          {selectedTable ? (
            <div className="inspector-stack">
              <div className="helper-box preset-box">
                <strong>{selectedTable.name}</strong>
                <div className="preset-preview">
                  <TablePresetGraphic table={selectedTable} className="preset-preview-image" />
                </div>
                <small>{SHAPE_META[selectedTable.shape]?.label} / {selectedTable.seats} kisilik</small>
              </div>

              <div className="helper-box compact">
                <strong>Masa ozeti</strong>
                <ul>
                  <li>Durum: {STATUS_META[selectedTable.status]?.label}</li>
                  <li>Boyut: {Math.round(selectedTable.w)} x {Math.round(selectedTable.h)}</li>
                  <li>Konum: X {Math.round(selectedTable.x)} / Y {Math.round(selectedTable.y)}</li>
                  <li>Bolge: {activeFloor?.zones.find(zone => zone.id === selectedTable.zoneId)?.name || 'Bolgesiz'}</li>
                </ul>
              </div>

              <div className="helper-box compact">
                <strong>Kat ozeti</strong>
                <ul>
                  <li>{floorCounts.tables} masa</li>
                  <li>{floorCounts.zones} bolge</li>
                  <li>Zemin: {activeFloor?.bgImage ? 'Gorselli' : 'Renkli'}</li>
                </ul>
              </div>
            </div>
          ) : (
            <div className="helper-box compact">
              <strong>Kayitli masa bulunamadi</strong>
              <p>Editor tarafinda plan kaydedildiginde masalar burada gosterilir.</p>
            </div>
          )}
        </aside>
      </main>

      <style>{`
        .layout-shell{min-height:100vh;background:linear-gradient(180deg,#05082b 0%,#071035 48%,#08123c 100%);color:#eef4ff;padding:22px;display:flex;flex-direction:column;gap:16px}
        .layout-topbar,.layout-panel,.canvas-panel{background:linear-gradient(180deg,rgba(11,20,64,.95),rgba(7,14,49,.94));border:1px solid rgba(148,163,184,.14);box-shadow:0 20px 50px rgba(2,6,23,.28)}
        .layout-topbar{border-radius:24px;padding:20px;display:flex;justify-content:space-between;gap:18px;align-items:flex-start}
        .layout-topbar h1{margin:4px 0 0;font-size:2rem;letter-spacing:-.03em}
        .layout-topbar p{margin:8px 0 0;color:rgba(191,219,254,.74);max-width:760px;line-height:1.55}
        .layout-kicker{font-size:.75rem;letter-spacing:.12em;text-transform:uppercase;color:rgba(191,219,254,.68)}
        .layout-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}
        .layout-btn{border:none;border-radius:16px;padding:0 16px;height:44px;font-weight:800;display:inline-flex;gap:10px;align-items:center;justify-content:center;cursor:pointer;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#071035}
        .layout-btn.ghost{background:rgba(15,23,42,.42);color:#dbeafe;border:1px solid rgba(148,163,184,.16)}
        .layout-badge{height:44px;border-radius:16px;padding:0 16px;display:inline-flex;align-items:center;background:rgba(15,23,42,.42);border:1px solid rgba(148,163,184,.16);font-weight:700}
        .layout-main{display:grid;grid-template-columns:260px minmax(0,1fr) 330px;gap:16px;align-items:start}
        .layout-panel,.canvas-panel{border-radius:24px;padding:18px}
        .panel-title{font-size:1rem;font-weight:900;margin-bottom:12px}
        .floor-list,.inspector-stack{display:flex;flex-direction:column;gap:10px}
        .floor-item{width:100%;border:none;border-radius:16px;background:rgba(8,15,49,.72);color:#eef4ff;padding:14px;text-align:left;display:flex;justify-content:space-between;align-items:center;cursor:pointer;border:1px solid rgba(148,163,184,.12)}
        .floor-item.active{border-color:rgba(56,189,248,.48);box-shadow:0 12px 24px rgba(2,6,23,.22)}
        .floor-item strong{display:block;margin-bottom:4px}
        .floor-item span{font-size:.84rem;color:rgba(191,219,254,.68)}
        .canvas-header{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:14px}
        .canvas-header strong{font-size:1.1rem}
        .canvas-header span{display:block;margin-top:4px;color:rgba(191,219,254,.68);font-size:.9rem}
        .canvas-frame{border-radius:22px;padding:14px;background:rgba(4,8,28,.44);border:1px solid rgba(148,163,184,.12)}
        .canvas-surface{position:relative;width:100%;aspect-ratio:16/10;border-radius:18px;overflow:hidden;background-size:cover;background-position:center}
        .canvas-surface.show-grid{background-image:
          linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px),
          var(--surface-image);
          background-size:28px 28px,28px 28px,cover}
        .zone-box,.table-box{position:absolute;border:none;padding:0}
        .zone-box{border:1px dashed rgba(255,255,255,.5);border-radius:18px;display:flex;align-items:flex-start;justify-content:flex-start;padding:12px;color:#e0f2fe;font-weight:800;pointer-events:none}
        .zone-box.readonly{backdrop-filter:blur(1px)}
        .table-box{display:flex;align-items:center;justify-content:center}
        .table-box.readonly{cursor:pointer}
        .table-box.preset{background:transparent;box-shadow:0 10px 28px var(--status-glow);border:2px solid transparent}
        .table-box.preset.active{border-color:rgba(255,255,255,.28)}
        .table-asset-shell{position:absolute;inset:0;padding:5%}
        .table-asset-image,.preset-preview-image{width:100%;height:100%;object-fit:contain;pointer-events:none;filter:drop-shadow(0 10px 16px rgba(7,16,53,.28))}
        .table-asset-label{position:absolute;left:50%;bottom:8px;transform:translateX(-50%);background:rgba(7,16,53,.78);color:#eef4ff;border-radius:999px;padding:4px 10px;font-size:.7rem;font-weight:800;pointer-events:none;white-space:nowrap;box-shadow:0 6px 14px rgba(2,6,23,.24)}
        .preset-loading{width:100%;height:100%;border-radius:999px;background:radial-gradient(circle, rgba(148,163,184,.36), rgba(15,23,42,.1));opacity:.55}
        .helper-box{padding:14px 16px;border-radius:18px;background:rgba(15,23,42,.42);border:1px solid rgba(148,163,184,.12)}
        .helper-box.compact p{margin:8px 0 0;color:rgba(219,234,254,.78);line-height:1.6}
        .helper-box strong{display:block;margin-bottom:8px}
        .helper-box ul{margin:0;padding-left:18px;color:rgba(219,234,254,.84);line-height:1.7}
        .legend-stack{display:flex;flex-direction:column;gap:8px}
        .legend-row{display:flex;align-items:center;gap:10px;color:rgba(219,234,254,.86);font-size:.92rem}
        .legend-dot{width:12px;height:12px;border-radius:999px;display:inline-block}
        .preset-preview{width:100%;aspect-ratio:1;border-radius:20px;background:rgba(8,15,49,.72);display:flex;align-items:center;justify-content:center;padding:12px}
        @media (max-width: 1180px){.layout-main{grid-template-columns:1fr}}
        @media (max-width: 760px){.layout-shell{padding:16px}.layout-topbar{padding:16px}.layout-topbar h1{font-size:1.6rem}.layout-actions{justify-content:flex-start}}
      `}</style>
    </div>
  )
}
