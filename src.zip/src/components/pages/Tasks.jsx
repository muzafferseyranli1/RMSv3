import { useEffect, useMemo, useState } from 'react'
import Header from '@/components/layout/Header'
import SearchableSelect from '@/components/ui/SearchableSelect'
import { useToast } from '@/hooks/useToast'
import {
  PERSONNEL_SETTINGS_KEYS,
  extractBranchNodes,
  normalizeEmployeeRecord,
  readCompanyTree,
  readSettingArray,
} from '@/lib/personnelConfig'

const RECURRENCE_OPTIONS = [
  { value: '', label: 'Tek seferlik' },
  { value: 'daily', label: 'Gunluk' },
  { value: 'weekly', label: 'Haftalik' },
  { value: 'monthly', label: 'Aylik' },
  { value: 'yearly', label: 'Yillik' },
]

const WEEKDAY_OPTIONS = [
  { value: 'monday', label: 'Pazartesi' },
  { value: 'tuesday', label: 'Sali' },
  { value: 'wednesday', label: 'Carsamba' },
  { value: 'thursday', label: 'Persembe' },
  { value: 'friday', label: 'Cuma' },
  { value: 'saturday', label: 'Cumartesi' },
  { value: 'sunday', label: 'Pazar' },
]

const MONTHLY_PATTERN_OPTIONS = [
  { value: 'day_of_month', label: 'Ayin kacinci gunu' },
  { value: 'first_day', label: 'Ayin ilk gunu' },
  { value: 'last_day', label: 'Ayin son gunu' },
  { value: 'nth_weekday', label: 'Orn. 3. Pazartesi' },
]

const YEARLY_PATTERN_OPTIONS = [
  { value: 'specific_dates', label: 'Belirli tarihler' },
  { value: 'every_n_months', label: 'X ayda bir' },
  { value: 'same_day_every_n_months', label: 'Her X ayda ayni gun' },
  { value: 'first_day_every_n_months', label: 'Her X ayda ayin ilk gunu' },
  { value: 'last_day_every_n_months', label: 'Her X ayda ayin son gunu' },
]

function createInitialForm() {
  return {
    title: '',
    description: '',
    responsibleId: '',
    collaboratorIds: [],
    observerIds: [],
    redirectToId: '',
    completionDate: '',
    isFutureTask: false,
    startDate: '',
    endDate: '',
    locationId: '',
    recurrence: '',
    completionTime: '',
    weeklyDays: [],
    durationValue: '',
    durationUnit: 'saat',
    monthlyPattern: 'day_of_month',
    monthlyDayOfMonth: '',
    monthlyNth: '3',
    monthlyWeekday: 'monday',
    yearlyPattern: 'specific_dates',
    yearlyDates: '',
    yearlyEveryMonths: '3',
    checklistText: 'Butceyi kontrol et\nResim cek',
    closingReportRequired: false,
    closingPhotoRequired: false,
    formTemplate: 'Denetim formu',
  }
}

function toOption(person) {
  const firstName = String(person?.firstName || '').trim()
  const middleName = String(person?.middleName || '').trim()
  const lastName = String(person?.lastName || '').trim()
  const fullName = [firstName, middleName, lastName].filter(Boolean).join(' ').trim()
  const fallback = String(person?.username || person?.registryNumber || person?.id || '')
  const label = fullName || fallback || 'Isimsiz personel'
  return {
    value: String(person.id),
    label,
    searchText: [
      label,
      person?.username,
      person?.registryNumber,
      person?.defaultBranchName,
    ].filter(Boolean).join(' '),
    description: person?.defaultBranchName || '',
  }
}

function createPeopleOptions(records) {
  return records
    .filter(record => !record.deletedAt && !String(record.terminationDate || '').trim())
    .map(toOption)
    .sort((a, b) => a.label.localeCompare(b.label, 'tr'))
}

function createBranchOptions(records) {
  return records
    .map(branch => ({
      value: String(branch.id),
      label: branch.name,
      description: branch.legalEntityName || '',
      searchText: [branch.name, branch.legalEntityName].filter(Boolean).join(' '),
    }))
    .sort((a, b) => a.label.localeCompare(b.label, 'tr'))
}

function findLabel(options, value) {
  return options.find(option => String(option.value) === String(value))?.label || '-'
}

function parseChecklistItems(value) {
  return String(value || '')
    .split(/\r?\n/)
    .map(item => item.trim())
    .filter(Boolean)
}

function Section({ title, hint, icon, children }) {
  return (
    <section className="card" style={{ padding: 20 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 16 }}>
        <span style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(59,130,246,.12)', color: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <i className={`fa-solid ${icon}`} />
        </span>
        <div>
          <div style={{ fontSize: '.98rem', fontWeight: 800, color: '#0f172a' }}>{title}</div>
          {hint && <div style={{ fontSize: '.78rem', color: '#64748b', marginTop: 4, lineHeight: 1.5 }}>{hint}</div>}
        </div>
      </div>
      {children}
    </section>
  )
}

function MultiPersonPicker({ label, values, options, onChange, placeholder, hint }) {
  const selectedValues = Array.isArray(values) ? values : []

  function addValue(nextValue) {
    if (!nextValue) return
    if (selectedValues.includes(nextValue)) return
    onChange([...selectedValues, nextValue])
  }

  function removeValue(target) {
    onChange(selectedValues.filter(value => value !== target))
  }

  return (
    <div>
      <label className="f-label">{label}</label>
      <SearchableSelect
        value=""
        onChange={addValue}
        options={options.filter(option => !selectedValues.includes(option.value))}
        placeholder={placeholder}
        searchPlaceholder="Personel ara..."
        clearLabel="Secimi temizle"
      />
      {hint && <div className="f-hint">{hint}</div>}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
        {selectedValues.length === 0 ? (
          <span style={{ fontSize: '.78rem', color: '#94a3b8' }}>Henuz secim yapilmadi.</span>
        ) : selectedValues.map(value => (
          <span key={value} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 10px', borderRadius: 999, background: '#eff6ff', color: '#1d4ed8', fontSize: '.76rem', fontWeight: 700 }}>
            {findLabel(options, value)}
            <button
              type="button"
              onClick={() => removeValue(value)}
              style={{ border: 'none', background: 'none', color: 'inherit', cursor: 'pointer', padding: 0 }}
              aria-label={`${findLabel(options, value)} secimini kaldir`}
            >
              <i className="fa-solid fa-xmark" />
            </button>
          </span>
        ))}
      </div>
    </div>
  )
}

function Field({ label, hint, children }) {
  return (
    <div>
      <label className="f-label">{label}</label>
      {children}
      {hint && <div className="f-hint">{hint}</div>}
    </div>
  )
}

export default function Tasks() {
  const toast = useToast()
  const [loading, setLoading] = useState(true)
  const [personnelOptions, setPersonnelOptions] = useState([])
  const [branchOptions, setBranchOptions] = useState([])
  const [form, setForm] = useState(createInitialForm())

  useEffect(() => {
    let mounted = true

    async function loadOptions() {
      setLoading(true)
      try {
        const [employees, companyTree] = await Promise.all([
          readSettingArray(PERSONNEL_SETTINGS_KEYS.employees, normalizeEmployeeRecord),
          readCompanyTree(),
        ])

        if (!mounted) return
        setPersonnelOptions(createPeopleOptions(employees))
        setBranchOptions(createBranchOptions(extractBranchNodes(companyTree)))
      } catch (error) {
        if (!mounted) return
        toast(`Gorevler ekrani yuklenemedi: ${error.message}`, 'error')
      } finally {
        if (mounted) setLoading(false)
      }
    }

    loadOptions()
    return () => {
      mounted = false
    }
  }, [toast])

  function setField(key, value) {
    setForm(current => ({ ...current, [key]: value }))
  }

  const checklistItems = useMemo(() => parseChecklistItems(form.checklistText), [form.checklistText])
  const summaryCards = useMemo(() => ([
    { label: 'Sorumlu', value: findLabel(personnelOptions, form.responsibleId) },
    { label: 'Lokasyon', value: findLabel(branchOptions, form.locationId) },
    { label: 'Tekrar', value: RECURRENCE_OPTIONS.find(option => option.value === form.recurrence)?.label || 'Tek seferlik' },
    { label: 'Checklist', value: checklistItems.length ? `${checklistItems.length} adim` : 'Yok' },
  ]), [branchOptions, checklistItems.length, form.locationId, form.recurrence, form.responsibleId, personnelOptions])

  return (
    <>
      <Header
        title="Gorevler"
        subtitle="Exceldeki gorev tanimi yapisina gore hazirlanan gorev formu. Personel ve lokasyon alanlari mevcut veri yolundan beslenir."
        actions={(
          <>
            <button type="button" className="btn-o" onClick={() => setForm(createInitialForm())}>
              <i className="fa-solid fa-rotate-left" /> Formu Temizle
            </button>
            <button type="button" className="btn-p">
              <i className="fa-solid fa-floppy-disk" /> Kaydetmeye Hazir
            </button>
          </>
        )}
      />

      <div style={{ display: 'grid', gap: 18 }}>
        <div className="card" style={{ padding: 18, background: 'linear-gradient(135deg,#eff6ff,#f8fafc)', borderColor: '#bfdbfe' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
            {summaryCards.map(card => (
              <div key={card.label} style={{ background: '#fff', border: '1px solid #dbeafe', borderRadius: 14, padding: '12px 14px' }}>
                <div style={{ fontSize: '.72rem', fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.08em' }}>{card.label}</div>
                <div style={{ marginTop: 6, fontSize: '.92rem', fontWeight: 700, color: '#0f172a' }}>{card.value || '-'}</div>
              </div>
            ))}
          </div>
        </div>

        <Section title="Gorev Kimligi" hint="Exceldeki Gorev adi ve Gorev Aciklamasi satirlarini temel alir." icon="fa-clipboard-list">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 16 }}>
            <Field label="Gorev adi">
              <input className="f-input" value={form.title} onChange={event => setField('title', event.target.value)} placeholder="Orn. Aylik denetim turu" />
            </Field>
            <Field label="Tamamlanma tarihi">
              <input type="date" className="f-input" value={form.completionDate} onChange={event => setField('completionDate', event.target.value)} />
            </Field>
          </div>
          <div style={{ marginTop: 16 }}>
            <Field label="Gorev aciklamasi">
              <textarea className="f-input" rows={4} value={form.description} onChange={event => setField('description', event.target.value)} placeholder="Gorevin kapsamı, beklenen cikti ve notlari..." />
            </Field>
          </div>
        </Section>

        <Section title="Atama ve Akis" hint="Kim sorumlu, birlikte yapacaklar, gozlemciler ve gorevin yonlendirilecegi kisi alanlari." icon="fa-users">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 16 }}>
            <div>
              <label className="f-label">Kim sorumlu</label>
              <SearchableSelect
                value={form.responsibleId}
                onChange={value => setField('responsibleId', value)}
                options={personnelOptions}
                placeholder={loading ? 'Yukleniyor...' : 'Personel secin...'}
                searchPlaceholder="Personel ara..."
              />
              <div className="f-hint">Personel listesindeki aktif kayitlardan secilir.</div>
            </div>
            <div>
              <label className="f-label">Gorevi yonlendir</label>
              <SearchableSelect
                value={form.redirectToId}
                onChange={value => setField('redirectToId', value)}
                options={personnelOptions}
                placeholder={loading ? 'Yukleniyor...' : 'Yonetilecek personel secin...'}
                searchPlaceholder="Personel ara..."
              />
              <div className="f-hint">Excel notuna gore secilen kisi gorevi kabul eder veya geri gonderebilir.</div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 16, marginTop: 16 }}>
            <MultiPersonPicker
              label="Birlikte yap"
              values={form.collaboratorIds}
              options={personnelOptions}
              onChange={value => setField('collaboratorIds', value)}
              placeholder="Ekip arkadasi ekle..."
            />
            <MultiPersonPicker
              label="Gozlemci ekle"
              values={form.observerIds}
              options={personnelOptions}
              onChange={value => setField('observerIds', value)}
              placeholder="Gozlemci ekle..."
            />
          </div>
        </Section>

        <Section title="Takvim ve Lokasyon" hint="Ileri tarihli gorev, baslangic-bitis araligi ve sube secimi." icon="fa-calendar-days">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
            <Field label="Baslangic tarihi">
              <input type="date" className="f-input" value={form.startDate} onChange={event => setField('startDate', event.target.value)} />
            </Field>
            <Field label="Bitis tarihi">
              <input type="date" className="f-input" value={form.endDate} onChange={event => setField('endDate', event.target.value)} />
            </Field>
            <div>
              <label className="f-label">Lokasyon</label>
              <SearchableSelect
                value={form.locationId}
                onChange={value => setField('locationId', value)}
                options={branchOptions}
                placeholder={loading ? 'Yukleniyor...' : 'Sube secin...'}
                searchPlaceholder="Sube ara..."
              />
              <div className="f-hint">Excel notuna uygun olarak sube listesinden secilir.</div>
            </div>
          </div>
          <div style={{ marginTop: 16, display: 'flex', flexWrap: 'wrap', gap: 10 }}>
            <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 12, border: '1px solid #e2e8f0', background: '#fff' }}>
              <input type="checkbox" checked={form.isFutureTask} onChange={event => setField('isFutureTask', event.target.checked)} />
              <span style={{ fontSize: '.84rem', color: '#0f172a', fontWeight: 600 }}>Ileri tarihli gorev</span>
            </label>
          </div>
        </Section>

        <Section title="Tekrarlayan Gorev" hint="Gunluk, haftalik, aylik ve yillik varyasyonlar Excel notlarindaki kurallara gore ayrildi." icon="fa-rotate">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
            <div>
              <label className="f-label">Tekrarlama tipi</label>
              <SearchableSelect
                value={form.recurrence}
                onChange={value => setField('recurrence', value)}
                options={RECURRENCE_OPTIONS}
                placeholder="Secin..."
                searchPlaceholder="Tip ara..."
                allowClear={false}
              />
            </div>
            {(form.recurrence === 'daily' || form.recurrence === 'weekly') && (
              <Field label="Gorevin tamamlanma saati">
                <input type="time" className="f-input" value={form.completionTime} onChange={event => setField('completionTime', event.target.value)} />
              </Field>
            )}
            {form.recurrence && form.recurrence !== 'daily' && (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 120px', gap: 10 }}>
                <Field label="Gorev suresi">
                  <input className="f-input" value={form.durationValue} onChange={event => setField('durationValue', event.target.value)} placeholder="Orn. 4" />
                </Field>
                <Field label="Birim">
                  <select className="f-input" value={form.durationUnit} onChange={event => setField('durationUnit', event.target.value)}>
                    <option value="saat">Saat</option>
                    <option value="gun">Gun</option>
                  </select>
                </Field>
              </div>
            )}
          </div>

          {form.recurrence === 'weekly' && (
            <div style={{ marginTop: 16 }}>
              <label className="f-label">Hangi gunler</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                {WEEKDAY_OPTIONS.map(option => {
                  const active = form.weeklyDays.includes(option.value)
                  return (
                    <button
                      key={option.value}
                      type="button"
                      className={active ? 'btn-p' : 'btn-o'}
                      onClick={() => {
                        const next = active
                          ? form.weeklyDays.filter(value => value !== option.value)
                          : [...form.weeklyDays, option.value]
                        setField('weeklyDays', next)
                      }}
                    >
                      {option.label}
                    </button>
                  )
                })}
              </div>
            </div>
          )}

          {form.recurrence === 'monthly' && (
            <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
              <div>
                <label className="f-label">Aylik desen</label>
                <select className="f-input" value={form.monthlyPattern} onChange={event => setField('monthlyPattern', event.target.value)}>
                  {MONTHLY_PATTERN_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                </select>
              </div>
              {form.monthlyPattern === 'day_of_month' && (
                <Field label="Ayin kacinci gunu">
                  <input className="f-input" value={form.monthlyDayOfMonth} onChange={event => setField('monthlyDayOfMonth', event.target.value)} placeholder="Orn. 15" />
                </Field>
              )}
              {form.monthlyPattern === 'nth_weekday' && (
                <>
                  <Field label="Kacinci">
                    <select className="f-input" value={form.monthlyNth} onChange={event => setField('monthlyNth', event.target.value)}>
                      <option value="1">1.</option>
                      <option value="2">2.</option>
                      <option value="3">3.</option>
                      <option value="4">4.</option>
                      <option value="5">5.</option>
                    </select>
                  </Field>
                  <Field label="Gun">
                    <select className="f-input" value={form.monthlyWeekday} onChange={event => setField('monthlyWeekday', event.target.value)}>
                      {WEEKDAY_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                    </select>
                  </Field>
                </>
              )}
            </div>
          )}

          {form.recurrence === 'yearly' && (
            <div style={{ marginTop: 16, display: 'grid', gap: 16 }}>
              <div>
                <label className="f-label">Yillik desen</label>
                <select className="f-input" value={form.yearlyPattern} onChange={event => setField('yearlyPattern', event.target.value)}>
                  {YEARLY_PATTERN_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                </select>
              </div>
              {form.yearlyPattern === 'specific_dates' && (
                <Field label="Hangi tarihler" hint="Virgul veya yeni satir ile ayirabilirsiniz.">
                  <textarea className="f-input" rows={3} value={form.yearlyDates} onChange={event => setField('yearlyDates', event.target.value)} placeholder="Orn. 15.01, 15.04, 15.07, 15.10" />
                </Field>
              )}
              {form.yearlyPattern !== 'specific_dates' && (
                <Field label="X ayda bir">
                  <input className="f-input" value={form.yearlyEveryMonths} onChange={event => setField('yearlyEveryMonths', event.target.value)} placeholder="Orn. 3" />
                </Field>
              )}
            </div>
          )}
        </Section>

        <Section title="Yapilacaklar Listesi ve Kapanis Kurallari" hint="Checklist, bitis raporu, foto zorunlulugu ve bagli form bilgisi." icon="fa-list-check">
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(260px, 1.25fr) minmax(240px, .75fr)', gap: 18 }}>
            <div>
              <Field label="Yapilacaklar listesi ekle" hint="Her satira bir madde yazin.">
                <textarea className="f-input" rows={6} value={form.checklistText} onChange={event => setField('checklistText', event.target.value)} />
              </Field>
            </div>
            <div className="card" style={{ padding: 16, background: '#f8fafc' }}>
              <div style={{ fontSize: '.78rem', fontWeight: 800, color: '#475569', textTransform: 'uppercase', letterSpacing: '.08em' }}>Onizleme</div>
              <div style={{ display: 'grid', gap: 8, marginTop: 12 }}>
                {checklistItems.length === 0 ? (
                  <div style={{ fontSize: '.82rem', color: '#94a3b8' }}>Checklist eklenmedi.</div>
                ) : checklistItems.map((item, index) => (
                  <div key={`${item}-${index}`} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', fontSize: '.84rem', color: '#0f172a' }}>
                    <span style={{ width: 20, height: 20, borderRadius: 999, background: '#dbeafe', color: '#1d4ed8', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '.72rem', fontWeight: 800, flexShrink: 0 }}>{index + 1}</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14, marginTop: 16 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', border: '1px solid #e2e8f0', borderRadius: 12, background: '#fff' }}>
              <input type="checkbox" checked={form.closingReportRequired} onChange={event => setField('closingReportRequired', event.target.checked)} />
              <span style={{ fontSize: '.84rem', color: '#0f172a', fontWeight: 600 }}>Gorev bitis raporu gerekli</span>
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', border: '1px solid #e2e8f0', borderRadius: 12, background: '#fff' }}>
              <input type="checkbox" checked={form.closingPhotoRequired} onChange={event => setField('closingPhotoRequired', event.target.checked)} />
              <span style={{ fontSize: '.84rem', color: '#0f172a', fontWeight: 600 }}>Gorev bitisi icin fotograf gerekli</span>
            </label>
          </div>
          <div style={{ marginTop: 16 }}>
            <Field label="Gorev icin kullanilacak form" hint="Excel notuna gore ileride olusturulacak formlara baglanacak alan.">
              <input className="f-input" value={form.formTemplate} onChange={event => setField('formTemplate', event.target.value)} placeholder="Orn. Denetim formu" />
            </Field>
          </div>
        </Section>
      </div>
    </>
  )
}
