import { useEffect, useMemo, useState } from 'react'

function findNode(nodes, id) {
  for (const node of nodes) {
    if (node.id === id) return node
    const match = findNode(node.children || [], id)
    if (match) return match
  }
  return null
}

function findParentName(nodes, id, parentName = '') {
  for (const node of nodes) {
    if (node.id === id) return parentName
    const match = findParentName(node.children || [], id, node.name)
    if (match) return match
  }
  return ''
}

function hasMask(mask, appendType, appendLen) {
  return Boolean(mask || (appendType && appendLen))
}

function buildSkuState(node, systemMask, genSku, appendLabel) {
  const categoryMask = hasMask(node.sku_mask, node.append_type, node.append_len)
  const systemHasMask = hasMask(systemMask?.mask, systemMask?.appendType, systemMask?.appendLen)

  if (categoryMask) {
    return {
      preview: genSku(node.sku_mask, node.append_type, node.append_len),
      rule: appendLabel(node.append_type, node.append_len),
      source: 'category',
    }
  }

  if (systemHasMask) {
    return {
      preview: genSku(systemMask.mask || '', systemMask.appendType || '', systemMask.appendLen || 4),
      rule: `Sistem varsayilani • ${appendLabel(systemMask.appendType, systemMask.appendLen)}`,
      source: 'system',
    }
  }

  return {
    preview: '-',
    rule: 'Tanimli degil',
    source: 'none',
  }
}

function shortId(value) {
  const text = String(value || '')
  if (text.length <= 12) return text.toUpperCase()
  return `${text.slice(0, 12).toUpperCase()}...`
}

function CategoryTreeRow({
  node,
  depth,
  isLast,
  tree,
  selectedId,
  collapsedMap,
  onSelect,
  onToggle,
  systemMask,
  genSku,
  appendLabel,
  accountChipLabel,
  getAccountName,
}) {
  const hasChildren = (node.children || []).length > 0
  const collapsed = !!collapsedMap[node.id]
  const isSelected = selectedId === node.id
  const deleted = !!node.deleted_at
  const rowInset = depth * 56
  const connectorWidth = 32
  const connectorX = rowInset - connectorWidth
  const parentName = findParentName(tree, node.id)
  const skuState = buildSkuState(node, systemMask, genSku, appendLabel)
  const relatedAccountName = getAccountName(node)
  const metaItems = [
    shortId(node.id),
    ...(parentName ? [parentName] : []),
    ...(deleted ? ['Silinmis'] : []),
  ]

  return (
    <div style={{ position: 'relative', padding: `6px 0 6px ${rowInset}px` }}>
      {depth > 0 && (
        <>
          <div
            style={{
              position: 'absolute',
              left: connectorX,
              top: 0,
              bottom: isLast ? '50%' : 0,
              width: 1,
              background: '#e2e8f0',
              zIndex: 0,
            }}
          />
          <div
            style={{
              position: 'absolute',
              left: connectorX,
              top: '50%',
              width: connectorWidth,
              height: 1,
              background: '#e2e8f0',
              zIndex: 0,
            }}
          />
        </>
      )}

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '12px 16px 12px 28px',
          background: deleted ? '#fff7f7' : node.bg || '#fff',
          border: `1px solid ${isSelected ? '#fca5a5' : `${node.text_color || '#cbd5e1'}30`}`,
          borderRadius: 18,
          position: 'relative',
          transition: 'transform .12s, box-shadow .12s, border-color .12s',
          boxShadow: isSelected ? '0 12px 24px rgba(248,113,113,.10)' : '0 10px 24px rgba(15,23,42,.05)',
          cursor: 'pointer',
          opacity: deleted ? 0.82 : 1,
        }}
        onClick={() => onSelect(node.id)}
        onMouseEnter={event => {
          event.currentTarget.style.transform = 'translateY(-1px)'
          event.currentTarget.style.boxShadow = isSelected ? '0 14px 28px rgba(248,113,113,.12)' : '0 14px 28px rgba(15,23,42,.08)'
        }}
        onMouseLeave={event => {
          event.currentTarget.style.transform = 'translateY(0)'
          event.currentTarget.style.boxShadow = isSelected ? '0 12px 24px rgba(248,113,113,.10)' : '0 10px 24px rgba(15,23,42,.05)'
        }}
      >
        <div
          style={{
            position: 'absolute',
            left: 16,
            top: 11,
            bottom: 11,
            width: 7,
            borderRadius: 999,
            background: node.text_color || '#64748b',
            opacity: .95,
          }}
        />

        <div style={{ flex: 1, minWidth: 0, display: 'grid', gap: 6 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
            <div style={{ minWidth: 0 }}>
              <div style={{ marginBottom: 6, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <span className="badge" style={{ background: '#eef3fb', color: node.text_color || '#475569', fontSize: '.7rem', fontWeight: 800 }}>
                  Kategori
                </span>
                {skuState.source === 'system' && (
                  <span className="badge" style={{ background: '#fff7ed', color: '#c2410c', fontSize: '.7rem', fontWeight: 700 }}>
                    Sistem SKU
                  </span>
                )}
              </div>
              <div style={{ fontWeight: 800, fontSize: '1rem', color: deleted ? '#b91c1c' : '#0f172a', lineHeight: 1.25 }}>
                {node.name}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end', minWidth: 0 }}>
              {metaItems.map(item => (
                <span
                  key={item}
                  className="badge"
                  style={{
                    background: '#f3f6fb',
                    color: item === 'Silinmis' ? '#b91c1c' : '#64748b',
                    fontSize: '.7rem',
                    maxWidth: 180,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {item}
                </span>
              ))}
              {hasChildren ? (
                <button
                  onClick={event => {
                    event.stopPropagation()
                    onToggle(node.id)
                  }}
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: 999,
                    border: '1px solid #e2e8f0',
                    background: '#fff',
                    color: collapsed ? '#94a3b8' : node.text_color || '#64748b',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '.65rem',
                    flexShrink: 0,
                  }}
                >
                  <i className={`fa-solid fa-chevron-${collapsed ? 'right' : 'down'}`} />
                </button>
              ) : (
                <div
                  style={{
                    width: 28,
                    height: 28,
                    flexShrink: 0,
                    borderRadius: 999,
                    border: '1px solid #e2e8f0',
                    background: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#cbd5e1',
                  }}
                >
                  <i className="fa-solid fa-chevron-right" style={{ fontSize: '.6rem' }} />
                </div>
              )}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', minHeight: 24 }}>
            {skuState.preview !== '-' && (
              <span className="badge" style={{ background: skuState.source === 'system' ? '#fff7ed' : '#ede9fe', color: skuState.source === 'system' ? '#c2410c' : '#5b21b6', fontFamily: 'monospace', fontSize: '.7rem' }}>
                {skuState.preview}
              </span>
            )}
            {node.acc_cat && (
              <span className="badge" style={{ background: '#f1f5f9', color: '#64748b', fontSize: '.7rem' }}>
                {node.acc_cat}
              </span>
            )}
            {node.acc_code && (
              <span className="badge" style={{ background: '#f1f5f9', color: '#475569', fontFamily: 'monospace', fontSize: '.7rem' }}>
                {node.acc_code}
              </span>
            )}
            {relatedAccountName && (
              <span className="badge" style={{ background: '#e0f2fe', color: '#0369a1', fontSize: '.7rem' }}>
                {accountChipLabel}
              </span>
            )}
            {node.description && (
              <span style={{ fontSize: '.72rem', color: '#64748b', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '48%' }}>
                {node.description}
              </span>
            )}
          </div>
        </div>
      </div>

      {hasChildren && !collapsed && (
        <div style={{ marginTop: 8 }}>
          {(node.children || []).map((child, index, arr) => (
            <CategoryTreeRow
              key={child.id}
              node={child}
              depth={depth + 1}
              isLast={index === arr.length - 1}
              tree={tree}
              selectedId={selectedId}
              collapsedMap={collapsedMap}
              onSelect={onSelect}
              onToggle={onToggle}
              systemMask={systemMask}
              genSku={genSku}
              appendLabel={appendLabel}
              accountChipLabel={accountChipLabel}
              getAccountName={getAccountName}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export default function CategoryHierarchyView({
  tree,
  loading,
  emptyText,
  sectionTitle = 'Hiyerarsi',
  sectionSubtitle = 'Kategori baglari',
  collapsedMap,
  onToggle,
  onEdit,
  onAddChild,
  onDelete,
  onRestore,
  genSku,
  appendLabel,
  systemMask,
  accountLabel,
  accountChipLabel = 'Bagli hesap',
  getAccountName,
  loadingText = 'Yukleniyor...',
}) {
  const [selectedNodeId, setSelectedNodeId] = useState(null)
  const [activeTab, setActiveTab] = useState('general')

  useEffect(() => {
    if (!tree.length) {
      setSelectedNodeId(null)
      return
    }
    if (!selectedNodeId || !findNode(tree, selectedNodeId)) {
      setSelectedNodeId(tree[0]?.id || null)
    }
  }, [tree, selectedNodeId])

  const selectedNode = useMemo(() => {
    if (!selectedNodeId) return null
    return findNode(tree, selectedNodeId)
  }, [tree, selectedNodeId])

  const parentName = selectedNode ? findParentName(tree, selectedNode.id) : ''
  const selectedChildren = selectedNode?.children || []
  const selectedSkuState = selectedNode ? buildSkuState(selectedNode, systemMask, genSku, appendLabel) : null
  const selectedAccountName = selectedNode ? getAccountName(selectedNode) : ''
  const canAddChild = Boolean(selectedNode && !selectedNode.deleted_at)

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.8fr) minmax(320px, .82fr)', gap: 18, alignItems: 'start' }}>
      <div className="card" style={{ overflow: 'hidden', padding: 0, minHeight: 300 }}>
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center', color: '#94a3b8' }}>
            <i className="fa-solid fa-spinner fa-spin" /> {loadingText}
          </div>
        ) : tree.length === 0 ? (
          <div className="empty" style={{ padding: 48 }}>
            <i className="fa-solid fa-tags" />
            <p>{emptyText}</p>
          </div>
        ) : (
          <div style={{ padding: '12px 12px 18px' }}>
            <div style={{ padding: '4px 10px 12px', borderBottom: '1px solid #eef2f7', marginBottom: 8 }}>
              <div style={{ fontSize: '.73rem', fontWeight: 800, letterSpacing: '.08em', color: '#94a3b8' }}>{sectionTitle.toUpperCase()}</div>
              <div style={{ fontSize: '1.02rem', fontWeight: 800, color: '#0f172a', marginTop: 6 }}>{sectionSubtitle}</div>
            </div>

            {tree.map((node, index, arr) => (
              <CategoryTreeRow
                key={node.id}
                node={node}
                depth={0}
                isLast={index === arr.length - 1}
                tree={tree}
                selectedId={selectedNodeId}
                collapsedMap={collapsedMap}
                onSelect={id => {
                  setSelectedNodeId(id)
                  setActiveTab('general')
                }}
                onToggle={onToggle}
                systemMask={systemMask}
                genSku={genSku}
                appendLabel={appendLabel}
                accountChipLabel={accountChipLabel}
                getAccountName={getAccountName}
              />
            ))}
          </div>
        )}
      </div>

      <div className="card" style={{ padding: 14, position: 'sticky', top: 16 }}>
        {!selectedNode ? (
          <div className="empty" style={{ minHeight: 260, padding: 32 }}>
            <i className="fa-solid fa-arrow-pointer" />
            <div style={{ fontSize: '1rem', fontWeight: 700, color: '#334155' }}>Bir kategori secin</div>
            <p style={{ fontSize: '.83rem' }}>Soldaki hiyerarsiden sectiginiz kayit burada detaylariyla gorunur.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gap: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start' }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: '.73rem', fontWeight: 800, letterSpacing: '.08em', color: '#94a3b8' }}>KATEGORI</div>
                <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a', marginTop: 6, lineHeight: 1.2 }}>
                  {selectedNode.name}
                </div>
              </div>

              <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                {!selectedNode.deleted_at && (
                  <button className="btn-o" onClick={() => onEdit(selectedNode)} style={{ padding: '8px 14px', fontSize: '.82rem' }}>
                    Duzenle
                  </button>
                )}
                {canAddChild && (
                  <button className="btn-p" onClick={() => onAddChild(selectedNode.id)} style={{ padding: '8px 14px', fontSize: '.82rem' }}>
                    <i className="fa-solid fa-plus" /> Alt Kategori
                  </button>
                )}
                <button
                  className="btn-g"
                  onClick={() => (selectedNode.deleted_at ? onRestore(selectedNode) : onDelete(selectedNode))}
                  style={{ padding: '8px 12px', fontSize: '.82rem', color: selectedNode.deleted_at ? '#166534' : '#b91c1c' }}
                >
                  <i className={`fa-solid fa-${selectedNode.deleted_at ? 'rotate-left' : 'trash'}`} />
                </button>
              </div>
            </div>

            <div
              style={{
                background: selectedNode.deleted_at ? '#fff7f7' : selectedNode.bg || '#f8fafc',
                border: `1px solid ${selectedNode.deleted_at ? '#fecaca' : `${selectedNode.text_color || '#94a3b8'}22`}`,
                borderRadius: 16,
                padding: '14px 16px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 6 }}>
                <span className="badge" style={{ background: '#eef3fb', color: selectedNode.text_color || '#475569', fontSize: '.68rem' }}>
                  Kategori
                </span>
                {selectedSkuState?.source === 'system' && (
                  <span className="badge" style={{ background: '#fff7ed', color: '#c2410c', fontSize: '.68rem' }}>
                    Sistem SKU
                  </span>
                )}
                {selectedNode.deleted_at && (
                  <span className="badge" style={{ background: '#fee2e2', color: '#b91c1c', fontSize: '.68rem' }}>
                    Silinmis
                  </span>
                )}
              </div>
              <div style={{ fontSize: '.86rem', color: '#47607f', fontWeight: 600 }}>
                Alt kategori eklenebilir, renk ve muhasebe baglari bu panelden takip edilir.
              </div>
            </div>

            <div style={{ display: 'flex', gap: 8, padding: 4, background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 14 }}>
              <button
                className={activeTab === 'general' ? 'btn-p' : 'btn-g'}
                onClick={() => setActiveTab('general')}
                style={{ flex: 1, padding: '9px 12px', fontSize: '.8rem', boxShadow: 'none' }}
              >
                Genel Bilgiler
              </button>
              <button
                className={activeTab === 'children' ? 'btn-p' : 'btn-g'}
                onClick={() => setActiveTab('children')}
                style={{ flex: 1, padding: '9px 12px', fontSize: '.8rem', boxShadow: 'none' }}
              >
                Alt Kategoriler ({selectedChildren.length})
              </button>
            </div>

            {activeTab === 'general' ? (
              <div style={{ display: 'grid', gap: 12 }}>
                {[ 
                  ['Ad', selectedNode.name],
                  ['Ust Kategori', parentName || '-'],
                  ['SKU Onizleme', selectedSkuState?.preview || '-'],
                  ['SKU Kurali', selectedSkuState?.rule || '-'],
                  ['Muhasebe Kategorisi', selectedNode.acc_cat || '-'],
                  ['Muhasebe Hesap Kodu', selectedNode.acc_code || '-'],
                  [accountLabel, selectedAccountName || '-'],
                  ['Aciklama', selectedNode.description || '-'],
                  ['Durum', selectedNode.deleted_at ? 'Silinmis' : 'Aktif'],
                ].map(([label, value]) => (
                  <div key={label}>
                    <label className="f-label">{label}</label>
                    <div className="f-input" style={{ display: 'flex', alignItems: 'center', minHeight: 44, color: value === '-' ? '#94a3b8' : '#475569', background: '#f8fbff' }}>
                      {value}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ display: 'grid', gap: 10 }}>
                {selectedChildren.length === 0 ? (
                  <div className="empty" style={{ padding: 24, minHeight: 180 }}>
                    <i className="fa-solid fa-diagram-project" />
                    <div style={{ fontSize: '.95rem', fontWeight: 700, color: '#334155' }}>Alt kategori bulunmuyor</div>
                    <p style={{ fontSize: '.8rem' }}>Bu kayit icin istersen sag ustten yeni bir alt kategori ekleyebilirsin.</p>
                  </div>
                ) : (
                  selectedChildren.map(child => {
                    const childSkuState = buildSkuState(child, systemMask, genSku, appendLabel)
                    return (
                      <button
                        key={child.id}
                        onClick={() => {
                          setSelectedNodeId(child.id)
                          setActiveTab('general')
                        }}
                        style={{
                          textAlign: 'left',
                          border: '1px solid #e2e8f0',
                          borderRadius: 16,
                          background: '#fff',
                          padding: '12px 14px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: 12,
                          boxShadow: '0 8px 18px rgba(15,23,42,.04)',
                          cursor: 'pointer',
                        }}
                      >
                        <div style={{ minWidth: 0 }}>
                          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 6 }}>
                            <span className="badge" style={{ background: '#eef3fb', color: child.text_color || '#475569', fontSize: '.68rem' }}>Kategori</span>
                            {childSkuState.preview !== '-' && (
                              <span className="badge" style={{ background: '#f8fafc', color: '#64748b', fontFamily: 'monospace', fontSize: '.68rem' }}>
                                {childSkuState.preview}
                              </span>
                            )}
                          </div>
                          <div style={{ fontSize: '.98rem', fontWeight: 700, color: child.deleted_at ? '#b91c1c' : '#0f172a' }}>{child.name}</div>
                        </div>
                        <i className="fa-solid fa-chevron-right" style={{ color: '#94a3b8' }} />
                      </button>
                    )
                  })
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
